from selenium import webdriver
from selenium.webdriver.support.ui import Select
import time
d=webdriver.Chrome()
d.get("http://www.facebook.com/")
d.maximize_window()
time.sleep(3)
d.find_element_by_id("u_0_2").click()
time.sleep(3)
# d.find_element_by_name("firstname").send_keys("srihari")
so=Select(d.find_element_by_id('month'))
so.select_by_value('2')
s1=Select(d.find_element_by_id('day'))
s1.select_by_index(13)
s2=Select(d.find_element_by_id('year'))
s2.select_by_index(28)


