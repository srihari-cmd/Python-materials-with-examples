from selenium import webdriver
import time
driver = webdriver.Chrome()
## Switch into first tab from right side

driver.get("https://www.python.org/")
time.sleep(5)
driver.execute_script("window.open('http://robotframework.org/')")
time.sleep(3)
driver.execute_script("window.open('https://mail.google.com')")
time.sleep(4)
windows = driver.window_handles
print("\n all the window tabs",windows)
print("\n default tab title is",driver.title)
driver.switch_to.window(windows[0])
time.sleep(3)
print("the 000 tab title is",driver.title)

driver.switch_to.window(windows[1])
time.sleep(3)
print("the 111 tab title is",driver.title)

driver.switch_to.window(windows[2])
time.sleep(3)
print("the 222 tab title is",driver.title)

driver.switch_to.window(driver.window_handles[2])
time.sleep(3)
print("\n the index of 2 tab title is ",driver.title)

driver.switch_to.window(driver.window_handles[1])
time.sleep(3)
print("\n the index of 1 tab title is ",driver.title)

driver.switch_to.window(driver.window_handles[0])
time.sleep(3)
print("\n the index of 0 tab title is ",driver.title)


