from selenium import webdriver
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.python.org/")
time.sleep(2)
driver.execute_script("window.open('http://robotframework.org/')")
time.sleep(2)
driver.execute_script("window.open('https://mail.google.com')")
get_url = driver.current_url
print("the current url is ",get_url)
print("the current title is",driver.title)


