from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("http://selenium-python.readthedocs.io/")

actions = ActionChains(driver)

obj = driver.find_element_by_xpath('//li/a[contains(text(),"3.2")]')
time.sleep(3)
actions.move_to_element(obj)
time.sleep(3)
actions.click()
actions.perform()
