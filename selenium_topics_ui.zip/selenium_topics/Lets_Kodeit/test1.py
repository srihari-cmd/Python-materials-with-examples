from selenium import webdriver
import time
from selenium.webdriver.support.ui import Select

d = webdriver.Chrome()
d.get("https://letskodeit.teachable.com/p/practice")
d.maximize_window()
time.sleep(3)

# d.find_element_by_id("benzradio").click()
# time.sleep(3)
# d.find_element_by_id("bmwradio").click()
# time.sleep(3)
# d.find_element_by_id("hondaradio").click()
# time.sleep(3)

d.find_element_by_xpath('//input[@id="benzradio"]').click()
time.sleep(3)
d.find_element_by_xpath('//input[@id="bmwradio"]').click()
time.sleep(3)
d.find_element_by_xpath('//input[@id="hondaradio"]').click()
time.sleep(3)

'''
# dropdown

select = Select(d.find_element_by_id("carselect"))
# select.select_by_value("benz")
# time.sleep(2)

select.select_by_index(1)
time.sleep(2)

# dropdown select
select = Select(d.find_element_by_id("multiple-select-example"))

select.select_by_value("peach")
time.sleep(2)

select.select_by_value("apple")
time.sleep(2)

select.select_by_value("orange")
time.sleep(2)

# select.select_by_index(1)
# time.sleep(2)
# checkbox
d.find_element_by_id("bmwcheck").click()
time.sleep(2)
d.find_element_by_id("hondacheck").click()
time.sleep(2)
d.find_element_by_id("benzcheck").click()
time.sleep(2)

# switch window

d.find_element_by_id("openwindow").click()
time.sleep(2)

# open tab

d.find_element_by_id("opentab").click()
'''
time.sleep(4)

# alerts

d.find_element_by_id("name").send_keys("srihari")
time.sleep(3)
d.find_element_by_id("confirmbtn").click()
time.sleep(2)
alert = d.switch_to.alert
alert.accept()

# d.close()
# select.select_by_value("benz")
# time.sleep(2)
