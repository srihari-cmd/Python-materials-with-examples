import pytest

#
def add(a):
   return a*2

def test_add():
    assert add(5)==10,"doesnt match"
    print("the add method values are ",add(20))
def func(x):
    return x+1
def test_func():
    assert func(4)==5,"the condition is failed"

