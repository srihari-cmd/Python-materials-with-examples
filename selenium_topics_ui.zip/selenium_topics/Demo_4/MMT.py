from selenium import webdriver,common
from selenium.webdriver.common.keys import Keys
from datetime import datetime
import time,re


def type_and_enter(element,text):
    element.clear()
    element.send_keys(text)
    time.sleep(1)
    element.send_keys(Keys.ENTER)

source = "Bangalore"
destination = "New Delhi"

# CREATE A NEW GOOGLE CHROME OBJECT & LOGIN TO makemytrip.com
chrome_browser = webdriver.Chrome()
chrome_browser.get("https://www.makemytrip.com/")

# ASSERT WE ARE ON THE CORRECT PAGE
assert "makemytrip" in chrome_browser.title.lower()
chrome_browser.maximize_window()
time.sleep(4)
# ENTER VALUE FOR "FROM"
# from_field = chrome_browser.find_element_by_id("hp-widget__sfrom")
from_field = chrome_browser.find_element_by_id("fromCity")
type_and_enter(from_field,source)

# ENTER VALUE FOR "TO"
# to_field = chrome_browser.find_element_by_id("hp-widget__sTo")
to_field = chrome_browser.find_element_by_id("toCity")
type_and_enter(to_field,destination)

# SET DEPART DATE TO PRESENT DAY
# depart_field = chrome_browser.find_element_by_id("hp-widget__depart")
# depart_field.click()



# time.sleep(4)
# chrome_browser.find_element_by_xpath('//div/span[@class="swipCircle"]').click()
# time.sleep(4)
