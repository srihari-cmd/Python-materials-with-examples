from selenium import webdriver
import time

from selenium.webdriver.common.keys import Keys
Url = "https://www.makemytrip.com/"
Source = "fromCity"
Dest = "toCity"
Sec_date = '//label/span[contains(text(),"DEPARTURE")]'


class Flight():

    # def __init__(self,Url,Sr_point):
    def __init__(self,Url,Per_date):
        self.Url = Url
        # self.Sr_point = Sr_point
        # self.De_point = De_point
        self.Per_date = Per_date

    def MMT_page(self):
        self.driver = webdriver.Chrome()
        self.driver.get(Url)
        self.driver.maximize_window()
        time.sleep(3)
        self.driver.find_element_by_xpath(Sec_date).click()
        time.sleep(2)
        self.driver.find_element_by_xpath('(//div[@class="dateInnerCell"])[31]').click()
        time.sleep(2)


# obj = Flight(Url,Source,Dest,Sec_date)
obj = Flight(Url,Sec_date)
obj.MMT_page()

# self.driver.find_element_by_id(Source).send_keys(Keys.ENTER)
# self.driver.find_element_by_id(Source).send_keys("Bangalore")

# s1= self.driver.find_element_by_xpath('//div/p[contains(text(),"Bangalore, India")]')
# s1.click()
# self.driver.find_element_by_xpath('(//div/p[@class="font14 appendBottom5 blackText"])[4]').send_keys(Keys.ENTER)
# time.sleep(2)
# self.driver.find_element_by_xpath('(//div/p[@class="font14 appendBottom5 blackText"])[4]').send_keys(Keys.ENTER)
#
# time.sleep(2)
# self.driver.find_element_by_id(Dest).send_keys("Goa")
# time.sleep(2)