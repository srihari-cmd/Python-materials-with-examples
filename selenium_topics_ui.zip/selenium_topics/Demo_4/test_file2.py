
# Program published on https://beginnersbook.com

# Python program to perform Addition Subtraction Multiplication
# and Division of two numbers

num1 = int(input("Enter First Number: "))
num2 = int(input("Enter Second Number: "))

print("Enter which operation would you like to perform?")
ch = input("Enter any of these char for specific operation +,-,*,/: ")

result = 0
if ch == '+':
    result = num1 + num2
elif ch == '-':
    result = num1 - num2
elif ch == '*':
    result = num1 * num2
elif ch == '/':
    result = num1 / num2
else:
    print("Input character is not recognized!")

print(num1, ch , num2, ":", result)



# def Divide_fun(a,b):
#     c = a/b
#     return c
# a = int(input("enter "))
# b = int(input("enter"))
#
# print("the ",Divide_fun(a,b))
# # print("the ",Divide_fun(b))



