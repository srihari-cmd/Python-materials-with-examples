
from selenium import webdriver
import time
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome()
driver.get("https://www.makemytrip.com/")
driver.maximize_window()

# driver.find_element_by_xpath('//div/p[contains(text(),"Bengaluru, India")]').send_keys(Keys.ENTER)
time.sleep(3)
driver.find_element_by_id("fromCity").send_keys("Goa")
time.sleep(7)
driver.find_element_by_id("first-img")
alert = driver.switch_to.alert
alert.dismiss()
driver.find_element_by_xpath('(//li[@class="react-autosuggest__suggestion react-autosuggest__suggestion--first"])[1]').click()
time.sleep(10)



#driver.find_element_by_id("fromCity").send_keys(Keys.ENTER)
# driver.find_element_by_id("fromCity").send_keys("Bangalore")
# time.sleep(3)
#time.sleep(30)


# driver.find_element_by_xpath('//div[@class="fsw_inputBox searchCity inactiveWidget "]').click()
# driver.find_element_by_xpath('//input[@aria-controls="react-autowhatever-1"]').send_keys("Goa")
# time.sleep(4)
# driver.find_element_by_xpath('(//li[@class="react-autosuggest__suggestion react-autosuggest__suggestion--first"])[1]').click()
# time.sleep(4)



# driver.find_element_by_xpath('//div/p[contains(text(),"Bengaluru, India")]').send_keys(Keys.ENTER)

# driver.find_element_by_id("fromCity").send_keys(Keys.ENTER)

# driver.find_element_by_xpath('//div/label/span[contains(text(),"From")]').send_keys("Bangalore")

# driver.find_element_by_xpath('//div/label/span[contains(text(),"From")]').send_keys(Keys.ENTER)



# driver.find_element_by_xpath('')

driver.close()