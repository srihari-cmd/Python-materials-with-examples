'''
'__breakpointhook__', '__displayhook__', '__doc__', '__excepthook__', '__interactivehook__', '__loader__', '__name__', '__package__', '__spec__', '__stderr__'
,'__stdin__', '__stdout__', '_base_executable', '_clear_type_cache', '_current_frames', '_debugmallocstats', '_enablelegacywindowsfsencoding', '_framework'
, '_getframe', '_git', '_home', '_xoptions', 'api_version', 'argv', 'base_exec_prefix', 'base_prefix', 'breakpointhook', 'builtin_module_names', 'byteorder'
, 'call_tracing', 'callstats', 'copyright', 'displayhook', 'dllhandle', 'dont_write_bytecode', 'exc_info', 'excepthook', 'exec_prefix', 'executable', 'exit'
, 'flags', 'float_info', 'float_repr_style', 'get_asyncgen_hooks', 'get_coroutine_origin_tracking_depth', 'get_coroutine_wrapper', 'getallocatedblocks'
, 'getcheckinterval', 'getdefaultencoding', 'getfilesystemencodeerrors', 'getfilesystemencoding', 'getprofile', 'getrecursionlimit', 'getrefcount', 'getsizeof'
, 'getswitchinterval', 'gettrace', 'getwindowsversion', 'hash_info', 'hexversion', 'implementation', 'int_info', 'intern', 'is_finalizing', 'maxsize'
, 'maxunicode', 'meta_path', 'modules', 'path', 'path_hooks', 'path_importer_cache', 'platform', 'prefix', 'set_asyncgen_hooks'
, 'set_coroutine_origin_tracking_depth', 'set_coroutine_wrapper', 'setcheckinterval', 'setprofile','setrecursionlimit', 'setswitchinterval', 'settrace', 
 'stderr', 'stdin', 'stdout', 'thread_info', 'version', 'version_info', 'warnoptions', 'winver'
 '''


# here performed sys module

import sys

'''
print("Hello {}. Welcome to {} tutorial".format(sys.argv[1], sys.argv[2]))

print("Hello {}. Welcome to {} tutorial".format(sys.argv[1], sys.argv[2]))

print("the 0 index is ",sys.argv[0])


# to get max size of integer 

print(sys.maxsize)
print(sys.getprofile)

print("copyright",sys.copyright)
print(sys.path)

print(sys.version)
print(sys.call_tracing )

# print("the get trace things ",sys.gettrace)
# print("the set trace things ",sys.settrace)
# print(dir(sys))

# print(sys.builtin_module_names)
# print("the modules are",sys.modules)

'''
print("i am waiting {}. from your {}".format(sys.argv[1],sys.argv[2]))
print("i am waiting ",sys.argv[0])