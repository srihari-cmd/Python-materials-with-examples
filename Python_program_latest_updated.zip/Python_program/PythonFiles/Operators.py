x= 4
y= 5
print(x + y)

x= 4
y= 5
print(y-x)

x= 5
y= 10
print(x / y)

x= 5
y= 10
print(x % y)

#Comparision
x = 4
y = 5
print(('x > y  is',x>y))

#Assignment
x=10
x+=10                 #x =x+10
print(x)
x-=10
print(x)
x*=10
print(x)

#Logical Operators

a = True
b = False
print(('a and b is',a and b))
print(('a or b is',a or b))
print(('not a is',not a))

#Membership opearators

x = 4
y = 8
list = [1, 2, 3, 4, 5 ];
if ( x in list ):
   print("Line 1 - x is available in the given list")
else:
   print("Line 1 - x is not available in the given list")
if ( y not in list ):
   print("Line 2 - y is not available in the given list")
else:
   print("Line 2 - y is available in the given list")

