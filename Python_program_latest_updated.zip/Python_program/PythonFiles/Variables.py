
#Python indentation is very important
if 5 > 7:
  print()
  print("Five is greater than two!")

"""
This is a comment
written in
more than just one line

this is how multi line comments are written
"""
"""
A variable can have a short name (like x and y) or a more descriptive name (age, carname, total_volume). Rules for Python variables:
A variable name must start with a letter or the underscore character
A variable name cannot start with a number
A variable name can only contain alpha-numeric characters and underscores (A-z, 0-9, and _ )
Variable names are case-sensitive (age, Age and AGE are three different variables)
"""

"three points to remember in python"


x = 1    # int
y = 2.8  # float
z = 1j   # complex

print(z)


#integer
x = 1
y = 35656222554887711
z = -3255522

print(type(x))
print(type(y))
print(type(z))


#float
x = 1.10
y = 1.0
z = -35.59

print(type(x))
print(type(y))
print(type(z))
x = 35e3
y = 12E4
z = -87.7e100

#Complex

print(type(x))
print(type(y))
print(type(z))
print(z)
x = 3+4j
x = 1 # int
y = 2.8 # float
z = 1j # complex
3
#convert from int to float:
a = float(x)

#convert from float to int:
b = int(y)

#convert from int to complex:
c = complex(x)



print(a)
print(b)
print(c)

print(type(a))
print(type(b))
print(type(c))



X = 5
print(X)
X = "AR"
print(X)
#no declaration

a=b=c=d=10                     #a=10,b=10,c=10,d=10
print(a)
print(b)
print(c)
print(d)

a,b,c,d =1,2,3,4
print(a)
print(b)
print(c)
print(d)

name = "Raj"

print("Hello, "+name)

x=10
y=5

print(x+y)

String ="guys"

multiline ="""dsadsajdksakdbsajk
dbsadbkjsabdkjsbajk
sbdabsdbsakjbdkjsa"""

print(multiline)