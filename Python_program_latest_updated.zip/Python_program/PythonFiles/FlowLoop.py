#Flows:-if elif else,for ,while,break and continue,pass,enumerate
#complex:- Nested IF
#IF ELIF ELSE
num=-70
if num > 0:
    print("Positive number")
elif num == 0:
    print("Zero")
else:
    print("Negative number")
#For Loop
numbers = [6, 5, 3, 8, 4, 2, 5, 4, 11]

# variable to store the sum
sum = 0

# iterate over the list
for val in numbers:
    print(val)
    sum = sum+val

# Output: The sum is 48
print("The sum is", sum)
# Range Function
Output: range(0, 10)
print(range(10))
# Output: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print(list(range(10)))
# Output: [2, 3, 4, 5, 6, 7]
print(list(range(2, 8)))
# Output: [2, 5, 8, 11, 14, 17]
print(list(range(2, 20, 3)))
genre = ['pop', 'rock', 'jazz','classic']

# iterate over the list using index
for i in range(len(genre)):
	print("I like", genre[i])

digits = [0, 1, 5]
#For Else
for i in digits:
    print(i)
else:
    print("No items left.")
#while loop
n = 10

# initialize sum and counter
sum = 0
i = 1

while i <= n:
    sum = sum + i
    i = i+1    # update counter

# print the sum
print("The sum is", sum)
#while with else
# the use of else statement
# with the while loop

counter = 0

while counter < 3:
    print("Inside loop")
    counter = counter + 1
else:
    print("Inside else")
#Break
# Use of break statement inside loop

for val in "string":             #['s','t','r','i','n','g']
    if val == "i":
        print('y')
        break
    print(val)
print("The end")
#Continue
# Program to show the use of continue statement inside loops
for val in "string":
    if val == "i":
        continue
    print(val)

print("The end")
#PASS
# pass is just a placeholder for
# functionality to be added later.
sequence = {'p', 'a', 's', 's'}
for val in sequence:
    pass
