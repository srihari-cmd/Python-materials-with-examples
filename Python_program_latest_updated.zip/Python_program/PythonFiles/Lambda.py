thisdict = {
  "brand": ["Ford","read","hallo"],
  "brand": "Mustang",
  "year": 1964
}
print(thisdict)
#
# def name(msg):
#   print(msg)
#
# name("hi")
"""A lambda function is a small anonymous function.

A lambda function can take any number of arguments, but can only have one expression.
"""

x = lambda a : a + 10
print(x(5))

x = lambda a, b : a * b
print(x(5, 6))

x = lambda a, b, c : a + b + c
print(x(5, 6, 2))

"""def myfunc(n):
  return lambda a : a * n
  """

def myfunc(n):
  return lambda a : a * n

mydoubler = myfunc(2)                   #lambda a:a *2
print(mydoubler)

print(mydoubler(11))

# def myfunc(n)
# return lambda a : a * n
#
# mydoubler = lambda a : a * 2
#
# print(mydoubler(11))

def myset(n):
    return  lambda a : a * n

mycase = lambda a : a * 3

print(mycase(2))

"""
Lambda function can be asssumed as the function with a mirror name
"""
def cube(y):
    return y * y * y;

g = lambda x: x * x * x
print(g(7))

print(cube(5))

#Power of Lambda

ages = [5, 12, 17, 18, 24, 32]

def myFunc(x):
  if x < 18:
    return False
  else:
    return True

adults = filter(myFunc, ages)             #myfunc(17)
print(filter.__doc__)
for x in adults:
  print(x)
#map
#The map() function executes a specified function for each item in a iterable. The item is sent to the function as a parameter.

#map(function, iterables)

def myfunc(n):
  return len(n)

x = map(myfunc, ('apple', 'banana', 'cherry'))
print(map.__doc__)
print(list(x))
#Filter and Lambda
li = [5, 7, 22, 97, 54, 62, 77, 23, 73, 61]
final_list = list(filter(lambda x: (x%2 != 0) , li))
print(final_list)
#Map and Lambda
li = [5, 7, 22, 97, 54, 62, 77, 23, 73, 61]
final_list = list(map(lambda x: x*2 , li))
print(final_list)

#palindrome

my_list = ["geeks", "geeg", "keek", "practice", "aa"]
result = list(filter(lambda x: reversed(x), my_list))
print(result)
print(filter(lambda x: print("".join(reversed(x))), my_list))

result = list(filter(lambda x: (x == "".join(reversed(x))), my_list))
print(result)



'''  Examples of anonymous Function  '''
'''
squaredArray = lambda x:x*x
print(squaredArray(2))
'''
def myfunc(n):
  return lambda a : a * n

mydoubler = myfunc(2)
print(mydoubler(11))

'''
mydoubler = lambda x:x*2
print(mydoubler(2))
'''

'''triple lambda'''
double_Function = lambda x :x * 2

Triple_Function = lambda y : y* double_Function(2)

Square_Function = lambda  z :z* Triple_Function(3)

print(Square_Function(10))

def secret(a,b,c):
  ''' This is the secret function'''
  double_Function = lambda x: x * x

  Triple_Function = lambda y: y * double_Function(a)

  Square_Function = lambda z: z * Triple_Function(b)

  return Square_Function(c)


print(secret(2,3,4))
print(secret(1,2,3))
print(secret(5,6,7))

'''
number of Rooms in a bulding

1 sqft
'''

def TotalRooms(length,breadth,height,Dimen):
  """finds total rooms in a building"""
  Length_Function = lambda x: x

  Breadth_Function = lambda y: y * Length_Function(length)

  Height_Function = lambda z: z * Breadth_Function(breadth)
  RoomDimen = lambda dimen : Height_Function(height)/dimen
  return RoomDimen(Dimen)

print(TotalRooms(2,2,2,2))

print(TotalRooms(3,5,7,3))

