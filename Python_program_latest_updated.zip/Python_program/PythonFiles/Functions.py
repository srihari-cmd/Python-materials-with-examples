"""def function_name(parameters):

	statement(s)
	"""

def greet(name):
	"""This function greets to
	the person passed in as
	parameter"""
	print("Hello, " + name)

greet("Suresh")
print(greet.__doc__)


#Return Value
def absolute_value(num):                #called function
	"""This function returns the absolute
	value of the entered number"""

	if num >= 0:
		return num
	else:
		return -num

# Output: 2
x =absolute_value(2)                     #calling function
print(x)

# Output: 4
print(absolute_value(-4))

#Scope of a Variable
x = 20
def my_func():
	x = 10
	print("Value inside function:",x)


my_func()
print("Value outside function:",x)

#Function Arguments
def greet(name,msg):
   """This function greets to
   the person with the provided message"""
   print("Hello",name + ', ' + msg)

greet("kishore","Good morning!")
greet("kishore","why are you late")
#Default Arguments
def greet(name, msg = "Good morning!"):
   """
   This function greets to
   the person with the
   provided message.

   If message is not provided,
   it defaults to "Good
   morning!"
   """

   print("Hello",name + ', ' + msg)

greet("Kate")
greet("Bruce","How do you do?")

#Arbiatry Arguements
def greet(*names):                #1,2,3,4,/.......n
   """This function greets all
   the person in the names tuple."""

   # names is a tuple with arguments
   for name in names:
       print("Hello",name)

greet("Monica","Luke","Steve","John")          #para1,para2..para4

#Recursion
# An example of a recursive function to
# find the factorial of a number

def calc_factorial(x):
    """This is a recursive function
    to find the factorial of an integer"""

    if x == 1:
        return 1
    else:
        return (x * calc_factorial(x+1))

num = 4
print("The factorial of", num, "is", calc_factorial(num))

#Intermediate:-Built-in Functions
#intermediate:-function recursion,arguements....

