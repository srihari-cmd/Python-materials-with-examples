import re

#findall function is used to fetch the all duplicates from the input string

line = "i love pet:cat i love you  pet:cow i have work with one thing"

found2 = re.findall(r'pet:\w\w\w',line)
print(found2)

if found2:
    print("found matched")
else:
    print("not found")

