
import re

'''
  str = 'purple alice-b@google.com monkey dishwasher'
  match = re.search(r'([\w.-]+)@([\w.-]+)', str)
  if match:
    print match.group()   ## 'alice-b@google.com' (the whole match)
    print match.group(1)  ## 'alice-b' (the username, group 1)
    print match.group(2)  ## 'google.com' (the host, group 2)'''

#here we are grouping the data based on gmail ids
 
list2 = ["sriharip@gmail.com", "srihari.pampana13@gmail.com","psrihari.5889@gmail.com","rebalsrihari143@gmail.com"]

for i in list2:
    # r = re.findall(r"[\w.-]+@[\w.-]+",i)
    r = re.search(r"([\w.-]+)@([\w.-]+)",i)
    print(r.group(1))
   

list2 = ["sriharip@gmail.com", "srihari.pampana13@gmail.com","psrihari.5889@gmail.com","rebalsrihari143@gmail.com"]

for i in list2:
    # r = re.findall(r"[\w.-]+@[\w.-]+",i)
    r = re.search(r"([\w.-]+)@([\w.-]+)",i)
    print(r.group(2))

