#this is how we can created the variables using this we can pass the values through cmd line

import sys

a = sys.argv[1]
b = sys.argv[2]

print("the username {} and password {}".format(a,b))
print("the value of 0 index is {}:".format(sys.argv[0]))

print(sys.maxsize)
print(sys.getprofile)
print("copyright",sys.copyright)
print(sys.path)
print(sys.version)
print("the modules are",sys.modules)
print("the get trace things ",sys.gettrace)
print("the get trace things ",sys.settrace)