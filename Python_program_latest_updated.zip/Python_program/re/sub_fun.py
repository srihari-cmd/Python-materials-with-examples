
import re

#sub function is used to replace from the input string where it exactly match the pattren.

line = "jhon@abc.com and alice@pqr.com"

found2 = re.sub(r"@\w+","@xyz",line)
print(found2)

if found2:
    print("found matched")
else:
    print("not found")
    
    
line = "jhon@abc.com and alice@pqr.com"

found2 = re.sub(r"@\w+","@gmail",line)
print(found2)

if found2:
    print("found matched")
else:
    print("not found")
    
print("##########################################")
line = "jhon@abc.com and alice@pqr.com"
list1 = ["jhon@efg.com","jhosdfdfn@abcd.com","jhonsdksj@ptr.com","jhon@sff.com"]
for i in list1:
    found2 = re.sub(r"[.]\w+",".inc",i)
    print(found2)

    if found2:
        print("found matched")
    else:
        print("not found")
    
    
print("#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#########################################")
line = "jhon@abc.com and alice@pqr.com"
list1 = ["jhon@efg.com","jhosdfdfn@abcd.com","jhonsdksj@ptr.com","jhon@sff.com"]
for i in list1:
    found2 = re.sub(r"@\w+","@gmail",i)
    print(found2)

    if found2:
        print("found matched")
    else:
        print("not found")
    
    
    
    

