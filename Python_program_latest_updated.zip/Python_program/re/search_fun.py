import re

# search function is used to search any where from the input string.
line = "pet:cat i love you"

found1 = re.search(r'pet:\w\w\w',line)
if found1:
    print("found matched")
else:
    print("not found")


# search function is used to search any where from the input string.

line = "i love pet:cat i love you  pet:cow"

found2 = re.search(r'pet:\w\w\w',line)
print(found2.group())
if found2:
    print("found matched")
else:
    print("not found")


