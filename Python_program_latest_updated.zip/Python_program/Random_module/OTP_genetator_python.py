# python program to create OTP_Generator

import random

s= "0123456789"
passlen = 6

p = "".join(random.sample(s,passlen))
print(p)

print("\n Your OTP(One Time Password) is : "+ p + "\n Please don't share it with any one." + "\n VALID ONLY FOR 3 MINUTES.")






