# The uniform() method returns a random floating number between the two specified numbers (both included).

# syntax
# random.uniform(a, b)

import random

print(random.uniform(20, 60))
