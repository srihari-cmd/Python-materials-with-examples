from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.action_chains import ActionChains
from time import sleep
import pytest


class test_bala:

    def test_up(self):
        self.d = webdriver.Chrome()
        self.d.get("https://testautomationpractice.blogspot.com/")
        self.d.maximize_window()

    def test_alert_checking(self, test_up):
        driver = self.d


    def test_dropdown_speed(self):
        driver = self.d
        select = Select(driver.find_element_by_xpath("//*[@id='speed']"))
        select.select_by_index(3)

    #
    # obj = d.find_element_by_xpath("//*[@id='HTML10']/div[1]/button")
    # action = ActionChains(d)
    # action.double_click(obj).perform()
    # source = d.find_element_by_xpath("//*[@id='draggable']")
    # target = d.find_element_by_xpath("//*[@id='droppable']")
    #
    # action.drag_and_drop(source, target).perform()
    # d.execute_script("window.scrollTo(0, 1000)")
    # source1 = d.find_element_by_xpath("//*[@id='gallery']/li[1]")
    # source2 = d.find_element_by_xpath("//*[@id='gallery']/li[2]")
    # target1 = d.find_element_by_xpath("//*[@id='trash']")
    # action.drag_and_drop(source1, target1).perform()
    # action.drag_and_drop(source2, target1).perform()
    #
    ## d.find_element_by_xpath("//*[@id='RESULT_RadioButton-9' and @class='drop_down']/option[2]").is_selected()
    ## data = Select(d.find_element_by_class_name("//*[@id='RESULT_RadioButton-9']"))
    ## data.deselect_by_value("Morning")
    # d.switch_to.frame(0)
    # d.find_element_by_xpath("//*[@id='RESULT_TextField-1']").send_keys("Bala")
    # select = Select(d.find_element_by_xpath("//*[@id='RESULT_RadioButton-9']"))
    # select.select_by_visible_text("Morning")
    # data = d.find_element_by_xpath(".//*[@id='q15']/table/tbody/tr[6]/td/label").click()
    # d.find_element_by_xpath(".//*[@id='q26']/table/tbody/tr[1]/td/label").click()
    # d.switch_to.frame(d.find_element_by_xpath("//*[@id='sidebar-right-1']"))
    # obj2 = d.find_element_by_xpath("//*[@id='slider']/span")
    #
    # action.click_and_hold(obj2).move_by_offset(1404, 1311).perform()
    # bf = d.find_element_by_xpath("//*[@id='q15']/table/tbody/tr[4]/td/label")
    # action.move_to_element(bf).perform()
    # data1=d.find_element_by_xpath("//*[@id='q21']/label").click()
    # data1.send_keys(r"C:\Users\bala.k\Downloads\jenkins-doc.docx")

    def test_close(self):
        self.d.quit()
