import pytest 




@pytest.mark.xfail
def test_add():
    
    assert 2==3,"not match"
    print("the add values are:")
    
def test_mul():
    print("the add values are:")
    
def test_div():
    print("the add values are:")
    