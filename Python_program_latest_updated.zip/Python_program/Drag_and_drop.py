# here i am performing the html page doing drap and drop operation using action_chains with all capitals

from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time
driver = webdriver.Chrome()
driver.get("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html")
driver.maximize_window()
time.sleep(5)
source_element= driver.find_element_by_id("box6")
target_element = driver.find_element_by_id("box106")

actions = ActionChains(driver)
actions.drag_and_drop(source_element,target_element).perform()

time.sleep(3)
source_element1 = driver.find_element_by_id("box3")
target_element1 = driver.find_element_by_id("box103")
actions.drag_and_drop(source_element1,target_element1).perform()

time.sleep(3)
source_element2 = driver.find_element_by_id("box7")
target_element2 = driver.find_element_by_id("box107")
actions.drag_and_drop(source_element2,target_element2).perform()

time.sleep(3)
source_element3 = driver.find_element_by_id("box5")
target_element3 = driver.find_element_by_id("box105")
actions.drag_and_drop(source_element3,target_element3).perform()

time.sleep(3)
source_element4 = driver.find_element_by_id("box4")
target_element4 = driver.find_element_by_id("box104")
actions.drag_and_drop(source_element4,target_element4).perform()

time.sleep(3)
source_element5 = driver.find_element_by_id("box2")
target_element5 = driver.find_element_by_id("box102")
actions.drag_and_drop(source_element5,target_element5).perform()

time.sleep(3)
source_element6 = driver.find_element_by_id("box1")
target_element6 = driver.find_element_by_id("box101")
actions.drag_and_drop(source_element6,target_element6).perform()

time.sleep(2)
driver.quit()





# driver.quit()

# source_element = driver.find_element_by_name('your element to drag')
# dest_element = driver.find_element_by_name('element to drag to')
# ActionChains(driver).drag_and_drop(source_element, dest_element).perform()





