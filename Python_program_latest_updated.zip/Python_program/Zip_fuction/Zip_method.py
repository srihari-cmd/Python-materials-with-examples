# zip --> using zip function will connect multiple components 

names = ("name","age","empid","company")
details = ("srihari pampana",29,"081312","calsoft")
zipped = list(zip(names,details))
print(zipped)
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

# using set in zip function it will not allow the duplicate values on this

names = ("name","age","empid","company","name")
details = ("srihari pampana",29,"081312","calsoft","srihari pampana")
zipped = set(zip(names,details))
print(zipped)
print("###############################################################################################")


# using dict in zip function it will not allow the duplicate values.

names = ("name","age","empid","company","name")
details = ("srihari pampana",29,"081312","calsoft","srihari pampana")
zipped = dict(zip(names,details))
print(zipped)
print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")


names = ("name","age","empid","company","name")
details = ("srihari pampana",29,"081312","calsoft","srihari pampana")
zipped = zip(names,details)

for (a,b) in zipped:
    print(a,b)





