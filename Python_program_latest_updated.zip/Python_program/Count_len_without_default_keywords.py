a=[10,3,4,2,2,2,6,1,8,9,55,9]
b={}
dict={}
for i in a:
    if i in dict:
        dict[i]=dict[i]+1
    else:
        dict[i]=1

for i,j in dict.items():
    if j>1:
        b[i]=j
print(b)




