# using islice module we can read the data how many number of lines we needed we can print it.

from itertools import islice
with open(r"C:\Users\srihari.pampana\Desktop\abc.txt","r") as f:
    for line in islice(f,4):
        print(line)