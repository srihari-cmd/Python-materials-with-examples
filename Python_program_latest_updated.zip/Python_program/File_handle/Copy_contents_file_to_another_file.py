# Copy the contents of a file to another file

# Write a Python program to copy the contents of a file to another file ?

from shutil import copyfile

copyfile(r"C:\Users\srihari.pampana\Desktop\xyz3.txt",r"C:\Users\srihari.pampana\Desktop\xyz4.txt")
