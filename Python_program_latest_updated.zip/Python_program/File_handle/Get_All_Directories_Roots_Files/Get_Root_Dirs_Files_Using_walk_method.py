
# using walk method in os module we can get separetly all the root, dirs ,files from main root .

import os

for (root,dirs,files) in os.walk("C:\\Users\\srihari.pampana\\Desktop\\Python_program",topdown=True):
    print(root)
    print(dirs)
    print(files)
    print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")