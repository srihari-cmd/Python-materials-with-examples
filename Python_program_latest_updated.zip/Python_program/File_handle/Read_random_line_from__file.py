# Read a random line from a file

# Write a Python program to read a random line from a file.?

import random
def random_line(fname):
    lines = open(fname).read().splitlines()
    return random.choice(lines)
print(random_line(r"C:\Users\srihari.pampana\Desktop\xyz3.txt"))


