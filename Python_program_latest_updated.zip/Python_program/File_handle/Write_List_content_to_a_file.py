# Write a List content to a file

# Write a Python program to write a list content to a file.?

color = ['Red', 'Green', 'White', 'Black', 'Pink', 'Yellow']
with open(r"C:\Users\srihari.pampana\Desktop\xyz3.txt", "a") as myfile:
        for c in color:
                myfile.write("%s\n" % c)

content = open(r"C:\Users\srihari.pampana\Desktop\xyz3.txt")
print(content.read())