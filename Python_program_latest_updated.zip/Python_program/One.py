# The main function in Python acts as the point of execution for any program. Defining the main function in Python programming is a 
# necessity to start the execution of the program as it gets executed only when the program is run directly and not executed when imported as a module.

def main():
    
    print("Hello")
    print("welcome userr")

if __name__=="__main__":
    main()
    