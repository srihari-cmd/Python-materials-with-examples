#multiple inheritance
class first(object):
    def __init__(self):
        super(first,self).__init__()
        print("srihari")
class second(object):
    def __init__(self):
        super(second,self).__init__()
        print("vijay kumar")
class third(second,first):
    def __init__(self):
        super(third,self).__init__()
        print("srinivasulu")
third()


# another way 

class One():
    def add1(self):
        print("the class one for add method")

class Two():
    def add(self):
        print("the class two for add method")
        
class Three(One,Two):
    def add1(self):
        print("the class three for add method")

inst = Three()
inst.add()

