a = ("John", "Charles", "Mike")
b = ("Jenny", "Christy", "Monica")


x = list(zip(a, b))
print(x)

# for i in x:
    # print(i)
    


    
    
    


