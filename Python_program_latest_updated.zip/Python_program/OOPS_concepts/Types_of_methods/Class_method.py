# 1.class method/class level data.
# here we are calling class variable using class method is nothing but a class level data.

class Student:
    Cname = "Google"
    def __init__(self,name,age):
        self.name = name
        self.age = age
        
    def display_details(self):
        print("the student name is :",self.name)            
        print("the student age is :",self.age)
    
    @classmethod                           # ---> class method
    def display_cname(cls):                 
        print("collage name is :",cls.Cname)
        
s1 = Student("srihari",29)
# s1.display_details()
Student.display_cname()       
        