# local variable is nothing but method variable

class Student:
    def __init__(self,name,age):
        self.name = name
        self.age = age
        
    def display_details(self):
        a = 20                  #--->  # local variable
        print("the student name is :",self.name)
        print("the student age is :",self.age+a)
    
s1 = Student("srihari",9)
s1.display_details()
        
        