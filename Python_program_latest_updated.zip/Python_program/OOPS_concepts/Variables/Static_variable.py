# static variable is nothing but class level variable

class Student:
    sname = "Google"     # --->     #static variable
    def __init__(self,name,age):
        self.name = name
        self.age = age
        
    def display_details(self):
        print("the student name is :",self.name)
        print("the student age is :",self.age)
        print("the static variable sname is :",self.sname)
    
s1 = Student("srihari",29)
s1.display_details()
        
        