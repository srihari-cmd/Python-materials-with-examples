

class A:
    def add(self):
        print("the add fun is")
        
class B(A):
    def add2(self):
        print("the add1 fun is")
        
class C(B):
    def add1(self):
        print("the add2 fun is")
        
        
inst = C()
inst.add()



class Base1:
    def B1(self):
        print("pass the base1")
    

class Base2:
    def B1(self):
        print("pass the base2")

class MultiDerived(Base1, Base2):
    def B2(self):
        print("pass the MultiDerived")

    
inst = MultiDerived()
inst.B1()



# Python program showing 
# abstract base class work 

from abc import ABC, abstractmethod 

class Polygon(ABC): 
    # abstract method 
    @abstractmethod
    def noofsides(self): 
        print("I have'nt  3 sides")

class Triangle(Polygon): 

    # overriding abstract method 
    def noofsides(self): 
        print("I have 3 sides") 

class Pentagon(Polygon): 

    # overriding abstract method 
    def noofsides(self): 
        print("I have 5 sides") 

class Hexagon(Polygon): 

    # overriding abstract method 
    def noofsides(self): 
        print("I have 6 sides") 

class Quadrilateral(Polygon): 

    # overriding abstract method 
    def noofsides(self): 
        print("I have 4 sides") 


# Driver code 

# K = Polygon()
# K.noofsides()

R = Triangle() 
R.noofsides() 

K = Quadrilateral() 
K.noofsides() 

R = Pentagon() 
R.noofsides() 

K = Hexagon() 
K.noofsides() 

# K = Polygon()
# K.noofsides()






