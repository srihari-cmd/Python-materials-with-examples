# class method
# self is used to refer the instance of variable

class Arithematic:
    def add(self,a,b):
        self.a=a
        self.b=b 
        print("sum of two numbers",a+b) 
    def sub(self,a,b):
        self.a=a 
        self.b=b 
        print("the sub of two numbers",a-b)
a=Arithematic()
a.add(10,20)
a.sub(30,30)
