polymorphism

* -->an object behaviour will get change during run time. by using inhertence and overriding we can achive it.

Encapsulation

1. Encapsulation is wrapping data or functionality(methods accessing data) together into single unit.

2. Giving protection to the class or class members. Using access specifiers/modifiers we can achive it.


abstract 

--> For Abstract class we can't create an instance.
--> An abstract method is a method that is declared, but contains no implementation.
--> By defining an abstract base class, you can define a common API for a set of subclasses.
--> By using abc module we can define abstract class.

class :
-------
class is a blue print to construct objects 

object :
--------
physical existence of a class is nothing but object.

referance variable :
--------------------
which is pointing to our object by using that we can perform operations on that objects.

hence class contains both variables and methods.

self:
------

1. within the class to refer current object python provides an implicit variable which is nothing but self .
2.self variable always pointing to current object.
3. self variable is the first argument for constructor and instance methods.
4. by using we can declare instance variables.
5. we can use self within the class only and from outside of the class we cannot use . 
6.at the time of calling constructor and instance methods we are not required to provide value for self variable. 
PVM(python vertual machine) itself is responsible to provide value.

implicit variable which is always pointing to current object.

** for every instance method and constructor the first argument should be self.


               method                               |                  constructor

1. method name can be anything                               1. should be __init__(self)
2.methods are required to call explicitly                    2. constructors are not required to call explicitly.
3. per object method can be called any number of times.      3. only once .
4. we can write businesss logic                              4. we have to declare and initialize instance variables.



operations/methods:
-------------------
1.instance method/object related methods.
2.static method.
3.class method.

variables/properties:
---------------------
1. instance variable/object level variables.

2. static variable/class level variables.
3.local variable/method variables.


function vs  method:
--------------------
functions which are declared outside of the class : functions 
functions which are declared inside of the class : methods 


''' this is document for detailed '''

if we want to display the document in output we can use <print(classname.__doc__)> or help(classname)

