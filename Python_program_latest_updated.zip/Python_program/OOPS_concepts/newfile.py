str="appartment=In my appartment 30 plots are avaiable ,floors=Entire apartment we have a six floors are there, rooms=each floor contain a 6 rooms"
lst=[]
for x in str.split(","):
     y=x.split("=")
     lst.append(y)
d=dict(lst)
for k,v in d.items():
     print('{} ==>  {}'.format(k,v))