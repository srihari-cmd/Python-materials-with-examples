def check(list1):
    for i in list1:
        try:
            print (i)
        except:
            pass
        

check([1,2,"sdkjfd","sdf",3,4,5])