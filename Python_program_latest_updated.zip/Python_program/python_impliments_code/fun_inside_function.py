how to call the function inn another function using classs 

class abc():
    def a(self):
        a = "123.txt"
        #print("hello world")
        return a
    def b(self):
        inst = abc.a(self)
        print(inst)
       
       
c=abc()
c.b()
    