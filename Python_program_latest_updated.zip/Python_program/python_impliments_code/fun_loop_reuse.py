def check(a,b,c):
    for i in range(a,b):
        k=i+c
        print("the i value is ",i,"and current value is ",k)
        
        
        
        
check(1,5,1)
print ("*************")
check(1,5,2)
print ("*************")
check(1,5,3)
print ("*************")
check(1,5,2)
        