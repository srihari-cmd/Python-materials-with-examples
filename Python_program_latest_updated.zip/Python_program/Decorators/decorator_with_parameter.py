#decorators with parameters
# we can change the behaviour of the existing function at the compile time itself using decorator.

def outer(expr):   
    def upper_d(func):
        def inner():
            return func() + expr
        return inner
    return upper_d

@outer("srihari")
def ordinary():
    return "good morning "


print(ordinary())