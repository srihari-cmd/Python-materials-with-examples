#with using the decorator function
#one method
def decor(satish):
    def inner(name):
        if name=="sreekanth":
            print("hello "+name+" bad morning")
        else:
            satish(name)
    return inner
@decor
def wish(name):
    print("hello "+name+" good morning")
wish("satish")
wish("sreekanth")
wish("shankar")
wish("rajesh")

print("######################################################")
#second method
def rajesh(func):
    def innerdecor(r):
        if r=="shankar":
            print("how "+r+"are you bro")
        else:
            func(r)
    return innerdecor
@rajesh
def satish(name):
   print("hello "+name+" are you")
satish("rajesh")
satish("shankar")
satish("gowtham")
satish("sriram")

print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

#with out decorator
def decor(func):
    def inner(satish):
        if satish=="rajesh":
            print("hello rajesh bad morning ")
        else:
            func(satish)
    return inner
def wish(name):
    print("hello "+name+" good morning")

withoutdecor=decor(wish)
withoutdecor("rajesh")
wish("rajesh")
#another example
print("######################################################@@@@@@@@@@@@@@@@@@@@@@@")
def smartdivision(func):
    def inner(x, y):
        if y == 0:
            print("hello stupid")
            # return
        else:
            return func(x, y)
    return inner
@smartdivision
def division(a, b):
    return a / b
print(division(10, 2))
print(division(10, 0))
print(division(10, 5))