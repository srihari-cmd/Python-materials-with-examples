# using ordereddict module we can sort the dictionary
# exple 1

from collections import OrderedDict
dict = {'rams': '10', 'raghu': '9', 'snantanu': '15', 'sri': '2', 'ssrikanth': '32'}
dict1 = OrderedDict(sorted(dict.items()))
print(dict1)

# exple 2

from collections import OrderedDict

dict1 = {"A":1,"C":3,"D":4,"B":2}
dict2 = OrderedDict(sorted(dict1.items()))
print(dict2)






