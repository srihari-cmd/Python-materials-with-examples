from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# driver = webdriver.Chrome()
driver = webdriver.Chrome(executable_path=r"C:\chromedriver_win32\chromedriver.exe")
driver.maximize_window()
wait = WebDriverWait(driver, 10)
driver.implicitly_wait(20)
driver.implicitly_wait(10)
#print(dir(wait))
driver.get("http://selenium-python.readthedocs.io/waits.html")
r = wait.until(EC.element_to_be_clickable((By.XPATH, 'html/body/div[1]/div[2]/div/ul/li[1]/aa')))
print(dir(r))
driver.find_element_by_xpath('html/body/div[1]/div[2]/div/ul/li[1]/a').click()

