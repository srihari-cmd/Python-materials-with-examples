from selenium import webdriver
from time import sleep

driver = webdriver.Chrome()
driver.get("http://www.teachmeselenium.com/automation-practice")
driver.maximize_window()

#Click on the link
driver.find_element_by_link_text("Click Me to get Alert").click()
sleep(3)

#Switch to alert window
alert = driver.switch_to.alert

#Get Text
print(alert.text)
sleep(5)

# Accept Alert
alert.accept()

# Dismiss Alert
# alert.dismiss()
