import os
from selenium import webdriver
import time
# import sele_refer as refer

DOWNLOADS_XP = '//*[@id="downloads"]/a'
ABOUT_XP = '//*[@id="about"]/a'

try:
    driver = webdriver.Chrome()
    
    driver.maximize_window()
    driver.get("https://www.python.org/")

    # about_elem = driver.find_element_by_xpath(refer.ABOUT_XP)
    about_elem = driver.find_element_by_xpath(ABOUT_XP)
    about_elem.click()
    driver.save_screenshot('C:\Selenium_Scripts\seleniumdocumentation\screens\about121.png')
    driver.back()

    # downloads_elem = driver.find_element_by_xpath(refer.DOWNLOADS_XP)
    downloads_elem = driver.find_element_by_xpath(DOWNLOADS_XP)
    downloads_elem.click()
    driver.save_screenshot('C:\Selenium_Scripts\seleniumdocumentation\screens\downloads131.png')
    driver.back()
except Exception as e:
    print("Exception while executing script. %s"%e)
finally:
    driver.quit()
