from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time

driver = webdriver.Firefox()
driver.maximize_window()
driver.get("http://selenium-python.readthedocs.io/")

## Move cursor on specified element and click
obj = driver.find_element_by_xpath('//li/a[contains(text(),"2.2")]')
time.sleep(3)
actions = ActionChains(driver)
actions.move_to_element(obj)
time.sleep(3)
actions.double_click()
time.sleep(3)
actions.perform()




