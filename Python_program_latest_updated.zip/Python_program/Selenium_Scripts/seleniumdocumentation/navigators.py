from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time


driver = webdriver.Chrome()

driver.maximize_window()
driver.get("http://selenium-python.readthedocs.io/")

## Move cursor on specified element and click
actions = ActionChains(driver)
obj = driver.find_element_by_xpath('//li/a[contains(text(),"2.2")]')
actions.move_to_element(obj)
time.sleep(3)
actions.double_click()
actions.perform()
time.sleep(5)
driver.back()
time.sleep(5)
driver.forward()


