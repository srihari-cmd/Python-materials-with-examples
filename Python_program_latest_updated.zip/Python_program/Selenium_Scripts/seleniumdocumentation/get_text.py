from selenium import webdriver
import time

# Open Chrome Browser
driver = webdriver.Chrome()
driver.get("http://selenium-python.readthedocs.io/")

## Get text based on xpath
value = driver.find_element_by_xpath('/html/body/div[1]/div[2]/div/h3').text

print('\n Text is :', value)

# Verify text is expected or not 
assert 'Navigation' == value , ' Not exist'




driver.close()


