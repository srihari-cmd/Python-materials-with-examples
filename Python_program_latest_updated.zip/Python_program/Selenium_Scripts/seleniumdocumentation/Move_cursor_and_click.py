from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time

# Chrome driver path
# cdriver = r"C:\SELENIUM\Drivers\V_36\chromedriver.exe"

#driver = webdriver.Chrome(cdriver)
driver = webdriver.Chrome()
driver.maximize_window()
driver.get("http://selenium-python.readthedocs.io/")


## Move cursor on specified element and click
actions = ActionChains(driver)
obj = driver.find_element_by_xpath('//li/a[contains(text(),"2.2")]')
time.sleep(3)
actions.move_to_element(obj)
time.sleep(3)
actions.click()
actions.perform()
# driver.close()
