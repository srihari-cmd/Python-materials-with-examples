from selenium import webdriver
from selenium.webdriver.support.ui import Select

driver = webdriver.Chrome()

driver.get('https://www.facebook.com/')

driver.maximize_window()
select1 = driver.find_element_by_id('u_0_2')
select1.click()
select2 = driver.find_element_by_id('day')
dropdown = Select(select2)

dropdown.select_by_value('13')

