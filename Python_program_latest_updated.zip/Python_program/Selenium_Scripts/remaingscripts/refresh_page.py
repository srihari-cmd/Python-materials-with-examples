from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time

#cdriver = r"C:\Others\Sriram_NOTE_Oct13_2017\INSTITUTE\PYTHONHUB_COURSES\SELENIUM\Drivers\V_36\chromedriver.exe"
driver = webdriver.Chrome()

print(dir(driver))
# driver.maximize_window()
# driver.get("http://selenium-python.readthedocs.io/")


# Move cursor on specified element and click
# actions = ActionChains(driver)
# obj = driver.find_element_by_xpath('//li/a[contains(text(),"2.2")]')
# actions.move_to_element(obj)
# time.sleep(3)
# actions.double_click()
# actions.perform()
# time.sleep(3)
# driver.refresh()


