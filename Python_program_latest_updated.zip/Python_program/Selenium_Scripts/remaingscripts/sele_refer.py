DOWNLOADS_XP = '//*[@id="downloads"]/a'
ABOUT_XP = '//*[@id="about"]/a'