from selenium import webdriver
import time

# Open chrome browswer
# d = webdriver.Chrome()
d = webdriver.Chrome(executable_path=r"C:\chromedriver_win32\chromedriver.exe")
d.maximize_window()

# Open url
d.get("https://www.python.org/")
time.sleep(5)

## Open a new tab with given URL
d.execute_script("window.open('http://robotframework.org/')")
time.sleep(5)

## Open a second tab with given URL
d.execute_script("window.open('https://mail.google.com')")
time.sleep(5)

#### To get all windows tabs
windows = d.window_handles
print('\n windows', windows)
print('\n Default tab title :', d.title)
time.sleep(5)

## Switch into first tab from right side 
d.switch_to.window(windows[1])
time.sleep(5)
print('\n second tab title 1', d.title)

## Switch into second tab from right side 
d.switch_to.window(d.window_handles[2])
time.sleep(5)
print('\n Third tab title 2', d.title)

## Switch into first tab(Default tab) from left side
d.switch_to.window(windows[0])
#d.switch_to_default_content()
time.sleep(5)
print('\n Default tab title : ', d.title)

