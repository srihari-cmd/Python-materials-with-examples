from selenium import webdriver 
import time
driver = webdriver.Chrome()
time.sleep(3)
driver.maximize_window()
time.sleep(3)

driver.get('https://accounts.google.com/')
time.sleep(3)

uname = driver.find_element_by_id('identifierId')
uname.send_keys('ssramchowdary@gmail.com')
time.sleep(2)
driver.find_element_by_xpath('//*[@id="identifierNext"]/content/span').click()
time.sleep(5)
driver.find_element_by_name('password').send_keys('password')
time.sleep(5)
driver.find_element_by_xpath('//*[@id="passwordNext"]/content').click()
driver.close()

