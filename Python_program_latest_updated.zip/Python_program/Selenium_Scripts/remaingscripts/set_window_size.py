from selenium import webdriver
import time

#driver = webdriver.Firefox()
driver = webdriver.Chrome()

#Get window size
print(driver.get_window_size())
time.sleep(5)

# Resize the window to the screen width/height
driver.set_window_size(1000, 700)

time.sleep(5)
print(driver.get_window_size())

# Move the window to position x/y
driver.set_window_position(200, 200)
time.sleep(5)
print(driver.get_window_size())
driver.close()
