from selenium import webdriver
import time

# Open a Chrome Browser
d = webdriver.Chrome(executable_path=r"C:\chromedriver_win32\chromedriver.exe");
d.maximize_window()

d.get("https://www.citibank.co.in/ibank/login/IQPin1.jsp?dOfferCode=LOANONCRED")
time.sleep(5)

# Scroll down page
d.execute_script("window.scrollTo(0, 1000)")
time.sleep(3)
d.close()

