from selenium import webdriver
import time

# Open chrome browswer
# d = webdriver.Chrome()
d = webdriver.Chrome(executable_path=r"C:\chromedriver_win32\chromedriver.exe")
d.maximize_window()

# Open url
d.get("https://accounts.google.com/")

time.sleep(5)

# Open another Blank tab
d.execute_script("window.open('about:blank', 'tab2');")
time.sleep(3)

# Switch into another tab based on tab name
d.switch_to.window("tab2")
d.get('http://bings.com')
time.sleep(5)
#d.close()

