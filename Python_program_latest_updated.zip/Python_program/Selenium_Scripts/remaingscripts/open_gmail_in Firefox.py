from selenium import webdriver
import time

gmail    = 'pythonhub1@gmail.com'
password = 'pythonhub1!'
'
FF_driver = r'C:\Users\smellamp\Desktop\SRIRAM\INSTITUTION\COURSES\SELENIUM\Drivers\Firefox\geckodriver-v0.16.0-win64\geckodriver.exe'
url = 'https://accounts.google.com/'

# Open a Browser 
driver = webdriver.Firefox()
driver.get(url)
driver.maximize_window()
time.sleep(2)
# Enter email id based id 
driver.find_element_by_id('identifierId').send_keys(gmail)
time.sleep(5)

# To clear text box before enter data
driver.find_element_by_id('identifierId').clear()
driver.find_element_by_id('identifierId').send_keys(gmail)
time.sleep(5)

# Click on next button after entered email
driver.find_element_by_xpath('//*[@id="identifierNext"]/content').click()
time.sleep(3)

# Enter Password based on name
driver.find_element_by_name('password').send_keys(password)
time.sleep(3)

# Click Next button using xpath element after entered password
driver.find_element_by_xpath('//*[@id="passwordNext"]/content/span').click()

time.sleep(2)


# Close a browser
driver.close()

