from selenium import webdriver
import time

# Launch Firefox browser
d = webdriver.Firefox()

# Send URL
d.get('http://www.google.com/')

# Take screenshot
d.save_screenshot(r'C:\Users\smellamp\Desktop\screenie.png')

# Get Window Title
w_title = d.title
assert w_title == 'Google1' ,' Title is not matched'
time.sleep(5)
d.quit()

