from selenium import webdriver
import time

d = webdriver.Firefox()
d.get('http://www.google.com/')
d.maximize_window()
time.sleep(3)

# Take screenshot
d.save_screenshot(r'C:\Users\smellamp\Desktop\Django\SRIRAM.png')
d.close()