
def f1():
    print("This is from function f1 of python")

def f2():
    print("This is from function f2 of python")