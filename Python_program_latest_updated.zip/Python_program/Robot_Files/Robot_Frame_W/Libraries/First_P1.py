def f1():
	print('the first result f1 is')
	# return 'the add function is displayed'
	return 3000
def f2():
	print('the second f2 result is ')