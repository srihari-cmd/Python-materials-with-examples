
# write a program to get common values from two lists?

l1 = [4,2,5,7,8]
l2 = [3,4,5,6]
l3 = []

def common_elements(list1,list2):

    for element in list1:
        if element in list2:
            l3.append(element)
    print(l3)
obj = common_elements(l1,l2)


# another way using set method

l1 = [4,2,5,7,8]
l2 = [3,4,5,6]
l3 = set(l1)
l4 = l3.intersection(l2)
print(list(l4))


# another way using list comprhention

l1 = [4,2,5,7,8]
l2 = [3,4,5,6]
l3 = [i for i in l1 if i in l2]
print(l3)
