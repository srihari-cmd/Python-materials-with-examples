# write a program to multiply the two lists.

foo=[1,2,3,4]
bar=[1,2,5,55]
l=list(map(lambda x,y:x*y,foo,bar))
print(l)


from operator import mul # import mul operator
a = [1,2,3,4]
b = [2,3,4,5]
c = list(map(mul,a,b))
print(c)


