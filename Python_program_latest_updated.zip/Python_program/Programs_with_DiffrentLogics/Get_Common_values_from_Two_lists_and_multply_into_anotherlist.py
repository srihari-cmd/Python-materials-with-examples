
# write a program to get common values from two lists and using common values to multiply another list

# one way

l1 = [2,4,5,78,56,34,17,7]
l2 = [45,23,34,56,98,2,13,7,17]
x = [3,5,7,9]
l3 = set(l1)
l4 = l3.intersection(l2)
l5 = list(l4)
print(l5)
l6 = [x[i] * l5[i] for i in range(len(x))]
print(l6)

# another way

l1 = [2,4,5,78,56,34,17,7]
l2 = [45,23,34,56,98,2,13,7,17]
x = [3,5,7,9]
l3 = [i for i in l1 if i in l2]
print(l3)
l4 = [x[i] * l3[i] for i in range(len(x))]
print(l4)



