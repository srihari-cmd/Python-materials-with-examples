
# using iterator function

l=[1,2,3,4]
i=iter(l)
print(next(i))
print(next(i))
print(next(i))
print(next(i))


l=[1,2,3,4]
i=iter(l)
for l in i:
    print(l)


# class remmote:
#     def __init__(self):
#         self.channels=["hbo","atv","data"]
#         self.index=-1
#     def __iter__(self):
#         return self
#     def next(self):
#         self.index+=1
#         if self.index==len(self.channels):
#             raise StopIteration
#         return self.channels[self.index]
# r=remmote()
# i=iter(r)
# print(next(i))
# print(next(i))
# print(next(i))
# print(next(i))

