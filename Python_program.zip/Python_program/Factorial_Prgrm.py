
#Factorial program ex: 4! = 4*3*2*1 = 24

def factorial(n): 
      
    # single line to find factorial 
    return 1 if (n==1 or n==0) else n * factorial(n - 1)  
  
# Driver Code 
num = int(input("enter the value :"))
print("Factorial of",num,"is", factorial(num)) 




def fact_num(n):
    return 1  if (n==1 or n==0) else n * fact_num(n-1)

num = int(input("enter the number is :"))
inst = fact_num(num)
print("Factorial of",num,"is",fact_num(inst))


