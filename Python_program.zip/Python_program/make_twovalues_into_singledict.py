# here we are making the dictionary using with two values

# one way

x = "abcd"
y = 0

z = dict.fromkeys(x,y)
print(z)

# another way

a = "abcd"
dict1 ={}
for i in a:
    # print(i)
    dict1[i]=0
print(dict1)


