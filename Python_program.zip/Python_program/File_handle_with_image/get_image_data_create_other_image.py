
fh = open("C:\\Users\\srihari.pampana\\Desktop\\Python_program\\File_handle_with_image\\calsoft.png","rb")

fh1 = open("C:\\Users\\srihari.pampana\\Desktop\\Python_program\\File_handle_with_image\\crated_image.png","wb")

for i in fh:
    fh1.write(i)
    
    
    