

def title_d(func):
    def inner():
        str2 = func()
        return str2.title()
    return inner

def upper_d(func):
    def inner1():
        str = func()
        return str.upper()
    return inner1

def split_d(func):
    def wrapper():
        str1 = func()
        return str1.split()
    return wrapper


@split_d
@upper_d
@title_d
def ordinary():
    return "good morning"
        
inst =ordinary()
print(inst)

