#Write a python program to print list of a number?
# list is mutable object

print("the list object is started with example  \n")

list=[1,2,3,4,5]
print(list)

list1=[1,2,3,4,5]
print(id(list1))
list1[0]='a'
print(list1)
print(id(list1))

print("the dict object is started with example \n")

dict = {"A":1,"B":2,"C":3}
print(dict)

dict1 = {"A":1,"B":2,"C":3}
print(id(dict1))
dict1["A"] = "srihari"
print(dict1)
print(id(dict1))

print("the set object is started with example \n")

set = {1,2,3,4,5}
print(set)

set1 = {1,2,3,4,5}
print(id(set1))
# set1[0] = "sri"
# print(set1)
# print(id(set1))


num=int(input("enter the number:"))
for i in range(2,num):
    if num%i==0:
        print(i)
    
    
 


