# using filter and lambda function filtering even number from list

num = [1,2,3,4,5,6,7,8,9,10]
even = list(filter(lambda n: n%2==0,num))
print(even)
