# The random() method returns a random floating number between 0 and 1.
# random() takes no arguments

import random

print(random.random())

