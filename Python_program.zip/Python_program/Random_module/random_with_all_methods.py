
import random

# to get the integer single value randomly 
# used randint

rd  = random.randint(0,3)
print(rd)

# to get the single value randomly from the list contain string values
# used choice

print("first")
list = ["srihari","ram","navami","happy","wish","you"]
rd1 = random.choice(list)
print(rd1)
print("second")
list = [2,3,4,5,7,8]
rd1 = random.choice(list)


# rd1 = random.choice(t)
print(rd1)


# used shuffle (re arrange the order of list/string/tuple)
# used shuffle

l = ["Apple","Banana","Cherry"]
random.shuffle(l)
print(l)
print("###################")
# s = "srihari"
# random.shuffle(s)
# print(s)

# used sample

l = ["Apple","Banana","Cherry"]

print(random.sample(l,k=2))

# used seed

random.seed(10)
print(random.random())

# used getstate

print(random.getstate())

# used setstate
# ********************************************

#print a random number:
print(random.random())

#capture the state:
state = random.getstate()

#print another random number:
print(random.random())

#restore the state:
random.setstate(state)

#and the next random number should be the same as when you captured the state:
print(random.random())

# used random
print(random.random())

