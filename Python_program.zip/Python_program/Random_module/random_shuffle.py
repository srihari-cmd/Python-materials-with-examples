# The shuffle() method takes a sequence (list, string, or tuple) and reorganize the order of the items.

import random 

# using list to shuffle the sequence

list1 = [1,2,3,4,5]
random.shuffle(list1)
print("the value for shuffle method is:",list1)


# using string to shuffle the sequence

str = "WELCOME"
print("Original String: ", str)
# convert string into list
char_list = list(str)
# shuffle list
random.shuffle(char_list)
# convert list to string
finalStr = ''.join(char_list)
print("shuffled String is: ", finalStr)


def myfunction():
  return 0.1

mylist = ["apple", "banana", "cherry"]
random.shuffle(mylist, myfunction)

print(mylist)

