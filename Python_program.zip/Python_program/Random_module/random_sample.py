# The sample() method returns a list with a randomly selection of a specified number of items from a sequnce
# syntax
# random.sample(sequence, k)


import random
# one way

mylist = ["apple", "banana", "cherry"]
print(random.sample(mylist, k=2))

# another way

values = "0123456789"
val_length = 5

var = random.sample(values,val_length)
print("the value for sample method is:",var)
