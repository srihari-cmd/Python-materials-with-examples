# The randint() method returns an integer number selected element from the specified range.
# syntax for randint 
# random.randint(start, stop)
 # This method is an alias for randrange(start, stop+1).

import random
str = 10
str1 = random.randint(0,str)
print("the value for random randint is:",str1)


str1 = 10
str2 = random.randrange(0,str1)
print("the value for random randrange is:",str2)



str2 = random.randrange(0,8)
print("the value for random randrange is:",str2)


