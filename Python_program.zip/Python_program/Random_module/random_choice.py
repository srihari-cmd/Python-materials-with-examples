
# The choice() method returns a randomly selected element from the specified sequence.
# The sequence can be a string, a range, a list, a tuple or any other kind of sequence.
# syntax:
# random.choice(sequence)

import random

# one way for example

list1 = ["haii","hello","apple", "banana", "cherry","how","are","you"] 

list2 = random.choice(list1)
print("the random choice value is:",list2)

# second way for example
# using string

str = "WELCOME"
str1 = random.choice(str)
print("the random choice value is:",str1)

# third way for example
# using list

values = ["apple", "banana", "cherry"]
def exm_fun(arg):
    str = random.choice(values)
    print("the value form random choice is:",str)
    

inst = exm_fun(values)

#fourth way for example

# using tuple

tuple1 = ("apple", "banana", "cherry","mango","grapes",)
tuple2 = random.choice(tuple1)
print("the random choice value is:",tuple2)





