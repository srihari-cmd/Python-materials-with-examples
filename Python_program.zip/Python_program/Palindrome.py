
# palindrome program

str = input("enter the string:")
str1 = str[::-1]
if str==str1:
    print("given string is palindrome ")

else:
    print("given string is not palindrome")

print("test completed")

print("next program is fibbnocci")


num = int(input("enter the number:"))

x=0
y=1
count=0

if num<=0:
    print("please enter the positive integer ")

elif num==1:
    print("fibonacci sequence upto",num,":")
    print(x)

else:
    print("fibbnocci sequence is")
    while count<num:
        print(x)
        z=x+y
        x=y
        y=z
        count+=1
        
        
        
def cal_fac(n):
    return 1 if n==1 else n* cal_fac(n-1)
    

num = int(input("enter the number :"))

print("the factorial of",num,"is",cal_fac(num))





str = input("the string is :")

str1 = str.casefold()

count=0

list1 = ["a","e","i","o","u"]


for char in str1:
    if char in list1:
        print(char)
        count+=1
print("the total vowels count is :",count)




num=int(input("enter the number:"))
for i in range(2,num):
    if num%i == 0:
        print("its Not a prime number",num)
        break
else:
    print(" its a prime number",num)
    
    
    



