# here the string contain char with inordered
a_string = "cbfdsjhewhrfeida"
sorted_characters = sorted(a_string) #Sort string alphabetically and return list.
a_string = "".join(sorted_characters) #Combine list elements into one string.
print(a_string)


# here the list contain both char and digits 

list1 = ["b","c","a","f","d","2","4","5","1","3"]
list1.sort()
print(list1)

# here the list contain digits with inordered 

list2 = ["2","4","121","245","187","865","5","1","3"]
list2.sort(key=int)
print(list2)


# here the list contain char with inordered
l1 = ["B","A","D","C"]
l1.sort()
print(l1)



k  = ["232","123","1","4","3","2","543"]
k.sort(key=int)
print(k)


ls = ["12","3","2","1","5","432","234","65","532"]
ls.sort(key=int)
print(ls)



ls = ["F","E","A","C","B","G","X","W","D"]
ls.sort(key=str)
print(ls)


def fac_fun(n):
    return 1 if (n==0 or n==1) else n*fac_fun(n-1)
    
    
num = int(input("enter the value :"))
print("the factorail of",num,"is",fac_fun(num))



num =  int(input("enter the number:"))
x,y=0,1

count=0

if num<=0:
    print("please enter the positive integer")

elif num==1:
    print("fibonacci sequence upto",num,":")
    print(x)
    
else:
    print("fibonacci sequence")
    while count<num:
        print(x)
        z=x+y
        x=y
        y=z
        count+=1
        
        
sent = input("enter the sentance :")
str1 = sent.casefold()
print(str1)
count=0
list2 = ["a","e","i","o","u"]

for char in str1:
    if char in list2:
        count+=1
        
print("the sentance of vowel is",count)


l =['abc' , 'cd' , 'xy' , 'ba' , 'dc']
l.sort()
print(l)



















