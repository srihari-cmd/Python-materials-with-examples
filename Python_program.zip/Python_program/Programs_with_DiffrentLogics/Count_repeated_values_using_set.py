
l = [3,2,1,2,3,4,2,1,4]
l2 = [[x,l.count(x)] for x in set(l)]
print(l2)