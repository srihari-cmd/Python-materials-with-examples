

from collections import Counter

l1 = [1,2,1,1,3,4,3,5,6,7,7]
l2 = [9,2,4,6,9,7,6]
l1.extend(l2)
print(l1)
a = dict(Counter(l1))
print(a)




# from collections import Counter
# l1 = [1,2,3,2,1,2,1,"sri",5,7,7,5,"sri"]
# l2 = [8,"sri",9,8,"srihari",8,"srihari",9]
# l1.extend(l2)
# print(l1)
    
# a = Counter(l1)
# print(a)







print("*********************************************")

l1 = [1,2,1,1,3,4,3,5,6,7,7]
l2 = [9,2,4,6,9,7,6]
l1.extend(l2)
# print(l1)
l3 = {i:l1.count(i) for i in l1}

print(l3)
