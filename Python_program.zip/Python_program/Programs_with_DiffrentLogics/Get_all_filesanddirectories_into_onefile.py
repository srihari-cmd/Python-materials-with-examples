import os

list_all = os.listdir(r"C:\Users\srihari.pampana\Desktop\Python_program")
print(list_all)
fh  = open(r"C:\Users\srihari.pampana\Desktop\all_files_with_names.txt","w")
for i in list_all:
    data = fh.write(i) 


