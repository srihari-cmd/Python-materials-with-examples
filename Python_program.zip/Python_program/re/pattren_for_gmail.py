import re    
# here i am matching the pattren for gmail 

list2 = ["sriharip@gmail.com", "srihari.pampana13@gmail.com","psrihari.5889@gmail.com","rebalsrihari143@gmail.com"]

for i in list2:
    # r = re.findall(r"[\w.-]+@[\w.-]+",i)
    r = re.findall(r"[\w.-]+@[\w.-]+",i)
    print(r)


list2 = ["sriharip@gmail.com", "srihari.pampana13@gmail.com","psrihari.5889@gmail.com","rebalsrihari143@gmail.com"]

for i in list2:
    # r = re.findall(r"[\w.-]+@[\w.-]+",i)
    r = re.search(r"([\w.-]+)@([\w.-]+)",i)
    print(r.group(1))
    print(r.group(2))

