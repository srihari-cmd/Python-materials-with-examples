
# The format() method allows you to format selected parts of a string.
# ex:1

price = 49
txt = "The price is {} dollars"
print(txt.format(price))

# ex:2

price = 49
print("The price is {} dollars".format(price))
print("The price is {0} dollars".format(price))

# ex:3

quantity = 3
itemno = 567
price = 49
myorder = "I want {} pieces of item number {} for {:.2f} dollars."
print(myorder.format(quantity, itemno, price))


# ex:4

quantity = 3
itemno = 567
price = 49
myorder = "I want {0} pieces of item number {1} for {2:.2f} dollars."
print(myorder.format(quantity, itemno, price))




import platform

x = platform.system()
print(x)