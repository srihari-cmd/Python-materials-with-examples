import re

# match function is used to search the input string from the starting 
line = "pet:cat i love you"

found = re.match(r'pet:\w\w\w',line)
if found:
    print("found matched")
else:
    print("not found")


# match function is used to search the input string from the starting 

line = "i love pet:cat i love you"

found = re.match(r'pet:\w\w\w',line)
if found:
    print("found matched")
else:
    print("not found")


