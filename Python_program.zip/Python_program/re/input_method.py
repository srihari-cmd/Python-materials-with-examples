# Python 3.6 uses the input() method.

# Python 2.7 uses the raw_input() method.

#input method
# Python stops executing when it comes to the input() function, and continues when the user has given some input.

n = input("enter the username:")
print("the username is " + n)

