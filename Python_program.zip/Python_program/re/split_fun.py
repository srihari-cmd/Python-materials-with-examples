
import re

#split function is used to split from the input string where it exactly match the pattren.

line = "i love pet:cat i love you  pet:cat i have work pet:cat with one thing"

found2 = re.split(r'pet:\w\w\w',line)
print(found2)

if found2:
    print("found matched")
else:
    print("not found")
    
    
    

