# A set is a set of characters inside a pair of square brackets [] with a special meaning:

# ex :1 for [arn]
import re
import sys
txt = "The rain in Spain"

#Check if the string has any a, r, or n characters:

x = re.findall("[arn]", txt)

print(x)

if (x):
  print("Yes, there is at least one match!")
else:
  print("No match")

# ex:2 for [a-n]


txt = "The rain in Spain"

#Check if the string has any characters between a and n:

x = re.findall("[a-n]", txt)

print(x)

if (x):
  print("Yes, there is at least one match!")
else:
  print("No match")

# ex:3 for [^arn]

txt = "The rain in Spain"

#Check if the string has other characters than a, r, or n:

x = re.findall("[^arn]", txt)

print(x)

if (x):
  print("Yes, there is at least one match!")
else:
  print("No match")

# ex:4 for [0123]

txt = "The rain in Spain"

#Check if the string has any 0, 1, 2, or 3 digits:

x = re.findall("[0123]", txt)

print(x)

if (x):
  print("Yes, there is at least one match!")
else:
  print("No match")


# ex:5 for [0-9]

txt = "8 times before 11:45 AM"

#Check if the string has any digits:

x = re.findall("[0-9]", txt)

print(x)

if (x):
  print("Yes, there is at least one match!")
else:
  print("No match")

# ex:6 for [0-5][0-9]

txt = "8 times before 11:45 AM"

#Check if the string has any two-digit numbers, from 00 to 59:

x = re.findall("[0-5][0-9]", txt)

print(x)

if (x):
  print("Yes, there is at least one match!")
else:
  print("No match")

# ex:7 for [a-zA-Z]

txt = "8 times before 11:45 AM"

#Check if the string has any characters from a to z lower case, and A to Z upper case:

x = re.findall("[a-zA-Z]", txt)

print(x)

if (x):
  print("Yes, there is at least one match!")
else:
  print("No match")

# ex:8 for [+]
txt = "8 times before 11:45 AM"

#Check if the string has any + characters:

x = re.findall("[+]", txt)

print(x)

if (x):
  print("Yes, there is at least one match!")
else:
  print("No match")
  
# ex :9 for group


#Search for an upper case "S" character in the beginning of a word, and print the word:

txt = "The rain in Spain"
x = re.search(r"\bS\w+", txt)
print(x.group())


# ex:10 for max split


#Split the string at the first white-space character:

txt = "The rain in Spain"
x = re.split("\s", txt, 1)
print(x)




