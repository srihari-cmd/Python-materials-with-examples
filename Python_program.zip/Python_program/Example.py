'''
# 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values'

# d = {"A":1,"B":2,"C":3,"A":2}
# print(dir(d))
# print(d)


# d1 = {5,3,2,1,7,9}
# d2 = dict.fromkeys(d1)
# print(d2)


# import re 

# s1 = "SRIhaRI pampANa"
# small = re.findall('[a-z]',s1)
# print(small)

# capital = re.findall('[A-Z]',s1)
# print(capital)




# s1=  "hai hello how are you fioien ahdjs xjcxjfes jhasdskjcfsdf"
# s2 = s1.split()
# print(len(s2))


# s1=  "jhasdskjcfsdf"
# s2 = s1.split()
# print(len(s1))

# s2 = {i:s1.count(i) for i in s1}
# print(s2)



# s = "1234" 
# print(type(s))

# s1 = int(s)
# print(type(s1))
# print(s1)


# functions 

# Python program showing 
import re
fh = open("hari123.txt","r")
data = fh.read()
str = re.findall("error",data)
print(str)    
print(len(str))    
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")        

lambda a,b: a+b
obj = lambda a,b: a+b
print(obj(2,3))
print("###############################")
str = "hello world"
str1 = re.match("hello",str)
print(str1.group())

print("*******************************")
import re
str = "hello world"
str1 = re.search("world",str)
print(str1.group())
print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")

d1 = "abcd"
d2 = {}
for i in d1:
    d2[i]=0
print(d2)


import copy

x= [[1,2,3],[4,5,6],[7,8,9]]
y = copy.deepcopy(x)
# y[0] = ["a","b","c"]
y[0][2] = "c"

print("deepcopy---------------------")
print("the old value is :",x)
print("the new value is :",y)


x1 = [[9,8,7],[6,5,4],[3,2,1]]

y1 = copy.copy(x1)

# y1[0] = ["a","b","c"]
y1[0][2] = "c"
print("shallow copy------------------")
print("the old values are :",x1)
print("the new values are :",y1)


# Aditi Shukla To Everyone3:20:19 PM
# str1 = re.match("hello",str)
# print(str1.group())
    
print("@@@@@@@@@@@@@@@@@@@@@@@@@@@")

import copy 

t1 = [[1,2,3],[4,5,6],[7,8,9]]

t2 = copy.deepcopy(t1)
t2[0] = ["sri","hari","pampana"] 
# t2[0][2] = "sri" 
print("deepcopy------------")
print("the older value is:",t1)
print("the older value is:",t2)

t1 = [[1,2,3],[4,5,6],[7,8,9]]

t2 = copy.copy(t1)
t2[0] = ["sri","hari","pampana"]
# t2[0][2] = "sri" 
print("shallowcopy------------")
print("the older value is:",t1)
print("the older value is:",t2)
'''



'''
# from collections import Counter
# l1 = [1,2,3,2,1,2,1,"sri",5,7,7,5,"sri"]
# l2 = [8,"sri",9,8,"srihari",8,"srihari",9]
# l1.extend(l2)
# print(l1)
    
# a = Counter(l1)
# print(a)

# print("*********************************************")

# l1 = [1,2,3,2,1,2,1,"sri",5,7,7,5,"sri"]
# l2 = [8,"sri",9,8,"srihari",8,"srihari",9]
# l1.extend(l2)
# print(l1)
# l3 = {i:l1.count(i) for i in l1}

# print(l3)
# print("###################################################")

# l = [3,2,1,2,3,4,2,1,4]
# l2 = [[x,l.count(x)] for x in set(l)]
# print(l2)

# from collections import Counter

# list1 = [2,3,4,2,1,2,2,1,3,4,3,4,3]
# list2 = dict(Counter(list1))
# print(list2)


# list3 = {i:list1.count(i) for i in list1}
# list3 = [[i,list1.count(i)] for i in set(list1)]
# print(list3)




from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains

    
url = "https://opensource-demo.orangehrmlive.com/"
name = "Admin"
pwd = "admin123"


class Login:
    def __init__(self,url,name,pwd):
        self.url = url
        self.name = name
        self.pwd = pwd
    
    def Login_page(self):        
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        self.driver.get(url)
        # self.driver.get_text()
        msg = self.driver.title
        print(msg) 
        assert "OrangeHRM" == msg,"the message is not matched"
        self.driver.find_element_by_id("txtUsername").send_keys(name)
        self.driver.find_element_by_id("txtPassword").send_keys(pwd)
        self.driver.find_element_by_id("btnLogin").click()
    
    
    def Logout_page(self):
        time.sleep(4)
        self.driver.find_element_by_id("welcome").click()        
        time.sleep(2)
        self.driver.find_element_by_link_text("Logout").click()
        # self.driver.close()
        
obj = Login(url,name,pwd)
obj.Login_page()
obj.Logout_page()
''url2 = 'https://www.facebook.com/'
url3 = 'https://www.python.org/'

driver = webdriver.Chrome()
# driver.get("http://selenium-python.readthedocs.io/")
driver.get("http://www.teachmeselenium.com/automation-practice")
driver.maximize_window()
time.sleep(3)
d1 = driver.title
print("the title is",d1)
# assert  d1 == "OrangeHRM","not matched"

# double click

# obj = driver.find_element_by_xpath('//li/a[contains(text(),"7.2.")]')
# time.sleep(3)
# actions = ActionChains(driver)
# actions.move_to_element(obj)
# time.sleep(3)
# actions.double_click()
# time.sleep(3)
# actions.perform()

# ActionChains(driver).move_to_element(obj).perform()


driver.find_element_by_link_text("Click Me to get Alert").click()
time.sleep(3)
alert = driver.switch_to.alert

print(alert.text)
time.sleep(3)
# alert.accept()
alert.dismiss()

'''




fh = open("C:\\Users\\srihari.pampana\\Desktop\\test_file.txt","r")
data = fh.readlines()
print(data)
for i in data:
    fh2  = open("C:\\Users\\srihari.pampana\\Desktop\\test_file12.txt","w")
    w_data = fh2.write(i)
    # print(w_data)



