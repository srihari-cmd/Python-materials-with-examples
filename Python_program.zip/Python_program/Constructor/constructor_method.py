# constructor is a method .it can be used to intialize the values to the instance variables .

class Student:
    def __init__(self,name,id,location):
        self.name = name
        self.id = id
        self.location = location
    
    def stud_details(self):
         print("the student name is :",self.name)
         print("the student id is :",self.id)
         print("the student location is :",self.location)

    def all_details(self):
        print("{0} is a student his roll no is {1} and finally he is located from {2}".format(self.name,self.id,self.location))
        
s1 = Student("srihari pampana",588,"bengaluru")
s2 = Student("srihari rebal",5889,"mantralayam")
s1.stud_details()
s1.all_details()
s2.all_details()

      




      