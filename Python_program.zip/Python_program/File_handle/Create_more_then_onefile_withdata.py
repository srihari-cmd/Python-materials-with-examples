
with open(r"C:\Users\srihari.pampana\Desktop\onehello_world111.txt","w") as file1,open(r"C:\Users\srihari.pampana\Desktop\onehello_world222.txt","w") as file2, open(r"C:\Users\srihari.pampana\Desktop\onehello_world333.txt","w") as file3:
    data1 = file1.write("hello world")
    print(data1)
    data2 = file2.write("hello world2")
    print(data2)
    data3 = file3.write("hello world3")
    print(data3)
    
