
with open(r"C:\Users\srihari.pampana\Desktop\Python_program\File_handle\abc1.txt","w") as fh1,open(r"C:\Users\srihari.pampana\Desktop\Python_program\File_handle\abc2.txt","w") as fh2,open(r"C:\Users\srihari.pampana\Desktop\Python_program\File_handle\abc3.txt","w") as fh3:
    file1 = fh1.writelines(["hello world \n","very good \n"])
    file2 = fh2.writelines(["hello google \n","very nice \n"])
    file3 = fh3.writelines(["hello family \n","very well \n"])
    
