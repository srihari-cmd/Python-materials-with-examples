with open(r"C:\Users\srihari.pampana\Desktop\Python_program\File_handle\abc1.txt","r") as f1, open(r"C:\Users\srihari.pampana\Desktop\Python_program\File_handle\abc2.txt","r") as f2:
	line_file1 = f1.readlines()
	line_file2 = f2.readlines()
	print(line_file1)
	print(line_file2)