#fetching the last line of 10 char in file using index

fh = open("C:\\Users\\srihari.pampana\\Desktop\\Python_program\\demo1.txt","r")
position = fh.seek(0,0)
data = fh.readlines()
data1 = data[-1][-10:]
print(data1)