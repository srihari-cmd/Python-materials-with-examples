
fh = open("C:\\Users\\srihari.pampana\\Desktop\\Python_program\\demo.txt","r")
data = fh.read(5)
print("the data is :",data)

# Check current position
position = fh.tell()
print("Current file position : ", position)


#seek(0,0) --> means it will point out to the starting position of the charecter.
#seek(0,1) --> means 1 it will point out to the current position of the charecter.
#seek(0,2) --> means 2 it will point out to the last position of the charecter.



# Reposition pointer at the beginning once again
position = fh.seek(0, 0)
str = fh.read(5)
print("Again read String is : ", str)
# Close opend file
fh.close()


