
# Check current position
fh = open("C:\\Users\\srihari.pampana\\Desktop\\Python_program\\demo.txt","r")
data = fh.read(5)
print("the data is :",data)

# Check current position
position = fh.tell()
print("Current file position : ", position)
