
# try:
    # fh = open("C:\\Users\\srihari.pampana\\Desktop\\Python_program\\demo.txt","r")
    # print("the name of the file is :",fh.name)
    # print("the mode is :",fh.mode)
    # print("the status of file closed or not is :",fh.closed)
    # data = fh.readlines()
    # print("the data is :",data)

# except IOError:
    # print("Error: can\'t find file or read data")

# else:
    # print("read  content in the file successfully")
    # fh.close()
    
try:
    fh = open("C:\\Users\\srihari.pampana\\Desktop\\Python_program\\demo.txt","r")
    print("the name of the file is :",fh.name)
    print("the mode is :",fh.mode)
    print("the status of file closed or not is :",fh.closed)
    data = fh.read(1:10)
    print("the data is :",data)

except IOError:
    print("Error: can\'t find file or read data")

else:
    print("read  content in the file successfully")
    fh.close()
    