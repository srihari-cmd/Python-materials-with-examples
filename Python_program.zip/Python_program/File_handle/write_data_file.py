
fh = open("C:\\Users\\srihari.pampana\\Desktop\\Python_program\\demo1.txt","r")
data =  fh.read(5)
print(data)

position = fh.tell()
print("the pos is :",position)


position1 = fh.seek(0,2)
print("the pos is :",position1)
data1 = fh.read(5)
print(data1)

