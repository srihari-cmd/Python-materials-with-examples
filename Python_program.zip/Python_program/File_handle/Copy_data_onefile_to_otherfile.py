fh = open(r"C:\Users\srihari.pampana\Desktop\onehello_world.txt","r")
data  = fh.read()
print(data)

fh1 = open(r"C:\Users\srihari.pampana\Desktop\onehello_world1.txt","w")
data2 = fh1.writelines(data)
print(data2)




