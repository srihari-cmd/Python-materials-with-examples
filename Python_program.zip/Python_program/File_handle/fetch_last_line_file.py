#fetch last line from the file using index

fh = open("C:\\Users\\srihari.pampana\\Desktop\\Python_program\\demo1.txt","r")
data = fh.readlines()
data1 = data[-1]
print(data1)