
# count the indidual char for string

str = "Srihari in expertized in Selenium Python "

d = {c:str.count(c) for c in str}

print(' Characters count is :', d)




str1 = "dfkgslng srlselr swesrnkwenkkjv askdnekrjws sdjfwenrnwzxpak wmnewmencxcm werewnfls"

d2 = {c:str1.count(c) for c in str1}

print("Characters count is:",d2) 


s = "SrIHariAa PamPAna"

f = {c:s.count(c) for c in s}
print("********",f)


