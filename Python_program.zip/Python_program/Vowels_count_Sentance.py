# count the vowels in sentance

sentance = input("enter the sentance:")
string = sentance.casefold()
print(string)
count = 0
list1 = ["a","e","i","o","u"]
for char in string:
    if char in list1:
        count=count+1
print("number of vowels in given sentance is:",count)


