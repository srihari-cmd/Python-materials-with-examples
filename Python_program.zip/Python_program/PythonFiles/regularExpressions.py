#A RegEx, or Regular Expression, is a sequence of characters that forms a search pattern.
"""If zero or more characters at the beginning of string match the regular expression pattern, return a corresponding MatchObject instance. Return None if the string does not match the pattern; note that this is different from a zero-length match.

Note: If you want to locate a match anywhere in string, use search() instead.
"""
import re

line = "I think i understand regex think "
match_result =re.search('think',line)
if match_result:
    print(match_result)
else:
    print("no search found")

match_result =re.match('think',line)
print(match_result)
if match_result:
    print(match_result)
else:
    print("no match found")

#always use raw expression,as some expressions like '\t' can be converted
print('\tTab')
print(r'\tTab')                        #\n\t\s

# findIter

Textmessage = r"is everthing fine here"
pattern = re.compile(r"e")
matching_ones = pattern.finditer(Textmessage)
for match in matching_ones:
    print(match)

#for Regular Expressions uses a backslash like for '.' is a regular expression variable ,so for it use'\.'
Textmessage = r"is. everthing. fine. here."
pattern = re.compile(r".")
matching_ones = pattern.finditer(Textmessage)
for match in matching_ones:
    print(match)

Textmessage = r"is. everthing. fine. here."
pattern = re.compile(r"\.")
matching_ones = pattern.finditer(Textmessage)
for match in matching_ones:
    print(match)
print('*******************')
Textmessage = r"is. everthing. fine. here. 234-222-1234  123.323.1212"
pattern = re.compile(r"\d\d\d.\d\d\d.\d\d\d\d")
matching_ones = pattern.finditer(Textmessage)
for match in matching_ones:
    print(match)

print("Hello")

#The findall() function returns a list containing all matches.
str = "The rain in Spain"
x = re.findall("ai", str)
print(x)
#The findall() function returns a list containing all matches.

#The search() function searches the string for a match, and returns a Match object if there is a match.

#If there is more than one match, only the first occurrence of the match will be returned:
str = "The rain in Spain"
x = re.search("\s", str)

#namehsjnamehsjname

print("The first white-space character is located in position:", x.start())
#The search() function searches the string for a match, and returns a Match object if there is a match.
#The split() function returns a list where the string has been split at each match:
str = "The rain in Spain"
x = re.split("\s", str)
print(x)
#The split() function returns a list where the string has been split at each match:
#The sub() function replaces the matches with the text of your choice:
str = "The rain in Spain"
x = re.sub("\s", "9", str)
print(x)
#The sub() function replaces the matches with the text of your choice:
import re
# capture Grouping and Numbering
#single
Textmessage = r"haha hh hah has ha haa dad bad dab gag gab hasahs"         #hiraak1234hiraak(hiraak)(shruti)1234\1\2
pattern = re.compile(r"(\w+)a\1")
matching_ones = pattern.finditer(Textmessage)
for match in matching_ones:
    print(match)
#multiple numbering
pattern = re.compile(r"(\w+)a(\w+)a\1\2")
matching_ones = pattern.finditer(Textmessage)
for match in matching_ones:
    print(match)
print("Test Phase")
pattern = re.compile(r"(\w+)\1")
matching_ones = pattern.finditer(Textmessage)
for match in matching_ones:
    print(match)
"""group() returns the substring that was matched by the RE. start() and end() return the starting and ending index of the match. span() returns both start and end indexes in a single tuple. Since the match() method only checks if the RE matches at the start of a string, start() will always be zero. However, the search() method of patterns scans through the string, so the match may not start at zero in that case."""
p = re.compile('[a-z]+')
print(p.match(""))
m = p.match('tempo')
print(m)
print(m.end())
print(m.start())
print(m.span())
print(m.group())

line = """hello is this working hello
hello is this working hello
hello is this working hello
hello is this working hello
hello is this working hello"""
print(line)
match_result =re.findall('hello',line,re.MULTILINE)
print(match_result)
print(match_result.__len__())
# matching_ones =p.finditer(line)
# for match in matching_ones:
#     print(match)