# An exception can be defined as an abnormal condition in a program resulting in the disruption in the flow of the program
"""A list of common exceptions that can be thrown from a normal python program is given below.
ZeroDivisionError: Occurs when a number is divided by zero.
NameError: It occurs when a name is not found. It may be local or global.
IndentationError: If incorrect indentation is given.
IOError: It occurs when Input Output operation fails.
EOFError: It occurs when the end of the file is reached, and yet operations are being performed.
"""

#Without Exception Handling
#
# a = int(input("Enter a:"))
# b = int(input("Enter b:"))
# c = a / b
# print("a/b = %d" % c)
#
# # other code:
# print("please read me,please please please")
#
#
# try:
#     a = int(input("Enter a:"))
#     b = int(input("Enter b:"))
#     c = a/b
#     print("a/b = %d"%c)
# except ZeroDivisionError:
#     print("can't divide by zero")
# except Exception:
#     print("Exception Handled")
# else:
#     print("Hi I am else block")
# finally:
#     print("I will be finally done")
#

try:
        a=10/0
except (RuntimeError, TypeError, NameError,ZeroDivisionError):
    print("Arithmetic Exception")
else:
    print("Successfully Done")

try:
    age = int(input("Enter the age?"))
    if age < 18:
        raise ValueError
    else:
        print("the age is valid")
except ValueError:
    print("The age is not valid")

#Custom Exceptions
class ErrorInCode(Exception):
    def __init__(self, data):
        self.data = data

    def __str__(self):
        return repr(self.data)


try:
    raise ErrorInCode(2000)
except ErrorInCode as ae:
    print("Received error:", ae.data)