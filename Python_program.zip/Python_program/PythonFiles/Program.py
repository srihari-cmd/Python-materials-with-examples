import Authen
import datetime


class YourBank:
    name = ""

    def __init__(self):
        print("Your Bank Working")

    def request_Bank(self,object):
        print("Amazon is requesting for a transaction of ",object.getAmazonRequest()[1])
        authentic_passcode = input("Please Authenticate")
        if authentic_passcode in object.OTP:
            print("user is validated,Transaction successful")
        else:
            raise Exception("Invalid OTP")






class Amazon:
    Authentic = False
    OTP = ["arun","swapnika","hirak","ajay","sanju","hari","satya","anant"]
    def __init__(self, name, password,prime_validity):
        self.name = name
        self.prime_validity = prime_validity
        if Authen.passwordValidate(password):
            self.Authentic = True
            print("User Authenticated")
        else:
            raise Exception("invalid credentials")

    def data_print(self):
        print(self.name)

    def getAmazonRequest(self):
        return Authen.display_list("Phone")

    def initialise_paymemt(self,Object):
        B1 = YourBank()
#        B1.name = Object.getAmazonRequest()
        B1.request_Bank(Object)
        return "success"

    def dispatch_action(self):
        if self.prime_validity:
            print("""Prime Membership is available,
picking the one day delivery for you.
Item will be delivered by """,datetime.datetime.today()+datetime.timedelta(days=1.00))
        else:
            print("""Not a Prime Member,
picking the normal delivery for you,
Item will be delivered by """,datetime.datetime.today()+datetime.timedelta(days=5.00))


class YourAmazonAccount:

    def get_primeValidity(self):
        return False

    def __init__(self, user_name, password):
        self.user_name = user_name
        A1 = Amazon(user_name, password,self.get_primeValidity())
        #Cart_Item = A1.getAmazonRequest()
        print(A1.initialise_paymemt(A1))
        print(A1.dispatch_action())


class YourAmazonPrimeAccount(YourAmazonAccount):

    def get_primeValidity(self):
        return True


Normal_User = YourAmazonAccount("John", "Ha1@dseg")
Prime_User = YourAmazonPrimeAccount("John", "Ha1@dseg")

# print(Normal_User.get_primeValidity())
# print(Prime_User.get_primeValidity())