"""
List is a collection which is ordered and changeable. Allows duplicate members.
Tuple is a collection which is ordered and unchangeable. Allows duplicate members.
Set is a collection which is unordered and unindexed. No duplicate members.
Dictionary is a collection which is unordered, changeable and indexed. No duplicate members.
"""

thislist = ["apple", "banana", "cherry"]
print(thislist)

thistuple = ("apple", "banana", "cherry")
print(thistuple)

thisset = {"apple", "banana", "cherry"}
print(thisset)


thisdict = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
print(thisdict)

#List is an ordered sequence of items. It is one of the most used datatype in Python and is very flexible. All the items in a list do not need to be of the same type.
a = [1, 2.2, 'python']
#looping through the list
for B in a:
    print(B)
#Accessing
thislist = ["apple", "banana", "cherry"]
print(thislist[1])
#change Item
thislist = ["apple", "banana", "cherry"]
thislist[1] = "blackcurrant"
print(thislist)
#cheking item
thislist = ["apple", "banana", "cherry"]
if "apple" in thislist:
  print("Yes, 'apple' is in the fruits list")
#append
thislist = ["apple", "banana", "cherry"]
thislist.append("orange")
print(thislist)
thislist = ["apple", "banana", "cherry"]
thislist.append(["orange","grape"])
print(thislist)
#extend
thislist = ["apple", "banana", "cherry"]
thislist.extend("mangoes")
print(thislist)
thislist = ["apple", "banana", "cherry"]
thislist.extend(["orange","grape"])
print(thislist)
#insert with index position
thislist = ["apple", "banana", "cherry"]
print(thislist)
thislist.insert(1, "orange")
print(thislist)
#copy
thislist = ["apple", "banana", "cherry"]
mylist = thislist.copy()
print(mylist)

#Tuple
t = (5,'program')
for B in t:
    print(B)
thistuple = ("apple", "banana", "cherry")
print(thistuple[1])

#let's try adding
# thistuple = ("apple", "banana", "cherry")
# thistuple[1] = "data"
#delete item in tuple
# thistuple = ("apple", "banana", "cherry")
# del thistuple
print(thistuple)
#Set
a = {5,2,3,1,4}
print(a)
print(a)
print(a)
print(a)
a = {"apple","banana","mangoes"}
print(a)
#access
thisset = {"apple", "banana", "cherry"}

for x in thisset:
  print(x)
thisset = {"apple", "banana", "cherry"}

print("banana" in thisset)
#Once a set is created, you cannot change its items, but you can add new items.
thisset = {"apple", "banana", "cherry"}

thisset.add("orange")

print(thisset)
thisset = {"apple", "banana", "cherry"}

thisset.update(["orange", "mango", "grapes"])
thisset.update(("ora", "man", "gra"))
thisset.update({"nge", "go", "pes"})
print(thisset)
#clear
thisset = {"apple", "banana", "cherry"}
thisset.clear()
print(thisset)
#set properties
#disjoint
x = {"apple", "banana", "cherry"}
y = {"google", "microsoft", "facebook"}

z = x.isdisjoint(y)

print(z)
#Union
x = {"apple", "banana", "cherry"}
y = {"google", "microsoft", "apple"}

z = x.union(y)

print(z)
#SuperSet
x = {"f", "e", "d", "c", "b", "a"}
y = {"a", "b", "c"}

z = x.issuperset(y)

print(z)



#set properties
#Dictionary

thisdict = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

print(thisdict.get("brand"))

# assigns keys with values fromkeys(keys,values)
x = ('key1', 'key2', 'key3')
y = 0

thisdict = dict.fromkeys(x, y)

print(thisdict)

# get(keyname,Value(optional))
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

x = car.get("name","user not exists")

print(x)

#keys
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

x = car.keys()

print(x)
#items
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

x = car.items()

print(x)
#values
car = {
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}

x = car.values()

print(x)

thisdict = {
  "brand": ["Ford","read","hallo"],
  "model": "Mustang",
  "year": 1964
}
print(thisdict)



#one example of combination
list1 = [1,2,3,4,5,6,1,2,3,4]
print(list1)
print(set(list1))
print(list(set(list1)))