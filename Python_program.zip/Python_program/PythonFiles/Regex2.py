#Regex Examples

import re

line = "I think i understand regex"

def reg(data,pattern):
    match_result = re.findall(pattern,data)
    if match_result:
        print(match_result)
    else:
        print("no search found")

reg(line,'think')
line = "regex is very powerful"
reg(line,'\\w')
reg(line,'\\w+')
reg(line,'\\s')
reg(line,r'\w')
print("check")
reg(line,r'\d')
print("check")
line = "name 25 +91-1234567890 1111.1111.1111"
reg(line,r'[A-Za-z]')
reg(line,r'[0-9]')
reg(line,r'\+\d+\-\d+')       #phone number fails
reg(line,r'\+\d\d\-\d\d\d\d\d\d\d\d\d\d')  #phone
reg(line,r'\+\d{2}-\d{10}')
reg(line,r'\W\d+\W\d+')
#10.0.0.23        192.168.11.211
line = "10.0.0.23"
print("ip address")
reg(line,r'\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}')
reg(line,r'[0-9]{1}[0-9]{0,1}[0-9]{0,1}.[0-9]{1}[0-9]{0,1}[0-9]{0,1}.[0-9]{1}[0-9]{0,1}[0-9]{0,1}.')