"""Python is a completely object-oriented language.
This approach towards programming seeks to treat data
and functions as part of a single unit called object.
The class defines attributes and the behaviour of the object,
while the object, on the other hand, represents the class."""
"""classes , ObjectsClass − A user-defined prototype for an object that defines a set of attributes that characterize any object of the class. The attributes are data members (class variables and instance variables) and methods, accessed via dot notation.
"""
#Class variable − A variable that is shared by all instances of a class. Class variables are defined within a class but outside any of the class's methods. Class variables are not used as frequently as instance variables are.

#creating Class
class Sample1:
    "this is a Test Class"
    access_count =0
    Name =""
    def __init__(self):                 #__init__
        print("activated")
        Sample1.access_count +=1

    def count(self):
        print(Sample1.access_count)

    def _hi(self, name, sal):
        self.__name = name  # private attribute
        self.__salary = sal  # private attribute
        self._read = "data"
        print(self.__name)
        print(self.__salary)

    def _greet(msg):

        _msg = msg

    print("Hello")

#class members:- Constructor,Instance Attributes,Class Attributes,Methods


s1 = Sample1()               #Anil
s2 = Sample1()
s3 = Sample1()
print(Sample1.access_count)

""" python :- name(public)
              _name(protected)
              __name(private)                                               
"""
s1._hi("Raj","1000")
s1._hi("Anil","4000")
s1._hi("Sanju","8000")


print(hasattr(s1,"access_count"))

print("checkpoint")
print(setattr(s1,"Name","hello"))
print("checkpoint")
print(getattr(s1,"Name"))
print("checkpoint")
delattr(s1, "_read")                      #deletes instances variables
print(hasattr(s1,"_read"))

print("checkpoint")


print(s2.__doc__)
print(s2.__dict__)
print(s2.__class__.__name__)
print(s2.__module__)
print(vars(Sample1))
print("end")




