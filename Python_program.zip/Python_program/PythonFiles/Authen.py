import re
Phone = ["Samsung", "Nokia", "LG", "Xioami", "Honor", "Realme", "Motorola"]
Samsung = ["Galaxy s10", "Galaxy s10e", "Galaxy s10+", "Galaxy Note10", "Galaxy Note10+"]
Realme = ["Realme2", "Realme2 Pro", "Realme3", "Realme3 Pro"]
Realme2 = ["Real me 2", "Rs 10000", "Black"]
GalaxyNote10 = ["Galaxy Note 10", "Rs 70000", "White"]


def display_list(ItemName):

    while ItemName !="":

        display_dict = {
            "Phone": Phone,
            "Samsung": Samsung,
            "Realme": Realme,
            "GalaxyNote10" : GalaxyNote10,
            "Realme2" : Realme2
        }
        if ItemName == "Buy" :
            return user_input
        else:
            user_input = display_dict.get(ItemName)
        input_data = "\n".join(display_dict.get(ItemName))
        ItemName = input(input_data+"\n")
#print(display_list("Phone"))


def passwordValidate(password):

    while True:
        if (len(password) < 8):
            return False
            break
        elif not re.search("[a-z]", password):
            return False
            break
        elif not re.search("[A-Z]", password):
            return False
            break
        elif not re.search("[0-9]", password):
            return False
            break
        elif not re.search("[_@$]", password):
            return False
            break
        elif re.search("\s", password):
            return False
            break
        else:
            return True
            break

