
d = {"A":1,"D":4,"C":3,"B":2}
# d1 = list(d)
d1 = d.keys()
print(sorted(d1))

# both are sorted using items 
d = {"A": 1, "D": 4, "C": 3, "B": 2}
# d1 = list(d)
d1 = d.items()
print(sorted(d1))


