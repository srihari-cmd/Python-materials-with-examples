
# here we are doing two dictionaries into one dictionary

#one way 

dict1={"Name":"rams","age":21}
dict2={"id":1234,"company":"calsoft"}

dict1.update(dict2)
print(dict1)

#another way

dict1={"Name":"rams","age":21}
dict2={"id":1234,"company":"calsoft"}
dict3={**dict1,**dict2}
dict4=list(dict3.items())
print(dict4)

