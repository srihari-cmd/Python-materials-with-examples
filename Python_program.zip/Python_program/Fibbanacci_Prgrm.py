#fibonnacci series
'''
x,y=0,1

num = int(input("enter the number :"))

while y<num:
    print(y)
    x,y = y,x+y


# second way for fibbonaci
print("the another way ")

# Program to display the Fibonacci sequence up to n-th term

nterms = int(input("How many terms? "))

# first two terms
n1, n2 = 0, 1
count = 0

# check if the number of terms is valid
if nterms <= 0:
   print("Please enter a positive integer")
elif nterms == 1:
   print("Fibonacci sequence upto",nterms,":")
   print(n1)
else:
   print("Fibonacci sequence:")
   while count < nterms:
       print(n1)
       nth = n1 + n2
       # update values
       n1 = n2
       n2 = nth
       count += 1

'''


num = int(input("enter the number:"))

x,y = 0,1
count=0

if num<=0:
    print("please enter a positive integer")

elif num ==1:
    print("Fibonacci sequence upto",num,":")
    print(x)
    
else:
    print("Fibonacci sequence:")
    while count<num:
        print(x)
        z=x+y
        x=y
        y=z
        count+=1
        







