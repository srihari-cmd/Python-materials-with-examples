# checking with if and else condition for vowels

ch = input("enter the char:")

if (ch=='A' or ch=='a' or ch=='E' or ch=='e' or ch=='I' or ch=='i' or ch=='O'
        or ch=='o' or ch=='U' or ch=='u'):
    print(ch ,"is vowel")
else:
    print(ch,"is a Consonant")
    
        