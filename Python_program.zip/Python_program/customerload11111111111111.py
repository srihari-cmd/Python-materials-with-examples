submain()
subinit()
subsetup()


def build_perl(self):
    #### Choose one of the production volume
    if(self.Params.get{'SHARED_OBJECTS'} and shared_vols)
         # each array element hold these infi # can be used as applicable
            # volume#node#aggregate#vserver
        #shared_vols =self.Params.get{'SHARED_OBJECTS'}
        temp =("#",shared_vols(random.shared_vols))
        input_agrs={'volume' :temp[0]
                    'vserver' :temp[1]}
        
        (vol_name,vol_node_obj,vol_aggr,data_vserver)=v.get_volume_info(**{input_agrs})
        self.Log.info("using shared volume "+ vol_name)
    elif (Params.get{'TEST_COMMON_VOL'} and Params.get{'TEST_COMMON_VOL'} and len(common_vol)):
        (self.vol_name,self.vol_node_obj,self.vol_aggr,self.data_vserver)=v.get_volume_info({volume : common_vol})
        self.Log.info("using shared volume "+ self.vol_name)
    
    else:
        (self.vol_name,self.vol_node_obj,self.vol_aggr,self.data_vserver)=v.get_volume_random({volinfo : vol_info})
         self.Log.info("using shared volume "+ vol_name)
    if not vol_name:
        return


    #### node_object
    Node =vol_node_obj
    vol_node =vol_node_obj.get(node())
    ## Pick a nfs client
    (self.nclient,self.mpt)=ClusterCommon::nfs_mount_reuse(Node,vol_name,vol_info)
    mpt= self.mpt +'/' +self.vol_name
    
    ## Error if no nfs clinet with mount
    
    if not nclient and mpt :
        return
    Client_obj =NACL::C::Client.new({name :nclient})
    self.Log.info("Selected nfs client -" nclient)
    self.Log.info("Mount point on nfs client is" mpt)
    ## Create testdir of some level deep
    testdir ='build_perl'
    testdir =testdir + '/' + ClusterCommon::generate_random_string(random.randint(20) + 1)
    input_agrs={ 'command_interface ':Client_obj,
                'path' :self.mpt +'/' +self.vol_name+'/'+self.testdir,
                'make-parents' : 1,
                'mode'  :'0777'}
    NACL::C::Client::FileDirOps.create_dir({**input_agrs})
    ## Copy perl.tar.gz to testdir
    input_agrs={ 'command_interface' : Client_obj,
                'path'         :FILE_DIR/PERL_FILE
                'dest' : self.mpt+'/'+self.vol_name+'/'+self.testdir,
                'force' :1,
                'recursive' : 1,
                'method-timeout'  : '3600'
                
    ## On client
    
    try:
        ## cd to dir
        Client_obj.apiset(interface :'CLI').cd(paths :self.mpt+'/'+self.vol_name+'/'+self.testdir)
      

        ## extract tar file
        Client_obj.apiset(interface :'CLI' .execute_raw_command({command : tar -xf +PERL_FILE ,
                                                                 'connectrec-timeout' : 3600})
        
         ## cd to dir
         
        Client_obj.apiset(interface :'CLI').cd({paths :self.mpt+'/'+ self.vol_name+'/'+self.testdir+'/'+self.PERL_DIR})
         
         
        ## run configure
        
        Client_obj.apiset(interface :'CLI' ).execute_raw_command({command :
             "./Configure -dse -Dprefix=$mpt/$vol_name/$testdir/$PERL_DIR >>$mpt/$vol_name/build_perl",###########
            'connectrec-timeout' : 2400})
            
        ## run make -ik
        Client_obj.apiset(interface : 'CLI').execute_raw_command({
                        command : make -ik '>>'self.mpt+'/'+self.vol_name+'/'+self.build_perl"
        
        ## run make install  
         Client_obj.apiset(interface : 'CLI').execute_raw_command({
                    command : make -ik install '>>'+self.mpt+'/'+self.vol_name+'/'+self.build_perl,
                    'connectrec-timeout' :2400})
    catch  NATE::BaseException with {
        excpn_obj =shift,
        self.Log.info("excpn - " + excpn_obj.text())
        return  # We cann't proceed on failure
        

    return True
    
   ## end sub build_perl

                        

def build_bash(): 
    build("build_bash", "bash-2.05b+tar.gz", "bash-2.05b")
    return True

def build_binutils():
    build("build_binutils", "binutils-2.14+tar.gz", "binutils-2.14")
    return True

def  build_bison(): 
    build("build_bison", "bison-1.875+tar.gz", "bison-1.875")
    return True


def  build_gcc(): 
    build("build_gcc", "gcc-3.0.4+tar.gz", "gcc-3.0.4")
    return True


def build_gettext(): 
    build("build_gettext", "gettext-0.11.5+tar.gz", "gettext-0.11.5")
    return True


def build_grep(): 
    build("build_grep", "grep-2.5+tar.gz", "grep-2.5")
    return True


def build_gzip()?: 
    build("build_gzip", "gzip-1.2.4a+tar.gz", "gzip-1.2.4a")
    return True


def build_id_utils(): 
     build("build_id_utils", "id-utils-3.2+tar.gz", "id-utils-3.2")
    return True


def build_m4() :
    build("build_m4", "m4-1.4+tar.gz", "m4-1.4")
    return $TCD::PASS;


def build_make(): 
    build("build_make", "make-3.79.1+tar.gz", "make-3.79.1")
    return True


def build_ncurses(): 
    build("build_ncurses", "ncurses-5.3+tar.gz", "ncurses-5.3")
    return True


def  build_samba(): 
    build("build_samba", "samba-2.2.8a+tar.gz", "samba-2.2.8a/source")
    return True


def build_screen(): 
    &build("build_screen", "screen-3.9.9+tar.gz", "screen-3.9.9")
    return True


def build_sed(): 
    build("build_sed", "sed-4.1.1+tar.gz", "sed-4.1.1")
    return True


def build_tar(): 
    build("build_tar", "tar-1.14+tar.gz", "tar-1.14")
    return True


def build_texinfo(): 
    build("build_texinfo", "texinfo-4+5.tar.gz", "texinfo-4.5")
    return True


def build (self): 
    #### Choose one of the production volume
    if (Params.get{'SHARED_OBJECTS'}
                and shared_vols) { 
        # each array element hold these infi # can be used as applicable
        # volume#node#aggregate#vserver
        #my @shared_vols  = @{$Params->{'SHARED_OBJECTS'}}
        my temp = ("#", shared_vols[random.shared_vols]).split('')

        (self.vol_name, self.vol_node_obj, self.vol_aggr, self.data_vserver)
             = v.get_volume_info(**{
                                      'volume' : self.temp[0], 
					                  'vserver' : self.temp[1]})
        self.log.info(" Using shared volume "+self.vol_name )
		
    elif (Params.get.[TEST_COMMON_VOL]
	
       and Params.get{'TEST_COMMON_VOL'} and len(common_vol)) {
	   
        (self.vol_name, self.vol_node_obj, self.vol_aggr, self.data_vserver)
             = v.get_volume_info({volume : self.common_vol})
        self.log.info(" Using commom volume"+ self.vol_name)
		
    else:
	
        (self.vol_name, self.vol_node_obj, self.vol_aggr, self.data_vserver)
             =v.get_volume_random(volinfo : vol_info)
        self.log.info(" Using random volume "+self.vol_name )
    }

    
	if not self.vol_name:
		return 

    #### node_object
    self.Node      = self.vol_node_obj[0]
    self.vol_node  = self.vol_node_obj.node()

    ## Pick a nfs client
    (self.nclient, self.mpt) = nfs_mount_reuse(sel,lf.Node, self.vol_name,vol_info)
    #$mpt = $mpt . '/' . $vol_name;

    ## Error if no nfs clinet with mount
    return 
    if not self.nclient or self.mpt
	
    self.Client_obj = Client.new({name : self.nclient})
    self.log.info("Selected nfs client -" self.nclient")
    self.log.info("Mount point on nfs client is" self.mpt)

    ## Create testdir of some level deep
    self.testdir = self.testdir +'/' +ClusterCommon::generate_random_string(int(rand(20)) + 1)
    NACL::C::Client::FileDirOps.create_dir(**{
        command_interface : self.Client_obj,
        path  : self.mpt+self.vol_name+self.testdir,
        'make-parents'   : 1,
        mode      : '0777'
    })

    ## Copy tar file to testdir
    NACL::C::Client::FileDirOps.copy(**
        'command_interface' : self.Client_obj,
        'path'              : "self.FILE_DIRself.tar",
        'dest'              : "self.mpt+self.vol_name+self.testdir",
        'force'             :1,
        'recursive'         : 1,
        'method-timeout'  : '3600'
    );

    ## On client
    try :
        ## cd to dir
        self.Client_obj.apiset({'interface' : 'CLI')
            .cd(paths => "self.mpt+"/"+self.vol_name+"/"+self.testdir")

        ## extract tar file
        self.Client_obj.apiset(interface = 'CLI').execute_raw_command(
            command   = "tar -vxf +self.tar",
            'connectrec-timeout' = 2400
        )

        ## cd to dir
        self.Client_obj.apiset(interface = 'CLI'})
            .cd(paths = "self.mpt+"/"+self.vol_name+"/"+self.testdir+"/"+self.wdir")

        ## run configure
        self.Client_obj.apiset(interface ='CLI').execute_raw_command(
            command ="./configure --prefix=self.mpt+"/"+self.vol_name+"/"+self.testdir+"/"+self.wdir >/dev/null",
            'connectrec-timeout' = 2400
        )

        ## run make -ik
        self.Client_obj.apiset(interface = 'CLI').execute_raw_command(
            command  = "make -ik >>/dev/null",
            'connectrec-timeout' = 2400
        )

        ## run make install
        self.Client_obj.apiset(interface ='CLI').execute_raw_command(
            command  = "make -ik install >>/dev/null",
            'connectrec-timeout' = 2400)
     except Exception  as e:
            self.log.info("Exception {}".format(e))
        self.log.warn("excpn - "+ self.excpn_obj.text());
        return True   # We cann't proceed on failure

    return True
	end sub build
	
	
	
def test_subrunner(self):

        self.log.info("In subrunner ")

        from collections import OrderedDict

        Testcases=OrderedDict()

        Testcases['inlinecomp_volmove_ondemand_snapshot']=TestInlinecomp_sisclone_snap_dedupe.inlinecomp_volmove_ondemand_snapshot

        Testcases['inlinecomp_volmove_sisclone_restore_volcone']=TestInlinecomp_sisclone_snap_dedupe.inlinecomp_volmove_sisclone_restore_volcone

        Testcases['inlinecomp_volmove_snapshot_snapmirror']=TestInlinecomp_sisclone_snap_dedupe.inlinecomp_volmove_snapshot_snapmirror

        No_of_wf = len(Testcases.keys())

        i = int(self.get_param(key='ITERATION',default = 1))

        stest = self.get_param(key='SUBTEST',default = 0)

        nos = int(self.get_param(key='TPARALLELISM',default = 3))

        if(No_of_wf < nos):

            nos=No_of_wf

        timeout = self.get_param(key='TIMEOUT',default = 3600)

        if (self.get_param(key='SHARED_OBJECT')):

            volume_obj = self.get_param(key='SHARED_OBJECT').split(",")

            volume = volume_obj[0]

            self.log.info("volume from shared object is :" + volume)

        if stest == "1" :

            while(i > 0):

                for key,value in Testcases.items():

                    self.log.info("Workflow invoked :" + key)

                    proc = NATEProcessFork(target=Testcases[key],runid=key,args=[self,])

                    proc.start()

                    while (proc.is_alive):

                        time.sleep(5)

                i = i - 1

        else:

            self.log.info("Running parallel")

            ctime = time.time()

            end_time = ctime+int(timeout)

            self.log.info("end time is :" + str(end_time))

            slots=[]

            cur_threads={}

            tobedel=[]

            while(time.time() < end_time):

                test=random.choice(list(Testcases.keys()))

                while (len(slots) < nos):

                    test=random.choice(list(Testcases.keys()))

                    if test not in slots :

                        self.log.info("Workflow invoked :" + test)

                        slots.append(test)

                        proc = NATEProcessFork(target=Testcases[test],runid=test,args=[self,])

                        proc.start()

                        cur_threads[test]=proc

                tobedel=[]

                for key,thread in cur_threads.items():

                    if not cur_threads[key].is_alive:

                        slots.remove(key)

                        tobedel.append(key)

                for k in tobedel:

                    del cur_threads[k]

            for kill,val in cur_threads.items():

                self.log.info("killing :" + str(kill))

                cur_threads[kill].terminate()

 
