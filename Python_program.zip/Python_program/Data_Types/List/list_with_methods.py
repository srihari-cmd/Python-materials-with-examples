
# here we are implimenting the list methods

# below are the methods for list

'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort'

list1 = [1,2,3,2,2,4,6,"sri","hari"] 

# print(dir(list1))

# list1.append("srinu")
# list1.extend([2,3,5,"pampana"])
# list1.clear()
# list2 = list1.copy()
# l2 = list1.count(2)
# list2= list1.index(2)
# list1.insert(1,"srihari")
# list1.pop()
# list1.pop(1)
# list1.remove(2)
# list1.reverse()
# list1.sort()
print(list1)

