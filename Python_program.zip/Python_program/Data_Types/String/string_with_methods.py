# here implimenting the string methods

# below are the string methods
'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 
'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 
'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 
'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 
'title', 'translate', 'upper', 'zfill'

string1 = " sriHAri PamPANa "
# print(dir(string1))

# string2 = string1.capitalize()
# string2 = string1.casefold()
# string2 = string1.count('a')
# string2 = string1.endswith('a')
# string2 = string1.startswith('s')
# string2 = string1.find('a')

# string1.index('2')
# string2 = string1.isdigit()
# string2 = string1.isalpha()
# string2 = string1.isdecimal()
# string2 = string1.islower()
# string2 = string1.isupper()
# string2 = string1.istitle()
# string2 = string1.lower()
# string2 = string1.upper()
# string2 = string1.lstrip()
# string2 = string1.rstrip()
# string2 = string1.strip()
# string2 = string1.replace("sri","sai")
# string2 = string1.split()
# string2 = string1.splitlines()
# string2 = string1.swapcase()
string2 = string1.title()

print(string2)