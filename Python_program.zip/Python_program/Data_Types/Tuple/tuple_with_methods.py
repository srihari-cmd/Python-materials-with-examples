# here implimenting the tuple methods

# below are the methods for tuple
'count', 'index'

t = (1,4,2,3,4,"sir")
# print(dir(tuple1))
# t1 = t.index(4)
t1 = t.count(4)

print(t1)
