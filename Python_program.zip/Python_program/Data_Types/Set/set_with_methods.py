# here implimenting the tuple methods

# below are the methods for tuple
'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 
'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 
'symmetric_difference_update', 'union', 'update'

s1 = {1,4,3,3,4,6,3,2}
# print(dir(s1))
s3 = {9,8,7}
# s1.add(13)
# s1.clear()
# s2 = s1.copy()
# s1.discard(6)
# s1.discard(6)
# s1.pop()
# s1.remove(6)
# s1.update(s3)
s1.update(s3)
print(s1)


x= {3,2,1,2}
y= {3,5,4}

# z = x.union(y)
z = x.intersection(y)
print(z)


x1 = {3,2,1,4}
print(id(x1))

# x1.add(12)
x1.discard(1)
print(id(x1))




