
# here implimenting the dictionary methods

# below are the methods for dictionary

'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values'

d1 = {"A": 1,"D": 4,"C": 3,"B": 2}
dc = {"E":5,"F":6}
# print(dir(d1))
# d1.clear()
# d2 = d1.copy()
# d2 = d1.get("C")
# d2 = d1.items()
# d2 = d1.keys()
# d2 = d1.values()
# d1.pop('C')
# d1.popitem()
# d2 = d1.setdefault("A","srihari")
# d1.update(dc)
d1.update(dc)
print(d1)


# it's for fromkeys()

a1 = {"A","B","C","D"}
a2 = "alpha"
d3 = dict.fromkeys(a1,a2)
print(d3)




