s = "hello"

print(s[::-1])

p = "prabhas"
p1 = ''.join(reversed(p))
print(p1)



def reverse_string_loop(original_string):
    reversed_string = ""
    for a in original_string:
        # appending characters in reverse
        reversed_string = a + reversed_string
    return reversed_string

original_string = "ABCDE"
print("Original String : ", original_string)
print("Reversed String : ", reverse_string_loop(original_string))


