class Arithematic:
    def __init__(self,a,b):
        self.a=a 
        self.b=b 
    def add(self,a,b):
        self.a=a 
        self.b=b 
        print("the sum of two numbers",a+b)
    def sub(self,a,b):
        self.a=a
        self.b=b 
        print("the sub of two numbers",a-b) 
c=Arithematic(10,20)
c.add(10,220)
c.sub(20,20)

print("@@@@@@@@@@@@@@@@@@@@@@@@@")

class Arithematic:
    def __init__(self,a,b):
        self.a=a 
        self.b=b 
    def add(self):
        print("the sum of two numbers",self.a+self.b)
    def sub(self): 
        print("the sub of two numbers",self.a - self.b)
        print("the sub of two numbers",self.a, self.b)
        
c=Arithematic(10,20)
c.add()
c1=Arithematic(20,20)
c1.sub()



