#multilevel inheritance
class Animal:
    def eat(self):
        print("eating")
    def dog(self):
        print("chicken")
class srihari(Animal):
    def sweet(self):
        print("good taste")
    def hot(self):
        print("it is very hot")
class rajesh(srihari):
    def good(self):
        print("good boy")
    def bad(self):
        print("bad boy")
c=rajesh()
c.good()
c.bad()
c.eat()
c.dog()
c.sweet()
c.hot()
