class Father:
    def __init__(self,Name,age,id,mail):
        self.Name= Name
        self.age= age
        self.id= id
        self.mail= mail
    def display(self):
        print("Name is :{}\nage is :{}\nid is :{}\nmail id is :{}\n".format(self.Name,self.age,self.id,self.mail))


cl = Father("srihari pampana",28,5889,"sriharip588@gmail.com")
cl.display()



