
var = int(input("please enter the age :"))

def check_age(n):
    if var>=18:
        print("Allowed to Vote")
    
    elif var<0:
        print("Please enter the positive integer")
    
    else:  
        print("not Allowed to Vote")
        
inst = check_age(var)
