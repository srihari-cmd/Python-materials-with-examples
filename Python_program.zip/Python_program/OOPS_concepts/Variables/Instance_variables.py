
# instance variable is nothing but object level variable

class Student:
    def __init__(self,name,age):
        self.name = name                   # instance variable is start with self.name ,self.age
        self.age = age
        
    def display_details(self):
        print("the student name is :",self.name)
        print("the student age is :",self.age)
    
s1 = Student("srihari",29)
s1.display_details()
        
        