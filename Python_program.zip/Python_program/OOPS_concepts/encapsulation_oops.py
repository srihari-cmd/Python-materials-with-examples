# encapsulation is warpping data or functionallity (methods accessing data) together into a single unit. 
# giving protection to the class or class members .using access specifiers /modifiers we can achive it.

class Robot(object):
    def __init__(self):
        self.a = 123
        self._b = 123
        self.__c = 123
    
    def fetch_private(self):
        print("the private value is :",obj.__c)
    

obj = Robot()
print(obj.a)
print(obj._b)
obj.fetch_private()

# print(obj.__c)


print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")

class Robot(object):
   def __init__(self):
      self.__version = 22

   def getVersion(self):
      print(self.__version)

   def setVersion(self, version):
      self.__version = version

obj = Robot()
obj.getVersion()
obj.setVersion(23)
obj.getVersion()
print(obj.__version)

