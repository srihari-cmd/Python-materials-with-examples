

# this is how will work for method overloading . python doesn't support for overloading.

class Student:
    def __init__(self,a=None,b=None,c=None):
        self.a=a
        self.b=b
        self.c=c
    
    
    def sum(self):
        s = 0
        if self.a!=None and self.b!=None and self.c!=None:
            s = self.a+self.b+self.c
        elif self.a!=None and self.b!=None:
            s = self.a+self.b
        else:
            s = self.a
        
        return s
        

s1 = Student(53)
print(s1.sum())
