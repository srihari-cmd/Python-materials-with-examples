
#this is for method overloading 

class A():
    def add(self,a):
        print("the a value is:",a)
class B(A):
    def add(self,a):
        print("the a value is :",a+10)
class C(B):
    def add1(self,a):
        print("the a value is: ",a*4)


inst = C()
inst.add(6)