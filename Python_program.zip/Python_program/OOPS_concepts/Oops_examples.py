# a python is an ooplanguage you can easily create and user class and objects
# major priciples of the oop is given below
# object
# class
# method
# inheritance
# polymorphism
# data abstraction
# encapsulation


# Object:an object is an entity that states and behaviour it may be anything it may be logical and physical things  for example mouse,keyboard,bench
# class:
# a class is collection of objects it may be the logical thing and it specifices the methods and abbritures it it as an logical entity for example you have the employee is a class and it specifiecs tthe methods and varriables in 
# method:
# a method is a function that is associated with an object.method is not unique of the class any object type of the methods.
# inheritance:
# inheritance is a feature of the oop it has to be the a queuing the all properties and behaviour to parent object.by using inheritnce you can defined 
# the neew class little or no changes in the existing class the new class is know as child class or derived class and from which inherits program is 
# properties is called is base class or derived class

# polymorphism:
# polymorphism is made by two words means the poly and morphism .poly means many and phism mean forms the for example take one task can be performed by 
# different ways. for example class is animal and but they talk differently ere talk is polymophic in the sense and totally depends on the animal.so 
# the abstact "animal" concept does not acutally talk but specific animal like have concrete implementation of the action talk

# encapsulation:
# encapsulation is also the feature of the opp it is used to restrict access the methods and variables the in encapsulation code
# and data wrapper into the single unit from being modified by acciedent 

# data abstraction:
# data abstraction and polymorphism both are often used the as synonyms. both are nearly synonym because data abstraction is achieved through encapsulation
# abstraction is used to hide the functionalies and only show the functionalites  abstracting something means to give the names to things so that the name 
# captuerd the core  of what a function or whole program does.

#class
# class Myclass:
    # "this is javapoint"
    # a=10
    # def func(self):
        # print "hello javapoint"
# print Myclass.a
# print Myclass.func 
#create an object in python
# b=Myclass()
# print b
# b.func()
# print b.a

#class method
# class Arithematic:
    # def add(self,a,b):
        # self.a=a
        # self.b=b 
        # print "sum of two numbers",a+b 
    # def sub(self,a,b):
        # self.a=a 
        # self.b=b 
        # print "the sub of two numbers",a-b
# a=Arithematic()
# a.add(10,20)
# a.sub(30,30)
# class Arithematic:
    # def __init__(self,a,b):
        # self.a=a 
        # self.b=b 
    # def add(self,a,b):
        # self.a=a 
        # self.b=b 
        # print "the sum of two numbers",a+b 
    # def sub(self,a,b):
        # self.a=a
        # self.b=b 
        # print "the sub of two numbers",a-b 
# c=Arithematic(10,20)
# c.add(10,220)
# c.sub(20,20)
#inheritance
# class arithematic():
    # def f1(self):
        # print "hello"
    # def f2(self):
        # print "satish"
# class satish(arithematic):
    # def f3(self):
        # print "hii"
    # def f4(self):
        # print "good bye"
# c=satish()
# c.f1()
# c.f2()
# c.f4()
#multilevel inheritance
# class Animal:
    # def eat(self):
        # print "eating"
    # def dog(self):
        # print "chicken"
# class satish(Animal):
    # def sweet(self):
        # print "goodtaste"
    # def hot(self):
        # print "it is very hot"
# class rajesh(satish):
    # def good(self):
        # print"good boy"
    # def bad(self):
        # print "bad boy"
# c=rajesh()
# c.good()
# c.bad()
# c.eat()
# c.dog()
# c.sweet()
# c.hot()
#multiple inheritance
# class first(object):
    # def __init__(self):
        # super(first,self).__init__()
        # print "sarojamma"
# class second(object):
    # def __init__(self):
        # super(second,self).__init__()
        # print "rajesh"
# class third(second,first):
    # def __init__(self):
        # super(third,self).__init__()
        # print "sivaiah"
# third()
#function overloading: the assignment of more than one behaviour to a particular function.
#operator overloading: the assignment of more than function to a particular operator
#overriding method:
# different classes and same name and same parameters then it is called the overriding method
# class Arithematic(object):
    # def add(self,a,b):
        # print "sum of two numbers",a+b 
# class satish(Arithematic):
    # def add(self,a,b):
        # print "sum of two numbers",a+b 
# c=satish()
# c.add(2,3)
#overloading: it is same method name and different arguments it is called overloading
# class satish(object):
    # def add(self,a,b):
        # print "sum of a,b is:",a+b 
    # def add(self,c,d):
        # print "sum  of c,d is:",c+d
# i=satish()
# i.add(9,3)
#polymorphism 
# class shark():
    # def swim(self):
        # print ("the shark is swimming")
    # def swim_backwards(self):
        # print("the shark cannot swim backward,but can sink backwards.")
    # def skeleton(self):
        # print ("the shark's skeleton is made of cartilage")
# class clownfish():
    # def swim(self):
        # print("the clownfish is swimming")
    # def swim_backwards(self):
        # print("the clownfish can swim backwards")
    # def skeleton(self):
        # print("the clownfish's skeleton is made of bone")
# satish=shark()
# rajesh=clownfish()
# for fish in (satish,rajesh):
    # fish.swim()
    # fish.swim_backwards()
    # fish.skeleton()
# class satish():
    # def maths(self):
        # print ("print the mathematics")
    # def physics(self):
        # print ("print the physics")
    # def cheminstry(self):
        # print ("print the cheminstry")
# class rajesh():
    # def maths(self):
        # print ("enter the mathematics details in rajesh")
    # def physics(self):
        # print("enter the physics details in rajesh")
    # def cheminstry(self):
        # print("enter the cheminstry details in rajesh")
# def sat(fish):
    # fish.physics()
# s1=satish()
# s2=rajesh()
# sat(s1)
# sat(s2)
#data encapsulation  
def car:
    def __init__(self)