

# here we are implimenting the encapsulation method in Oops .and declare class variables for public ,protect,  private and implimented in below script.

# encapsulation is nothing but wriiting attributes and methods inside the class


class Encaps:
    name = "srihari"     #public 
    _name = "srihari p"     #protect 
    __name = "srihari pampana"   #private
    
    def __init__(self,a,b):
        self.a=a
        self.b=b
        
    def add(self):
        print("adding two values",self.a+self.b)
        print("this is indirectly calling for protect",self.__name)
        
obj = Encaps(21,43)
obj.add()
print(obj.name)
print(obj._name)
# print(obj.__name)
        
        
        
        
        