

from abc import ABC,abstactmethod

class One(ABC):
    @abstactmethod
    def add(self):
        print("one add ok")
    
    # @abstactmethod
    # def sub(self):
        # print("one sub ok")
                
a = One()
a.add()


# class Two():
    # def add2()