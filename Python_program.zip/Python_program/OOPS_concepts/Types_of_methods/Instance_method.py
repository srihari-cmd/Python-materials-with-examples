# 1.instance method/object related methods.
# here we are calling instance variable in another method is nothing but a instance method


class Student:
    def __init__(self,name,age):
        self.name = name
        self.age = age
        
    def display_details(self):
        print("the student name is :",self.name)            # ---> instance method
        print("the student age is :",self.age)
    
s1 = Student("srihari",29)
s1.display_details()
        
        