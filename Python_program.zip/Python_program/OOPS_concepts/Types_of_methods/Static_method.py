# 1.static method/utility methods
# 2.when ever we decleared the decarator of staticmethod we can call the method using the object.  
# 2.when ever we are not decleared the decarator of staticmethod we can call the method using the class name with method.  

class Student:
    Cname = "Google"
    def __init__(self,name,age):
        self.name = name
        self.age = age
        
    def display_details(self):
        print("the student name is :",self.name)            
        print("the student age is :",self.age)
    
    # @staticmethod
    def findAverage(x,y):
        print("Average",(x+y)/2)


s1 = Student("srihari",29)
# s1.display_details()
# s1.findAverage(5,5)
Student.findAverage(5,5)
        