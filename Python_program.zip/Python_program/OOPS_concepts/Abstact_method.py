
# abstract class can have atleast one abstract method.
# using abc module we can implement the abstract method for class and method.
# python can not support for abstract method
#abc(abstract base classes)
 

from abc import ABC,abstractmethod

class Computer(ABC):
    @abstractmethod
    def process(self):
        pass
        
        
class Laptop(Computer):
    def process(self):
        print("its running")
 
class Desktop(Computer):
    def process(self):
        print("its also running")
        
class Programmer:
    def work(self,com):
        print("solving bugs")
        com.process()
        
# com = Computer()

com1 = Laptop()
# com1.process()

com2 = Programmer()
com2.work(com1)
    
com3 = Desktop()
com3.process()
