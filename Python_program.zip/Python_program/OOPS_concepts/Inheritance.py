#inheritance
class arithematic():
    def f1(self):
        print("hello")
    def f2(self):
        print("srihari")
class srihari(arithematic):
    def f3(self):
        print("hii")
    def f4(self):
        print("good bye")
c=srihari()
c.f1()
c.f2()
c.f4()
