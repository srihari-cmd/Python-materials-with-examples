
class A():
    def add(self,a):
        print("the a value is :",a)
    
    def add(self,a):
        print("the a1 value is:",a+10)
     
    def add(self,a):
        print("the a2 value is :",a*10+2)
    # def add(self,a,b):
        # print("the a and b values are:",a+b)
        

inst = A()
inst.add(8)
# inst.add(12,21)

