# class A:
    # def __init__(self, value=0):
        # self.value = value

    # def __add__(self, b):
        # r = self.value + b
        # return r
    # def __str__(self):
        # return str(self.value)

# a = A(10,20)
# print(a)
# print(a + 1 + 2)


class A:
    def __init__(self, value):
        self.a = value
    def __add__(self, another_value):
        return self.a + another_value

a = A(1)
print(a+1+1)


