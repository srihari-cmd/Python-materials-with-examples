def add_Fun():
	print("hello")
	

def add(a,b):
	return int(a)-int(b)
