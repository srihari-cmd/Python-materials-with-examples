NAME = 'kumar'
DID  = 345
l = [1,2,3,4]
d = {44:55,'name':'sriram'}