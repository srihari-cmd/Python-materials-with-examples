# To know robot version
pybot --version
robot --version

# paasing values to variable command line =>  
    pybot -v ONE:10 Loop.txt
# create log file             ==> 
    pybot -b debug.log test2_list.robot
# validate the test data      ==> 
    pybot --dryrun test2_list.robot
# To run particular test case ==> 
    pybot -t "Add Two Values" first_test.txt
    pybot -t "TestCase 1" -t  "TestCase 2" first_test.txt
    pybot -t  Add* first_test.txt
# TO run a test case based on tag => 
    pybot -i test2 first_test.txt
# TO run all test cases except given tag => 
    pybot -e test2 first_test.txt
# Change logs path ==> 
    pybot -d C:\Users\smellamp\Desktop\SRIRAM\INSTITUTION\COURSES\ROBOT_FRAMWEORK\Logs test2_list.robot
