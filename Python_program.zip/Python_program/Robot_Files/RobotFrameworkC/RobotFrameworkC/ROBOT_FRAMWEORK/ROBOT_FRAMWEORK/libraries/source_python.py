def emp_details(name):
    print('emp name is :', name)
    return 'RETURN FROM PYTHON FUNCTION'





