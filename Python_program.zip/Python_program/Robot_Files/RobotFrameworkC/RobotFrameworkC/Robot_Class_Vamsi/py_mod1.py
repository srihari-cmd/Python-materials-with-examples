
def f1():
    print("This is from function f1 of python")
    raise Exception("F1 raises exception")
    return  1000

def f2():
    print("This is from function f2 of python")