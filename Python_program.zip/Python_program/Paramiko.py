import paramiko

host name= "****"
port="***"
uname="**"
password="**"
Paramiko.util.log_to_file('paramiko.log')  # -> Send paramiko logs to a log file
s=paramiko.SSH.client()                     #-> Create a object from ssh agent
s.load_system_host_key()                    #-> Your host keys(read the files)
s.connect(Hn,port,un,pwd)                    #-ssh server
stdin,stdout,stderr=s.execommand("Run any command from here")
print stdout.read()    #-get the O/P