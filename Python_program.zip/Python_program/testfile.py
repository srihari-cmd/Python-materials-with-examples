

# we can change the behaviour of the existing function at the compile time itself using decorator.


# d={1: 'val1', 2: 'val2'}
# values_l= list(d.values())
# print(values_l)

#remove the duplicate values

# list1 = ["a","b",2,1,2,1,"a","b","c","c","a",1,2,3,1,2,1,2]
# print(len(list1))
# list2 = list(dict.fromkeys(list1))
# print(list2)
# print(len(list2))


def upper_d(func):
    def inner():
        str1 = func()
        return str1.upper()
    return inner        

def split_d(func):
    def wrapper():
        str2 = func()
        return str2.split()
    return wrapper



@split_d
@upper_d
def ordinary():
    return "good morning"

print(ordinary())



d = {"name1":"srihari","emp":"srihari1","age":"123"}
print(d)

