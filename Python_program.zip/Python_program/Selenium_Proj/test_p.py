import pytest


def test_file1_method1():
    x = 5
    y = 6
    assert x + 1 == y, "test failed"


def test_file1_method2():
    x = 5
    y = 6
    try:
        assert x == y, "test failed"
    except AssertionError as error:
        print(error)


@pytest.fixture
def supply_AA_BB_CC():
    aa = 25
    bb = 35
    cc = 45
    return [aa, bb, cc]


def test_comparewithAA(supply_AA_BB_CC):
    zz = 35
    assert supply_AA_BB_CC[0] == zz, "aa and zz comparison failed"


def test_comparewithBB(supply_AA_BB_CC):
    zz = 35
    assert supply_AA_BB_CC[1] == zz, "bb and zz comparison failed"


def test_comparewithCC(supply_AA_BB_CC):
    zz = 45
    assert supply_AA_BB_CC[2] == zz, "cc and zz comparison failed"


@pytest.mark.parametrize("input1, input2, output", [(5, 5, 10), (3, 5, 12)])
def test_add(input1, input2, output):
    assert input1 + input2 == output, "failed"


@pytest.mark.xfail
def test_add_3():
    assert 15 + 13 == 28, "failed"


@pytest.mark.xfail
def test_add_4():
    assert 15 + 13 == 100, "failed"


def test_add_5():
    assert 3 + 2 == 5, "failed"


def test_add_6():
    assert 3 + 2 == 6, "failed"


@pytest.mark.skip
def test_add_1():
    assert 100 + 200 == 400, "failed"


@pytest.mark.skip
def test_add_2():
    assert 100 + 200 == 300, "failed"


import request
import json

@pytest.mark.bala
def test_login_valid(supply_url):
    url = supply_url + "/login/"
    data = {'email': 'test@test.com', 'password': 'something'}
    resp = request.POST(url, data=data)
    j = json.loads(resp.text)
    assert resp.status_code == 200, resp.text
    assert j['token'] == "QpwL5tke4Pnpja7X", resp.text
