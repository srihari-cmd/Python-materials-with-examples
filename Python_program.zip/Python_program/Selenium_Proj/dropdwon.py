from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.action_chains import ActionChains
from time import sleep


class Checking:

    def __init__(self, driver):
        self.driver = driver
        self.click_me = "//*[@id='HTML9']/div[1]/button"
        self.speed = "//*[@id='speed']"
        self.double = "//*[@id='HTML10']/div[1]/button"
        self.drable = "//*[@id='draggable']"
        self.dropble = "//*[@id='droppable']"

    def check_drop(self):
        self.driver.find_element_by_xpath(self.click_me).click()
        alert = self.driver.switch_to.alert
        alert.accept()

    def dropdown_speed(self):
        select = Select(self.driver.find_element_by_xpath(self.speed))
        select.select_by_index(3)

    def dropdown_speed2(self):
        global action
        obj = self.driver.find_element_by_xpath(self.double)
        action = ActionChains(self.driver)
        action.double_click(obj).perform()
        sleep(3)

    def drag_anddrop(self):
        source = self.driver.find_element_by_xpath(self.drable)
        target = self.driver.find_element_by_xpath(self.dropble)
        action.drag_and_drop(source, target).perform()
