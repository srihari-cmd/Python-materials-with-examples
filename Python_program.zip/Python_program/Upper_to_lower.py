

# fetch the seperate the char for upper and lower cases in to list

import re

str = "PYthon ProgRammIng LanguaGe"

C = re.findall('[A-Z]', str)

s = re.findall('[a-z]', str)

print(' upper case letters ',C)

print('lower case letters :', s)






str1 = "HEllo SriHari PamPAna This is PYthon Course"

Cap = re.findall('[A-Z]',str1)

Sma = re.findall('[a-z]',str1)

print("upper case letters",Cap)

print("upper case letters",Sma)







