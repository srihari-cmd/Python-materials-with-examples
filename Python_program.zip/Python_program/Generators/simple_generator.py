#sample generator function 
# generator function is a function which returns generator-iterator with the help of yield keyword


'''
def fib(mymax):
    a,b = 0,1
    while True:
        c=a+b
        if c<mymax:
            print("before yield keyword")
            yield c
            print("after yield keyword ")
            a=b
            b=c
        else:
            break

gen= fib(10)
print(next(gen))
print(next(gen))
print(next(gen))
print(next(gen))
print(next(gen))
print(next(gen))'''


# another way

def topten():
        n =1
        while n<=10:
            sq = n+n
            yield sq
            n+=1
           
values = topten()

for i in values:
    print(i)

    
    
