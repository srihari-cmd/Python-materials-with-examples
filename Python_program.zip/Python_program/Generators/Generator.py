#using genarator print fibonacci

def fib():
    a,b=0,1
    while True:
        yield a
        a,b=b,a+b
for i in fib():
   if i>40:
      break
print(i)

def rev_str(my_str):
     length = len(my_str)
     for i in range(length - 1,-1,-1):
         yield my_str[i]
for c in rev_str("dada"):
     print(c)
#To generate n numbers

def fun_gen(num):
    n=1
    while n<num:
        yield n
        n=n+1
for x in fun_gen(10):
    print(x)
#The fibonacci series in generator in python
def fib():
    a,b=0,1
    while True:
        a,b=b,a+b
for n in fib():
    if n>100:
        break
    print("The fibonacic numbers are",n)

#advantages of generator function
#1)imporved the memory utalization and performance will be improved
#2)generator best are suitable for reading data from  large number and large files.
#3)generator work great for webscrapping and crawling.
#4)when compared with class level iterators,generators are very easy to usee .