# using map and lambda function doing multiple with list values

num = [1,2,3,4,5,6,7,8,9,10]
multiple = list(map(lambda a: a*2,num))
print(multiple)
