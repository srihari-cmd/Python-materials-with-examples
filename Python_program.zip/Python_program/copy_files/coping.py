numbers = [1,2,3,4,5]
new_numbers = numbers

new_numbers[0] = 9

print("numbers list :",numbers)
print("ID of numbers :",id(numbers))


print("new numbers :",new_numbers)
print("ID of new numbers :",id(new_numbers))