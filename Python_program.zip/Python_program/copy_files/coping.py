numbers = [1,2,3,4,5]
new_numbers = numbers

new_numbers[0] = 9

print("numbers list :",numbers)
print("ID of numbers :",id(numbers))


print("new numbers :",new_numbers)
print("ID of new numbers :",id(new_numbers))




x = [1,2,3]
y = x

y[0]=4

print("the x values are :",x)
print("id of x is :",id(x))

print("the y values are :",y)
print("id of y is :",id(y))
