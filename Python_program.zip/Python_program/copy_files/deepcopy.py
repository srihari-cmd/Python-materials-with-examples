#deep copy  ---> using the method is copy .deepcopy()

# deep copy creates a copy of the object and the elements of the object.

import copy

old_list = [[1,2,3],[4,5,6],[7,8,9]]

new_list = copy.deepcopy(old_list)

new_list[0] = ['a','b','c']
# new_list[0][2] = 'c'


print("old list :",old_list)
print("new_list :",new_list)
