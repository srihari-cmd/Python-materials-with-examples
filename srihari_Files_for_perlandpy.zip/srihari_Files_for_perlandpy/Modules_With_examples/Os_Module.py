
import os

# to get all the methods or functions
print(dir(os))

# to get os name of laptop

print(os.name)

# to get the current working directory

print(os.getcwd())

# to get the data from the file 

fd = "C:\\Users\\srihari.pampana\\Desktop\\test_file.txt" 
file = open(fd, 'r') 
text = file.read() 
print(text) 
os.close(file) 


