
import pytest
def test_add():
    x= 2
    y= 6
    assert x*3==y,"test failed"
def test_sub():
    x=10
    y = 5
    assert x-5==y,"test failed"
    
