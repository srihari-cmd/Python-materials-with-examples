import pytest

@pytest.fixture(scope='module')
def setup():
    print("\n the setup part will execute before all tc")
    yield 
    print("\n the teardown part will execute after all tc")
        
def test_add_val(setup):
        pass
        print("\n the add valuse")
        
def test_mul_val(setup):
        pass
        print("\n the mul valuse")
        
 