
class TestClass(object):
    def test_one(self):
        x="hello"
        assert 'l' in x
    
    def test_two(self):
        x="world"
        assert hasattr(x,"w")
        