

import pytest

@pytest.mark.skip
def test_add():
    x= 2
    y= 6
    assert x+4==y,"test failed"
@pytest.mark.xfail
def test_sub():
    x=10
    y = 5
    assert x-5==y,"test failed"
    
@pytest.mark.skip
def test_mul():
    x= 2
    y= 6
    assert x*3==y,"test failed"
@pytest.mark.xfail
def test_div():
    x=10
    y = 5
    assert x/2==y,"test failed"
   