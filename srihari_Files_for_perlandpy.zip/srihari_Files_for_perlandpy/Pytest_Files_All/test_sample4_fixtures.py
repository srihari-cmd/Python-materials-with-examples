
'''
import pytest
@pytest.fixture
def supply_Id_Name_Branch():
    Id=81312
    Name="srihari"
    Branch = "IT"
    return [Id,Name,Branch]
   

def test_comparewithId(supply_Id_Name_Branch):
    result=81312
    assert supply_Id_Name_Branch[0]==result,"test failed"
   
def test_comparewithName(supply_Id_Name_Branch):
    result="srihari"
    assert supply_Id_Name_Branch[1]==result,"test failed"

def test_comparewithBranch(supply_Id_Name_Branch):
    result="IT"
    assert supply_Id_Name_Branch[2]==result,"test failed"

'''

# a = 10

# while a<=0:

    # print(a)
    # a -= 1
    
i = 10
while i >=0:
  print(i)
  i -= 1
  
    