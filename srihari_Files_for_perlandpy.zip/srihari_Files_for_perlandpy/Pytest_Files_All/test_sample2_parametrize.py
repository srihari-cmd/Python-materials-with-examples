
'''
using parametrize we can pass the multiple values in a single time
we can  define parametrize like-->  @pytest.mark.parametrize()
'''

import pytest
def add(a,b):
    return a+b
def sub(a,b):
    return a-b

@pytest.mark.parametrize('arg1,arg2,result',[(3,3,6),(2,2,4),(5,5,10)])
def test_add(arg1,arg2,result):
    assert add(arg1,arg2)==result,"test failed"
@pytest.mark.parametrize('arg1,arg2,result',[(5,3,2),(8,4,4),(12,6,6)])
def test_sub(arg1,arg2,result):
    assert sub(arg1,arg2)==result,"test failed"

# or we can create other way with out creating separate function below

@pytest.mark.parametrize('arg1,arg2,result',[(3,3,9),(2,2,4),(5,5,25)])
def test_mul(arg1,arg2,result):
    assert arg1*arg2 ==result,"test failed"
@pytest.mark.parametrize('arg1,arg2,result',[(10,5,2),(8,4,2),(12,6,2)])
def test_div(arg1,arg2,result):
    assert arg1/arg2==result,"test failed"

@pytest.mark.parametrize('arg1,arg2,result',[(10,10,20),(5,4,9),(7,7,14)])
def test_add1(arg1,arg2,result):
    assert arg1+arg2==result,"test failed"
