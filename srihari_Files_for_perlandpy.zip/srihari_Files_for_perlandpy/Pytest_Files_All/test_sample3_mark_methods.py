
'''
here we can define a mark  name with every functions with out a class.
'''

import pytest
@pytest.mark.set1
def test_add():
    x= 2
    y= 6
    assert x+4==y,"test failed"
@pytest.mark.set2    
def test_sub():
    x=10
    y = 5
    assert x-5==y,"test failed"
@pytest.mark.set1
def test_mul():
    x= 2
    y= 6
    assert x*3==y,"test failed"
@pytest.mark.set2
def test_div():
    x=10
    y = 5
    assert x/2==y,"test failed"
    
'''
here we can created one class and we can define mark for that class.
here we can call that class using mark name in output will dispaly all function which is containing class.  
'''

@pytest.mark.marker1
class TestClass(object):
    def test_one(self):
        x="hello"
        assert 'l' in x,"hai"
    
    def test_two(self):
        x="world"
        assert 'w' in x,"helllo"
                
import pytest
@pytest.mark.marker2
def test_add():
    x= 2
    y= 6
    assert x*3==y,"test failed"
@pytest.mark.marker2    
def test_sub():
    x=10
    y = 5
    assert x-5==y,"test failed"
    

