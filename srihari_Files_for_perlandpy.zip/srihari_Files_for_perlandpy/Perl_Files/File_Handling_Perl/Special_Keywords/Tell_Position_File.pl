
#Perl Tell
#This method will return the current position of FILEHANDLER in bytes if specified else it will consider the 
#last line as the position.

open(fh,"D:\\Perl_Files\\File_Handling_Perl\\Append_Mode\\Append_File1.pl");

while (<fh>)
{
	$a = tell fh;
	print "$a";
}


