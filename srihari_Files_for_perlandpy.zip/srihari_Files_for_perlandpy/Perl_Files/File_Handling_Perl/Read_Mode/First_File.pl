#1 one way to read the content in a file using file handler 
#this is the syntax to open a file and read the symbol is "<" ===>>Read – open(my $fh,"<filename or complete path of the file"); 

open(fh,"<D:\\Perl_Files\\File_Handling_Perl\\Read_Mode\\File1.txt");
while(<fh>)
{
	print "$_";
}
close fh;

# 2nd way to  read the file 

open(fh,"<D:\\Perl_Files\\File_Handling_Perl\\Read_Mode\\File1.txt");

my @content = <fh>;
foreach(@content)
{
	print "$_";
}
close fh;
