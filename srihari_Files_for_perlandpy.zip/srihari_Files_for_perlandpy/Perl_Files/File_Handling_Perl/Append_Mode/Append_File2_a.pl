open(fh,">>D:\\Perl_Files\\File_Handling_Perl\\Append_Mode\\Write_File.txt");

my $var = "hello world \n";

print fh $var;

close fh;


