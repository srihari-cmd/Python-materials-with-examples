

open(fh,">>D:\\Perl_Files\\File_Handling_Perl\\Append_File\\Write_File.txt");

my $var = "srihari \n";


print fh $var;

close fh;
