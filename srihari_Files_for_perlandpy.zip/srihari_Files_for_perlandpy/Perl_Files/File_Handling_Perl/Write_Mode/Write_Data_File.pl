#one way to write a data in to a file

 
open(fh,">D:\\Perl_Files\\File_Handling_Perl\\Write_Mode\\Write_File.txt");

my $var = "good";


print fh $var;
close fh;

# 2nd way to write a data in to a file

open(fh1,">D:\\Perl_Files\\File_Handling_Perl\\Write_Mode\\Write_File.txt");

print fh1 "hello how are you \n ";

close fh1;


 