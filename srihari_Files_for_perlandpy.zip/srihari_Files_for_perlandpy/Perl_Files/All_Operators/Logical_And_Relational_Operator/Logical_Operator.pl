
#here how we are performing the logical operations
#Logical and Relational Operators:
#Perl uses logical operators to compare numbers and strings. Most of the time logical operators are 
#used in Conditional Statements.

my $x=5;
my $y=5;

if($x==$y)
{
	print "True --Equal $x and $y \n";
}
else
{
	print "False --Not equal $x and $y \n";
}

$x = 5;
$y = 8;

if ($x!=$y)
{
	print "True --not equal $x and $y \n";
}
else
{
	print "False --equal $x and $y \n";
}

if ($x>$y)
{
	print "True --  $x greater than $y \n";
}
else 
{
	print "False -- $x greater than $y \n";
}

if ($x<$y)
{
	print "True --$x less than $y \n";
}
else
{
	print "False --$x less than $y \n";
}

if ($x>=$y)
{
	print "True --$x greater than are equal to $y \n";
}
else
{
	print "False --$x greater than are equal to $y \n";
}


if ($x<=$y)
{
	print "True --$x less than are equal to $y \n";
}
else
{
	print "False --$x less than are equal to $y \n";
}





