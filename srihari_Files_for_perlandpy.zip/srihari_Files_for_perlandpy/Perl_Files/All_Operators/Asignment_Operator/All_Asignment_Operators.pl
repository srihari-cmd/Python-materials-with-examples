

my $x = 10;

$x += 5;
print "Add = $x\n";

$x -= 5;
print "Sub = $x \n";

$x *= 5;
print "mul = $x \n";


$x **= 5;
print "mul = $x \n";

$x %= 5;
print "Per = $x \n";

$x/=12;
print "Dev = $x \n";


