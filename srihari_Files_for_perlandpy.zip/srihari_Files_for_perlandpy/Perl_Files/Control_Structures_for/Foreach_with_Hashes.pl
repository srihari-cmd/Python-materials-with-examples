#This looks good for accessing arrays. How about Hashes, how can we obtain hash keys and values using foreach?

#We can use foreach to access keys and values of the hash by looping it.

#here we are using foreach condition to get separate keys and values.below there is one example.
#You might be wondering, Why we used Keys in foreach(). Keys is an inbuilt function of Perl where 
#we can quickly access the keys of the hash. How about values? We can use values function for accessing values of the hash.




my %hari  = ('tom' => 23,'jerry' => 21,'hai' => 12);

foreach my $key (keys %hari)
{
	print "$key \n";
}

print "\n";

foreach my $value (values %hari)
{
	print "$value \n";
}
