#Perl While
#The Perl While loop is a control structure, where the code block will be executed till the condition is true.
#The code block will exit only if the condition is false.
#Let's take an example for Perl While loop.

=abc
$guru99 = 0;
$luckynum = 7;
print "Guess a Number Between 1 and 10\n";
$guru99 = <STDIN>;
while ($guru99 != $luckynum)
{
	print "Guess a Number Between 1 and 10 \n ";
	$guru99 = <STDIN>;
}
print "You guessed the lucky number 7";
=cut

$a = 11;

# while loop execution
while( $a= $a-1 ) {
   printf "Value of a: $a\n";
 
}





