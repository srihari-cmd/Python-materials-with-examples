
#Perl do-while
#Do while loop will execute at least once even if the condition in the while section is false.
#Let's take the same example by using do while.


$s = 5;

do{
	print "$s \n ";
	$s--;
	
}
while($s>=1);
print "the value is less then 1";



