
#here we are performing the for loop statement 

#1 For loop Perl 
#For code block will execute till the condition is satisfied. 
#Let's take an example of how to Perl loop an array.

my @arry = (1..10);

for(my $count=0;$count<10;$count++)
{
	print "the arry index $count value is $arry[$count]";
	print "\n";
}

#2  for ( initialization ; condition; incrementing)
#Here is another way of using for.

for (1..10)
{
	print "$_ srihari ";
	print "\n";
}


my @list = (1,2,3,4,5,6,7,8,9);

for(my $count=0;$count<10;$count++)

{
	print "the list index $count  value is $list[$count] ";
	print "\n";
	
}
