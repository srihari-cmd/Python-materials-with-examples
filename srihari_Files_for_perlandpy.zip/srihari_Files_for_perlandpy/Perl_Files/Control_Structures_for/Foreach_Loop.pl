#Perl Foreach
#The for each statement can be used in the same way as for; the main difference is we don't have any condition check 
#and incrementing in this.
#Let's take the same example with foreach perl.

my @arry = (1,2,3,4,5,67,8,9,10);

foreach my $val (@arry)
{
	print "the value is $val \n";
}

#Foreach takes each element of an array and assigns that value to $var for every iteration. We can also use $_ for the same.

my @list = (1..10);
foreach(@list)
{
	print "the value is $_ \n";
}
