#You can also declare an array in the above way; the only difference is, it stores data into an array considering a 
#white space to be the delimiter. Here, qw() means quote word. The significance of this function is to generate a list 
#of words. You can use the qw in multiple ways to declare an array.


@array = qw( a b c d );
print @array;
@array1=qw/a b c d/;
@array2= qw' p q r s'; 
@array3=qw { v x y z};
print @array1;
print @array2;
print @array3;