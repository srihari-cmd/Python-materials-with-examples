


@list = qw\a b c d\;

print $size = scalar (@list);




@array= qw/a b c d e/;
print $size=scalar (@array);
print "\n";
print $size=$#array + 1;                           # $#array will print the Max Index of the array, which is 5 in this case


@a = (1,2,3,5,32,4,6,2,12,4,3);
print $size = scalar (@a);



