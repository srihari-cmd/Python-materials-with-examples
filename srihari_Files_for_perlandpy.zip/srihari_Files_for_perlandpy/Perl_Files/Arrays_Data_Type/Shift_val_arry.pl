#shift is a function. it will perfrom to remove the value from starting of array values.



@list = ("hari",2,4,5,7,3);
print "before shift :@list \n";

shift(@list);

print "after shift :@list \n";


