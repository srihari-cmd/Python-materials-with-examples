
@list = (1,2,3,4);
print "before pop:@list \n";

pop(@list);
print "after pop:@list \n";
