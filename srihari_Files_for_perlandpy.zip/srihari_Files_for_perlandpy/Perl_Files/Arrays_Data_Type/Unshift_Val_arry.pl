
#unshift -->it is a function.it is used to perform add the values from starting onwards.


@list = (2,3,4);
print "before unshift:@list \n";
unshift(@list,"hello","hai","bye");
print "after unshift:@list \n";
