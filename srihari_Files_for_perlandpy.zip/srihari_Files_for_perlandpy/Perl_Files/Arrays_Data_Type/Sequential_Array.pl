#Sequential arrays are those where you store data sequentially. 
#Suppose, you want to store 1-10 numbers or alphabets a-z in an array. 
#Instead of typing all the letters, you can try something like below -




@list2 = (1..10);
print "@list2\n";
@list3 = (A..Z);
print "@list3\n";
@list4 = (F..Z);
print "@list4\n";
@list5 = (42..99);
print "@list5\n";
