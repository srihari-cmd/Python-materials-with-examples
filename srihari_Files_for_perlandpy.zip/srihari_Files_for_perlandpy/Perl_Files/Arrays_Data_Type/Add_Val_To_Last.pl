
#using push function we can achive it


@arry = ("Hello","hai");
print "before adding the elements: @arry \n";
push (@arry,"rebal","srihari","dfcdznsn");
print "after adding the elements : @arry \n";


