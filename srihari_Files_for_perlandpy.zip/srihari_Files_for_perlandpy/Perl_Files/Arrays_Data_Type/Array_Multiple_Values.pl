
#here array preceeded with @ symbol .we can create multiple values in array.like @a = (2,1,4,3,9);
#What is Perl Array?
#An Array is a special type of variable which stores data in the form of a list; each element can be
#accessed using the index number which will be unique for each and every element.
#You can store numbers, strings, floating values, etc. in your array. This looks great, 
#So how do we create an array in Perl? In Perl, you can define an array using '@' character 
#followed by the name that you want to give. Let's consider defining an array in Perl.

#here we are storing the different values with different levels




@list = qw "3 4 2 2 4 5";

print "@list\n";

@list1 = (3,4,2,2,4,5);
print "@list1\n";
print "$list1[1]\n";	









