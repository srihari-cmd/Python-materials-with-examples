


@a = (1,2,3,4);

$a[5] = 'hari';
print "@a\n ";
