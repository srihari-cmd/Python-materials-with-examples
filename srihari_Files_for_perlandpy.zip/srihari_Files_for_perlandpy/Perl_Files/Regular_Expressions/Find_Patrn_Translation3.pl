
# here we are performing to find the pattren or replace using the translation operator 

my $var = "Hello hai how are youe";

$var =~tr/Hello/Bollo/;

print $var;
