
# here we are performing to find the pattren and replace the values using Substitution type

my $var = "Hello srihari Pampana";
$var =~s/Hello/Bollo/gi;             #gi (globally Ignore)
print $var;
