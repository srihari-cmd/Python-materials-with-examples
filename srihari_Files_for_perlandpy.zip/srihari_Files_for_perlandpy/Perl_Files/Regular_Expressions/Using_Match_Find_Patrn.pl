
my $p = "hello how are you";
if ($p =~m/you/)
{
	print "true";
}
else
{
	print "false";
}



#2

print "\n";


my $var = "hello all my name is srihari";

if ($var =~m/\.*\s*/)
{
	print "true";
}
else
{
	print "false";
}
