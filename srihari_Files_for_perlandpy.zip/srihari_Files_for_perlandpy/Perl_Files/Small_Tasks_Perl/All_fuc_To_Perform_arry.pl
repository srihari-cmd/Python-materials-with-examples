
#here i am using all functions to handle array values like shift ,unshift, pop, push.


@list = ("bad","wed","Thus","Fri","good");

print "without performing :@list \n";

pop(@list);
print "1st after performing pop fun the values are:@list \n";

push(@list,"Sat","Sun");
print "2nd after performing push fun the values are:@list \n";

shift(@list);
print "3rd after performing shift the values are:@list \n";

unshift(@list,"Mon","Tue");
print "4th after performing unshift the values are:@list \n";
