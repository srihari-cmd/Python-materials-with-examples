@list = (1..20);

print $size = scalar (@list);
print "\n";



#with out using function we can get the size of array


@list = (1,2,4);
#print $size  = scalar (@list);
print $size = $#list +11;
print "\n ";

