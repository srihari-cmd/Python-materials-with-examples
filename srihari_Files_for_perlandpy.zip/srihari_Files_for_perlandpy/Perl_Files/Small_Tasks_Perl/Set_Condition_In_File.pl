use feature 'say';

my $i = 1;

while ($i<10)
{
	if($i%2==0)
	{
		$i++;
		next;
	}
	if ($i==7)
	{
		last;
	}
	say $i;
	$i++;
}
