# here we are perfroming to reverse the array values using reverse function

#to reverse a array values 

my @arry = (5,3,2,5,7,8,1,13,6);
my @rev_arry = reverse @arry;
print join(",",@rev_arry),"\n";


#to reverse a scalar values 


my $s = "srihari pampana";
my $s1 = reverse $s;
print join (",",$s1),"\n";


