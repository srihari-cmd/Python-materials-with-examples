

@list  = (1,2,3);
$list[3]="calsoft";
print "@list\n";


@list1  = (1,2,3);
$list1[10]="calsoft";
print "@list1\n";