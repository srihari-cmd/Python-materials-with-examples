

use feature 'say';

my $x = 7;
my $y = 4;

say "7+4 =",7+4;
say "7-4 =",7-4;
say "7*4 =",7*4;
say "7/4 =",7/4;
say "7%4 =",7%4;
say "7**4=",7**4;



 