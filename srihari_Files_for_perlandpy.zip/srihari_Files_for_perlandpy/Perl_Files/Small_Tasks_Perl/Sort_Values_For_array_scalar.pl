
# here we are performing to sort the values from scalar and arrays datatypes.

my $s = "vamsi srihari pampana vijay";
my @s1 = split / /,$s;

@s1 = sort @s1;

print join(",",@s1),"\n";



my @arry = (5,21,35,67,14,85,1,2);
my @arry1 = sort @arry;

print join(",",@arry1),"\n";

