# here we will get odd and even numbers with condition like using grep condition

#odd num

my @arry = (1..20);
my @odds_arry = grep{$_ %2} @arry;
print join(",", @odds_arry),"\n";

#even num

my @arry = (1..20);
my @odds_arry = grep{$_ %2==0} @arry;
print join(",", @odds_arry),"\n";

