

# here we are performing to multiplying  the values in variable 
# map

my @arry = (1..10);
my @dbl_arry = map{$_ *2} @arry;
print join(",",@dbl_arry),"\n";

