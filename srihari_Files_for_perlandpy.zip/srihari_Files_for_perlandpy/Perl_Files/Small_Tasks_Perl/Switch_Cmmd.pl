#here we are performing the switch command 
use feature 'say';

use feature "switch";

my $first = 1;
my $second = 2;

($first,$second) = ($second,$first);

say "$first $second";
