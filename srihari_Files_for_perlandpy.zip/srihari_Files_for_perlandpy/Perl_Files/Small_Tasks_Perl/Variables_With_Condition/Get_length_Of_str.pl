
# here we are performing the some special things .
#here we are performing to get the length of string.

use feature 'say';


my $str = "my name is srihari";

say "length of string", length $str;


@h = (3,4,6,7,8,6,4,3);
say "length of values are:",length @h;
printf("Last character is %s \n",chop @h);

