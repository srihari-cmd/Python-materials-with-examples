
# here we are peroform to display the characters and next letter of set condition 

#1
  
my @abcs = ('a'..'z');
print join(",",@abcs),"\n";

my $letter = 'c';
say "Next letter ", ++$letter;


@s = (a..z);
print @s;

#2

use feature 'say';


my @s = (1..10);

print join(",",@s),"\n";
my $s = 5;

say "Next s :", ++$s;
