#here we will print the last character in string using (chop-->display the last character)

my $a = "animalsr";

printf("Last character is %s \n",chop $a);
