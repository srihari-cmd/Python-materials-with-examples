
# here we will multiple the values in two times


my $two_times = "what i said is " x 2;
say $two_times;

