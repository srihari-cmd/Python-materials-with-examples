
my $str = "hai hello how are you this is srihari pampana";
my @array;
@array = split('r',$str);
foreach(@array)
{
	print "$_ \n";
}



