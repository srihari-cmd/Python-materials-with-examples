
use strict;
$var = 10;
print "$var";


use strict;
my $var = 10;
print "$var";