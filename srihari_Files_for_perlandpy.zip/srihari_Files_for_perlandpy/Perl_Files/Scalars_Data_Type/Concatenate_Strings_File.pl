
#using "."-->dot operator we can concatente the string


$a = "srihari";
$b = "calsoft";

$c = $a ." is a part of ". $b;
print $c;
