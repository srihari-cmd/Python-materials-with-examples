
#Local: Using this we can actually mask the same variable values to different values without actually changing 
#the original value of the variable, suppose we have a variable $a for which the value is assigned 5,
#you can actually change the value of that variable by re-declaring the same variable using local keyword 
#without altering the original value of the variable which is 5. Let's see how this works with an example.
 
 
 
$x = 12;
{
local $x=14;
print "local,\$x = $x \n";
}
print "global,\$x = $x \n";
