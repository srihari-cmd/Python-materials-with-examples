


$num = 7;
$txt = "it is $num";
print $txt;







$string = 'tutorial';                                      # give $string the eight-character string 'tutorial'
print $string;
$string = $size + 3 ;                                           # give $string the current value of $size plus 3
print $string;
#$string = $ string * 5;                                         # multiplied $string by 5
#print $string;