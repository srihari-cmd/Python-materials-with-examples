
#different data types 1->scalar,2->Arrays ,3->Hashes


#1
$a = srihari;

print "$a \n";


$n = 2+34;

print"$n \n";


$n1 = 23*4;
print"$n1 \n ";

$n2 = 24/4;
print"the n2 value is $n2 \n ";

