
$num = 7;
$txt = 'it is $num';
print $txt;
