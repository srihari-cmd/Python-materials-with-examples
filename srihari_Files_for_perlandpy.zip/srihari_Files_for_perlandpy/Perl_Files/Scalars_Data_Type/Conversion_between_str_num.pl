
$s1 = "43";
$s2 = 123;

$s3 = $s1+$s2;
print $s3;



$a = "121";
$b = 12;
$c = $a+$b;
print "$c\n";
