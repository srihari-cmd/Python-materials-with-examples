#The output of the program will be nothing!

my $var=5;
{ 
my $var_2 =$var;
}
print $var_2;



