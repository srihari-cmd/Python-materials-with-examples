#How to print the values
#!/usr/local/bin/perl
use feature 'say';

print "Hello World \n ";


