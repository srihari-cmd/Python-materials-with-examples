my $var =7;

if ($var<10)
 {
  print "inside the 1st if statement is executed....the value is $var";
  
  if ($var<5)
  {
   print "the 2nd if statement is executed ....the value is $var";
  }
  else
  {
   print "2 nd else statement is executed ...the value is $var";
  }
 }
 else
 {
  print "1st else statement is executed ....the value is $var";
 } 