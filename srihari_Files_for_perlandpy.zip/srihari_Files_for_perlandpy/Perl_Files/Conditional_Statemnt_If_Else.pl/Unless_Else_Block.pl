#Perl Unless
#You have already got an idea what if does (If the condition is true it will execute the code block). 
#Unless is opposite to if, unless code block will be executed if the condition is false.



my $a = 4;

unless($a==5)
{
	print "the unless stetement is executed $a \n";
}
else
{
	print "the else statement is executed $a \n";
}
