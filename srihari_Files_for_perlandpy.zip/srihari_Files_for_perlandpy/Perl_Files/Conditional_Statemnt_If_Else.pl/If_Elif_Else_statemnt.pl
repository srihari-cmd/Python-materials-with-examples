my $var = 21;

if ($var==23)
{
	print "if statement is executed $var \n";
}
elsif ($var==21)
{
	print "elif statement is executed $var \n";
}
else
{
	print "the else statement is executed $var \n";
}
