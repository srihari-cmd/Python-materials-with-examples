#here we are performing the if statement

my $var = 20;
if ($var==20)
{
	print "the if statement is valid the value is equal to $var\n";
}

