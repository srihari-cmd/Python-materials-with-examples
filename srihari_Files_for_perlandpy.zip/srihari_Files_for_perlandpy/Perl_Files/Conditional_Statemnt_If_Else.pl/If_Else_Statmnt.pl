

my $var = 21;

if($var==21)
{
	print "the if statement $var\n";
}
else
{
	print "the else statement is $var \n";
}
