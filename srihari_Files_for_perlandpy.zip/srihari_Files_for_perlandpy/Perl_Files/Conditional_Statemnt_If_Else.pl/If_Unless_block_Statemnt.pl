
# here we are performing the if statement will execute until the specified condition becomes True.
# here we are performing the unless statement will execute until the specified condition becomes False.

$var = "this is srihari";
if($var eq "this is srihari1")
{
	print "this is for if statement";
}
else
{
	print "else block";
}

print "\n";

$var1 = "this is srihari";
unless($var1 eq "hai hello how are you")
{
	print "the unless block is executed";
}
else
{
	print "else block is executed";
}
