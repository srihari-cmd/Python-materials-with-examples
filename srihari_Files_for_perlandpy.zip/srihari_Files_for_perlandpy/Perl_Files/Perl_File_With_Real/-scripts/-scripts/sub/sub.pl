#!\usr\bin\perl

# perl sub.pl .\\source\\contents.html .\\output\\win.txt .\\input\\input.txt .\\pmfiles

use lib "$ARGV[3]";
use suse;use windows;use windows12;use rhel;use win12R2;use win08R2;

$sfile=$ARGV[0];$ofile=$ARGV[1];$ifile=$ARGV[2];
open (INPUT,"<$ifile")      || die " Could not open input file \n";
while ( $in = <INPUT> ){
        #print " $in \n";
        push(@input,$in) if ( $in !~ /#|^\s/ );
    }
if ( $input[0] =~ /Red Hat/i){
	rhel($sfile,$ofile,$ifile); 
}
elsif ( $input[0] =~ /SUSE/i){ 
	suse($sfile,$ofile,$ifile);
}
elsif ( $input[0] =~ /Windows Server 2008$/i){
	print " ++ Windows Server 2008 ++ \n";
	win8($sfile,$ofile,$ifile);
}
elsif ( $input[0] =~ /Windows Server 2012$/i){
	win12($sfile,$ofile,$ifile);
}
elsif ( $input[0] =~ /Windows Server 2012 R2/i){
	win12R2($sfile,$ofile,$ifile);
}
elsif ( $input[0] =~ /Windows Server 2008 R2/i){
	win08R2($sfile,$ofile,$ifile);
}
else{
	print " could not match OS => $input[0]  \n";
	}

#  C:\\Users\\chaudars\\Desktop\\sub\\content\\contents.html C:\\Users\\chaudars\\Desktop\\sub\\NEW\\suse.txt C:\\Users\\chaudars\\Desktop\\scripts\\SUSE\\input.txt
#  win8('C:\\Users\\chaudars\\Desktop\\scripts\\NEW\\contents.html','C:\\Users\\chaudars\\Desktop\\scripts\\NEW\\win8.txt','C:\\Users\\chaudars\\Desktop\\scripts\\Win-2008\\input.txt'); 