#!\usr\bin\perl

package rhel;
use vars qw(@ISA @EXPORT);
use Exporter;
use File::Basename;
@ISA         = qw(Exporter);
@EXPORT      = qw(rhel);
sub rhel{
#print " win12### is ok \n";

$sfile=$_[0];$ofile=$_[1];$ifile=$_[2];#$sername=$ARGV[0];
my($file, $dir, $ext) = fileparse($ofile);
#print "Directory: " . $dir . "\n";print "File:      " . $file . "\n";
$diff="./diff.txt"; #print " ===== diff is ----> $diff\n";
open (IN,"$sfile")       || die " Could not open a file \n";
open (RHEL,">./temp.txt")    || die " Could not open output file \n"; 
open (DIFF,">$diff")     || die " Could not open diff file \n";
open (INPUT,"<$ifile")   || die " Could not open input file \n";
 # perl rhel.pl ./temp/contents.html  ./temp/rhel.txt  ./input.txt
 
	while ( $in = <INPUT> ){
        #print " $in \n";
        push(@input,$in) if ( $in !~ /#|^\s/ );
    }  
    $ver1  = $input[1]; $kern  = $input[2];	$osbit = $input[3]; $proce = $input[4];
	$nicdri= $input[5]; $nicver= $input[6]; $rom   = $input[7]; $controller = $input[8];
	$harddrive = $input[9];$nicspeed=$input[11];
	@nic=split(/,/,$nicdri);@nicv=split(/,/,$nicver);@hdriv=split(/,/,$harddrive);
	$nicsize=scalar(@nic);$hdrsize=scalar(@hdriv);
	#print " \n sizes are  => $nicsize == $hdriv\n nic ver => @nicv \n";
	
	$ver1   =~ s/^\s+|\s+$//g;$kern  =~ s/^\s+|\s+$//g;	$osbit  =~ s/^\s+|\s+$//g;$proce =~ s/^\s+|\s+$//g;
	$nicdri =~ s/^\s+|\s+$//g;$nicver=~ s/^\s+|\s+$//g; $rom    =~ s/^\s+|\s+$//g;$controller =~ s/^\s+|\s+$//g;
	$harddrive =~ s/^\s+|\s+$//g;$nicspeed =~ s/^\s+|\s+$//g;
	$osver="6" if ($ver1 =~ /5/); $osver="5" if ($ver1 =~ /6/);$osver="5|6" if ($ver1 =~ /7/);
	$osver1="7" if ($ver1 =~ /5/);$osver1="7" if ($ver1 =~ /6/);$osver1="5" if ($ver1 =~ /7/);
	@osv=split(//,$ver1); $ov=$osv[0];$xx='rhel7.' if ($ver1 =~ /5|6/ );$xx='rhel33.' if ($ver1 =~ /7/ );
	$ov="[567]";
	#print " linus are=Linux $osver @@@@@@@@@ $ver1= Linux $osver1 \n";
	print " ===> os version is =\$osver $osver : new =\$osver1 $osver1 =\$ov+++ $ov\n \$xx  $xx ";
	if ( $osbit == 32 ){
		$redhat="Red Hat Enterprise Linux|Red Hat";
	    $bit="AMD64|EM64T|x86_64|64-bit|SUSE|Linux $osver1|Linux $osver |sles|.txt|rhel5\b|x64|$xx|rhel5.|rpm.sig|.log";
		$bit1="rhel|scexe|rpm";
		$bit2="<|>|sles|README";
	}	
	elsif ( $osbit == 64 ){
	    $redhat="Red Hat Enterprise Linux|Red Hat"; #=~
	    $bit="i686|SUSE|sles|i586|Linux $osver |Linux $osver1|Linux x86\b|i386|.txt|rhel5\b|$xx|rhel5.|rpm.sig|.log"; #!~ hpsmh-7.3.1-4.x86_64.rpm
	    #$bit="i686|SUSE|sles|i586|Linux $osver |Linux $osver1|Linux x86\b|i386|.txt|rhel5\b|rhel7.|rhel5.|sig"; #!~ hpsmh-7.3.1-4.x86_64.rpm
		$bit1="rhel|scexe|rpm";  #=~ 
		$bit2="<|>|sles|README"; # !=
	}	
       	
	 $siz=length($ver1);
	 # print "===>+  siz is $siz\n +++ $ver1|scexe\n";
	  print " \n inputs are ====> \n\n @input\n";
    while ($line = <IN>){
        $status=0 if ($line =~ /<tr>/);
	    @add=()   if ($status == 0);
	
	if ($status == 1){
	     #print " lines 1111 ==>  $status \n";
		  #print " lines ==> R4 $line \n" if ( $add[1] =~ /HP OpenIPMI Device Driver for Red Hat Enterprise Linux 5/);
	   	$sp=$line; 
        @sp=split(/<|>/,$sp);
	    push(@add,"Version              : ".@sp[2]) if (@sp[2] =~ /\d+/);
	    
		if ( $line =~ /<p>/ ){
		    @a=split(/<P>|<br\/>|<p>/,$line); 
			
			foreach $b(@a) {
			
			    next if ( $b =~ /<\/p><\/td>/ );
				#print " R is => $b\n";
				@add[2]="Deploying component  : $b"  if ( $b !~ /<|>|README/ and $b =~ /$ver1/ and $b =~ /$kern/ and $b !~ /$bit/ );
				@add[2]="Deploying component  : $b"  if ( $b !~ m/$bit/ and $b !~ m/$ov+u0|$ov+u1|$ov+u2|$ov+u3|$ov+u4|$ov+u5|$ov+u6|$ov+u7|$ov+u8|$ov+u9|$ov+u10/ and $b !~ /xen|PAE/ and $b !~ /<|>|README/);
				@add[2]="Deploying component  : $b"  if (  $b =~ m/$ver1/ and $b !~ /xen|PAE/i and $b !~ /<|>|README/);
				@add[2]="Deploying component  : $b"  if (  $b =~ m/sles/ );
				
				$siz=scalar(@add);
				@add[3]=$head1 if (defined @add[2] );
		#print "@@@@@@@@@@@@@@@@@ lines ==> R1 @add[3] \n" if (@add[0] =~ /oadcom 1\/10 GbE Multifunction Drivers for Red Hat Enterprise Linux 6 x86/);
				foreach (@add){
				#print " input ver1 is ==> $ver1 and @add[2] \n";
					
				print RHEL "$_ \n"	if ( defined @add[2] and $b =~ /$ver1/  and $b =~ /$kern/ and $b !~ /$bit/  );
				print RHEL "$_ \n"  if (defined @add[2] and $b !~ m/$bit/ and $b !~ m/$ov+u0|$ov+u1|$ov+u2|$ov+u3|$ov+u4|$ov+u5|$ov+u6|$ov+u7|$ov+u8|$ov+u9|$ov+u10/ and $b !~ /xen|PAE/ and $b !~ /<|>|README/);	
				print RHEL "$_ \n"  if (defined @add[2] and $b =~ m/$ver1/ and $b !~ /xen|PAE/ and $b !~ /<|>|README/);	
				print DIFF "$_ \n"  if (defined @add[2] and $b =~ m/sles/); 
				}
			}
			
		}
      	
	}
	
	elsif ( $status == 3 ) {
	#print "************> $line " if ( $line =~ /Linux 64-bit/);
	#print " lines +++++++++++ ==> R4 $add[0] \n" if ( @add[0] =~ /HP Dynamic Smart Array SATA RAID Controller Driver for Red Hat Enterprise Linux 5/);
	    $sp=$line; 
		@sp=split(/<|>/,$sp);
	    push(@add,"Version              : ".@sp[2]) if (@sp[2] =~ /\d+|[HPDB]/); 
		 
	    if ( $line =~ /<p>/ ){
		    @a=split(/<P>|<br\/>|<p>/,$line);
			 foreach $b(@a){
			 #print " b is +++> $b \n" if ( $b =~ /hpsmh/);
			    next if ( $b =~ /<\/p><\/td>/ );
		        @add[2]="Deploying component  : $b"  if ( $b !~ /$bit2/ and $b =~ /$bit1/ and $b =~ /$ver1|scexe/ and $b =~ /$kern|scexe|rpm/ and $b !~ /$bit/);
				@add[2]="Deploying component  : $b"  if ( $b !~ m/$bit/ and $b !~ m/$ov+u0|$ov+u1|$ov+u2|$ov+u3|$ov+u4|$ov+u5|$ov+u6|$ov+u7|$ov+u8|$ov+u9|$ov+u10/ and $b !~ /<|>|README/ and $b !~ /xen|PAE/i);
				@add[2]="Deploying component  : $b"  if ( @add[0] =~ m/AMD64\/EM64T/ and $b !~ m/$ov+u0|$ov+u1|$ov+u2|$ov+u3|$ov+u4|$ov+u5|$ov+u6|$ov+u7|$ov+u8|$ov+u9|$ov+u10/ and $b !~ /<|>|README/ and $b !~ /xen|PAE/);
				@add[2]="Deploying component  : $b"  if ( @add[0] =~ m/AMD64\/EM64T/ and $b =~ m/$ver1/ and $b !~ /<|>|README/ and $b =~ /$kern/);
				@add[3]=$head1 if (defined @add[2] );   # hpsmh-7.3.1-4.x86_64.rpm
				#print " 3 version ==> n @add[2]  $b\n"if ( @add[0] =~ /Linux FCoE\/FC Driver Kit for HP Qlogic CNAs, HBAs and mezzanine HBAs/);
				#print " 9 version ==> n @add[2]  $b\n"if ( @add[2] =~ /hpsm/);
				#print " lines +++++++++++ ==> R4 $add[2] \n" if ( @add[0] =~ /HP Dynamic Smart Array SATA RAID Controller Driver for Red Hat Enterprise Linux 5/);
		        foreach (@add){
				#print " 3999999999999 version ==> n   @add[1]\n"if ( @add[0] =~ /HP H2xx SAS\/SATA Host Bus Adapter Driver for Red Hat Enterprise Linux 6/);
				   # print " 7 is ===> $_ = @add[2]\n"if (   @add[1] =~ /7.3.1-4/);
		             if (defined @add[2] and $b =~ /$ver1|scexe/i and $b =~ /$kern|scexe|rpm/ and $b !~ /$bit/ ){
					 #print " \n\n\n 3 version ==> n @add[2]  $b\n"if ( $_ =~ /Linux FCoE\/FC Driver Kit for HP Qlogic CNAs, HBAs and mezzanine HBAs/);
					 print RHEL "$_\n"
					 }
					 elsif (defined @add[2] and $b !~ m/$bit/ and $b !~ m/$ov+u0|$ov+u1|$ov+u2|$ov+u3|$ov+u4|$ov+u5|$ov+u6|$ov+u7|$ov+u8|$ov+u9|$ov+u10/ and $b !~ /xen|PAE/i ){
					 print RHEL "$_\n";
					 }
					 elsif (defined @add[2] and @add[0] =~ /AMD64\/EM64T/ and $b !~ m/$ov+u0|$ov+u1|$ov+u2|$ov+u3|$ov+u4|$ov+u5|$ov+u6|$ov+u7|$ov+u8|$ov+u9|$ov+u10/){
					 #print " ok ok \n";
					 print RHEL "$_\n";
					 }
					 elsif (defined @add[2] and @add[0] =~ /AMD64\/EM64T/ and $b =~ /$ver1/  and $b !~ m/$bit/){
					 #print " ok ok \n";
					 print RHEL "$_\n";
					 }
		        } 
		    }
	    }  
	}	
	
	
		
	if ( $line =~ m/b\// ){
		@head=split(/<|>/,$line);
		$head1="Sub                  : @head[6]" if defined(@head[6]);
	}
	#print " ===> proce @head[6]\n";
	#print " lines ==> R4@@@@@@@@@@@@@@@@@@ $line \n" if ( $line =~ /HP H2xx SAS\/SATA Host Bus Adapter Driver for Red Hat Enterpr/);
	if (  $line =~ m/$redhat/ and $line =~ m/$proce/  and $line !~ m/$bit/ ){
	    #print "@@@@@@@@@@@@@@@@@ lines ==> R1 $line \n" if ($line =~ /oadcom 1\/10 GbE Multifunction Drivers for Red Hat Enterprise Linux 6 x86/);
	    $sp=$line; 
        @sp1=split(/<|>/,$sp); 	  
	    $status=1;
	    push(@add,"\n\nComponent Name       : ".@sp1[2]);
		#print " input 0 is ==> $bit \n @add \n";
	}
	elsif (  $line =~ m/$redhat/ and $line !~ m/AMD|Intel/  and $line !~ m/$bit/ and $osbit =~ /32/ ){
	    #print " lines ==> R2 $line \n";
	    $sp=$line; 
        @sp1=split(/<|>/,$sp); 	  
	    $status=1;
	    push(@add,"\n\nComponent Name       : ".@sp1[2]);
		#print " input 0 is ==> $bit \n @add \n";
	}
	elsif (  $line =~ m/$redhat/ and $line !~ m/AMD|Intel/  and $line !~ m/$bit/  and $line !~ m/\(x86\)/  and $osbit == 64){
	    #print "@@@@@@@@@@@@@@@@@ lines ==> R1 $line \n" if ($line =~ /oadcom 1\/10 GbE Multifunction Drivers for Red Hat Enterprise Linux 6 x86/);
	    $sp=$line; 
        @sp1=split(/<|>/,$sp); 	  
	    $status=1;
	    push(@add,"\n\nComponent Name       : ".@sp1[2]);
		#print " input 0 is ==> $bit \n @add \n";
	}
	elsif ( $line !~ m/$bit/  and $line =~ m/AMD64\/EM64T/ and $line =~ m/$redhat/ and $line !~ m/\(x86\)/ and $line !~ m/Linux x86\b/  and $osbit == 64 ){
	    #print " lines ==> L4 $line \n" if ( $line =~ /HP H2xx SAS\/SATA Host Bus Adapter Driver for Red Hat Ent/);
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name       : ".@sp[2]);
	}
	elsif (  $line =~ m/Linux/ and $line =~ m/$proce/ and $line !~ m/$bit/ and $osbit == 32){
	    #print " lines ==> L1 $line \n";
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name       : ".@sp[2]);
	} 
	elsif (  $line =~ m/Linux/ and $line =~ m/$proce/ and $line !~ m/$bit/ and $osbit == 64 and $line !~ m/Linux x86\b/){
	    #print " lines ==> L1 $line \n";
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name       : ".@sp[2]);
	} 
	elsif (  $line =~ m/Linux/i and $line !~ m/$proce/ and $line !~ m/$bit/ and $osbit == 64 and $line !~ m/Linux x86\b|Linux \(x86\)/){
	    #print " lines ==> L1 $line \n";
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name       : ".@sp[2]);
	} 
	elsif (  $line =~ m/Linux/ and $line !~ m/AMD64|Intel/ and $line !~ m/$bit/ and $osbit == 32  ){
	    #print " lines ==> L2 $line \n";
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name       : ".@sp[2]);
	} 
	elsif ( $line !~ m/$bit/  and $line !~ m/AMD32|Intel/ and $line =~ m/Linux/i and $line !~ m/\(x86\)/ and $line !~ m/Linux x86\b/  and $osbit == 64 ){
	    $sp=$line; @sp=split(/<|>/,$sp); 
		$status=3;
	    push(@add,"\n\nComponent Name       : ".@sp[2]);
	}
	elsif ( $line !~ m/$bit/  and $line =~ m/AMD64\/EM64T/ and $line =~ m/Linux/i and $line !~ m/\(x86\)/ and $line !~ m/Linux x86\b/  and $osbit == 64 ){
	    #print " lines ==> R4 $line \n" if ( $line =~ /HP H2xx SAS\/SATA Host Bus Adapter Driver for Red Hat Enterprise Linux 5/);
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\n Component Name       : ".@sp[2]);
	}
 }	
 close(RHEL); close(IN);
 close(INPUT);close(DIFF);
 $flag123=0;
open (OUT1,"<./temp.txt")      || die " Could not open temp file \n";
open (IN123,">./temp123.txt")  || die " Could not open output file \n";

while ($line =<OUT1>){
			next if ($line =~ /^ 0/);
			#print " ======>  $line \n";
			$sta=0 if ($line =~ m/\s+/);
			$sta=1 if ($line !~ m/^\s+$/);
			@add=0 if ($sta==0);
			#print IN1 "\n " if ($sta==0);
		    if ($sta == 1){
			
				push(@add,$line);
				#print " add is => @add[3] \n";
				if(defined(@add[4]) and @add[4] =~ m/Firmware - Storage Controller/i ){
					foreach (@add){
						next if ($_ =~ /^0/);
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " @@@@@@@@@@@@@@@@@@@======> @add[1] \n" if (@add[1] =~ /x64/i);
						$flag123=1 if (@add[1] =~ /x64|64/i);
						#if (@add[1] =~ /$spa/i  and @add[3] =~ /$fc1/i){
							#print " @@@@@@@@@@@@@@@@======> $nicdriver ==> @add[4] \n";
							print IN123 "\n\n" if ($_ =~ /Component Name/);
							print IN123 "$_";
						#}
					}
				}
				}
}
print " flag123 is ++++>> $flag123 \n";
				
close(OUT1);close(IN123); 




 ################  NIC card filtering from output file ##################

 
 ## Mapping FC values  
$rhel={"kmod-cciss"=>[P800,P700m,P600,P400,P400i,E200,E200i,E500],"kmod-hpsa"=>[P840,P830,P830i,P822,P812,P731m,P712m,P711m,P441,P440ar,P440,P431,P430,
P421,P420,P420i,P411,P410,P410i,P244br,P230i,P222,P220i,P212,H241,H240,H240ar,H244br],"kmod-hpvsa"=>[B320i,B120i],"kmod-mpt2"=>[H222,H221,H220,H220i,H210i],"hpahcisr-kmp"=>[B110i]};
%rh=%$rhel;   
#print keys(%rh),"ok \n";

foreach ( keys(%rh)){
# print " \n keys are   => $_   \n";
 @a=@{$rhel->{"$_"}};undef(@g);
 @g = grep(/$controller\b/i,@a);
 $fc=$_ if @g;
 #print " values are =>  \@a   \n\n  Match is -> \@g  FC is -> $fc \n";
 }
 
 #print " values are =>   FC is###################### -> $fc \n";
%hash=('Netxtreme2'=>'Broadcom','HP-CNA-FC-Emulex-Enablement-Kit'=>'Emulex','hp-nx_nic'=>'Qlogic','mellanox-mlnx'=>'Mellanox','hp-e1000'=>'Intel','bfa'=>'Brocade');  	
$no=0;
@loop= @nicv  if ($nicsize >= $hdrsize);
@loop= @hdriv if ($nicsize <= $hdrsize);
#print " size is = $nicsize : size1 is = $hdrsize : loop is = @loop \n";
foreach $new(@loop){ 

 $no++;$no1 = $no;
 $no1 =$no - 1;
 #print " no is -----> $no & $new& no1 is = $no1\n";
 #print "  _______________> $new \n";

	$nic[$no1] =~ s/^\s+|\s+$//g; $nicv[$no1] =~ s/^\s+|\s+$//g;
  ###### Mapping NIC cards 
undef $fc1;
if ( $nic[$no1] =~ /Broadcom/i){
	#print "Broadcome \n";
	$nich={"cnu"=>['533FLR-T','534FLB','534FLR-SFP','534m,630FLB','630m','CN1100R'],"netxtreme2"=>['NC382i','NC382m','NC382T','NC532i','NC532m','530FLB','530FLR-SFP','530m','530SFP+'],
	"tg3"=>['330i','332T','331FLR','331T','331i',NC107i,NC105i,NC325m,NC326m,NC324i,NC325i,NC326i,NC150T,NC320,NC1020,NC67,NC77,NC320m,'331i-SPI','332i'],
	"iscsiuio"=>[NC382i,NC382m,NC382T,NC532i,NC532m,'534FLB','534FLR-SFP','534m','630FLB','630m'],"tg3sd"=>['330i','331FLR','331i','331i-SPI','331T','332i','332T'],};
} 
elsif( $nic[$no1] =~ /Emulex/i){ 
	#print "Emulex \n";
	$nich={"be2iscsi"=>['554FLB','554M','554FLR-SFP+','CN1100E','CN1000E','553m','553i','551m','551i'],"lpfc|HP-CNA-FC-Emulex-Enablement"=>['FC2243','FC2242','FC2143','FC2142','SN1000E','82E','81E','CN1000E','CN1100E','552m','NC553m','NC553i','NC552m','NC552SFP','NC551m','NC551i','NC550SFP','554m','554FLR-SFP','NC550m','LPe1205','LPe1105','SN1100E','556FLR-SFP','650FLB','650m','CN1200E'],
	"be2net"=>['552M','554FLB','554M','554FLR-SFP+','CN1000E','CN1100E','552SFP','550SFP','553m','553i','552m','551m','551i','550m','554FLR-SFP','556FLR-SFP','650FLB','650m','CN1200E','NC550SFP','NC550m','NC551m','NC551i','NC552m','NC552SFP','NC553i','NC553m','552m'],
	"HP Firmware Flash for Emulex Converged Network Adapters"=>['CN1000E','CN1100E','552M','NC553m','NC553i','NC552m','NC552SFP','NC551m','NC551i','NC550SFP','54M','554FLR-SFP+','554FLB','NC550m','CN1200E','650FLB','650M','556FLR-SFP+'],
	"HP Firmware Flash for Emulex Fibre Channel Host Bus Adapters"=>['FC2243','FC2242SR','FC2143','FC2142SR','SN1000E','SN1000E','82E','81E','LPe1205A','LPe1205','LPe1105','SN1100E','SN1100E','LPe1605'],};
} 
elsif( $nic[$no1] =~ /QLogic/i){
	#print "*********  QLogic *************\n";
	$nich={"hp-nx_nic"=>['375i','375T','522SFP','524SFP','510F','510C','512m','522m'],"hp-qla4xxx"=>['CN1000Q'],"nx-nic"=>['NC522SFP','NC552m','NC375i','NC375T'],
	"qla2xxx|HP-CNA-FC-hpqlgc"=>['QMH2672','QMH2572','FC1243','FC1143','FC1242','FC1142','SN1000Q','82Q','81Q','CN1000Q','526m','526FLR-SFP','526FLB','QMH2562','QMH2462'],
	"qla4xxx"=>['526FLR-SFP','CN1000Q'],"hp-qlcnic"=>['CN1000Q','523SFP'],"HP QLogic P3 Online Firmware Upgrade Utility|HP QLogic P2/P3 Online Firmware Upgrade Utility"=>['522SFP','375i','375T'],"HP QLogic P3P Online Firmware Upgrade Utility"=>['CN1000Q','523SFPSFP'],
	"HP Firmware Flash for QLogic Fibre Channel Host Bus Adapters"=>['FC1143 4Gb','FC1243','FC1142SR','FC1242SR','81Q','82Q','QMH2562','QMH2462','QMH2572','SN1000Q','QMH2672'],};
}
elsif( $nic[$no1] =~ /Mellanox/i){ 
	#print "Mellanox \n";
	$nich={"mellanox-mlnx|mlnx"=>['Nc542m','NC543i','544i','10GbE Dual Port Mezzanine'],};
}
elsif( $nic[$no1] =~ /Intel/i){ 
	#print "Intel \n";
	$nich={"hp-e1000"=>['NC340T','NC310F'],"ocsbbd"=>['361i','361FLB','361T','363i','364i','366FLR','366i','366m','367i','560FLB','P560FLR-SFP+','560m','560SFP+','561FLR-T','561T','562i'],
	"hp-ixgbevf"=>['560FLB','560FLR-SFP','560m','560SFP+','561FLR-T','561T','562i'],"hp-ixgbe"=>['562i','561T','561FLR-T','560SFP+','P560FLR-SFP+','560FLB'],"hp-e1000e|e1000e"=>['Intel','NC112i','NC112T','NC110T','NC364m','NC360m','NC364T','NC360T'],
	"hp-igb"=>['366m','366i','361FLB','361i','362i','365T','361T','NC362i','NC365T','366FLR','367i'],"hp-ixgbe"=>['560FLB','560SFP+'] };
}
elsif( $nic[$no1] =~ /Brocade/i){
	#print "Brocade \n";
	$nich={"bfa"=>['82B','42B','81B','41B'],"bfa|HP-FC-Brocade"=>['82B','81B','42B','41B','804'],"HP Firmware Flash for Brocade Fibre Channel Host Bus Adapters"=>['41B','42B','81B','82B','Brocade 804']};
}

 %rh=%$nich;
 foreach ( keys(%rh)){
# print " \n keys are   => $_   \n";
 @a=@{$nich->{"$_"}};undef(@g);
@g = grep(/\*|\b$nicv[$no1]\b/i,@a);
 $fc1.="\|$_" if @g;
 #my @foo = split (//,$fc1);$f=shift @foo;$fc1 = join '', @foo;
 #print " values are => FC1 is -> $fc1 \n";

 }
$fc1=reverse($fc1);chop($fc1);$fc1=reverse($fc1);
#print " Nic card mapping values are  => $f   FC1 is -> $fc1 \n";
 
$nic[$no1] =~ s/^\s+|\s+$//g; $nicv[$no1] =~ s/^\s+|\s+$//g;
  ###### Mapping NIC cards for firmware network 
undef $fnet1;
 if ( $nic[$no1] =~ /QLogic/i){
	#print " F W => QLogic \n";
	$fnet={"HP Firmware Flash for QLogic Fibre Channel Host Bus Adapters"=>['FC1143 4Gb','FC1243','FC1142SR','FC1242SR','81Q','82Q','QMH2562','QMH2462','QMH2572','SN1000Q','QMH2672']};
} 
elsif( $nic[$no1] =~ /Emulex/){ 
	#print " F W => Emulex \n";
	$fnet={"HP Firmware Flash for Emulex Fibre Channel Host Bus Adapters"=>['FC2243','FC2242SR','FC2143','FC2142SR','SN1000E','SN1000E','82E','81E','LPe1205A','LPe1205','LPe1105','SN1100E','SN1100E','LPe1605']};
} 
elsif( $nic[$no1] =~ /Brocade/){ 
	#print " F W => Brocade \n";
	$fnet={"HP Firmware Flash for Brocade Fibre Channel Host Bus Adapters"=>['41B','42B','81B','82B','Brocade 804']};
} 

 %rh1=%$fnet;
 foreach ( keys(%rh1)){
# print " \n keys are   => $_   \n";
 @a=@{$fnet->{"$_"}};undef(@g);
@g = grep(/\*|\b$nicv[$no1]\b/i,@a);
 $fnet1.="\|$_" if @g;
 #my @foo = split (//,$fc1);$f=shift @foo;$fc1 = join '', @foo;
 #print " values are => FC1 is -> $fc1 \n";

 }
$fnet1=reverse($fnet1);chop($fnet1);$fnet1=reverse($fnet1);
#print " Firmware network 2222   =>    Fnet1 is -> $fnet1 \n";


 
 
=head  
  if ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /NC370|NC371|NC373|NC374|NC380|NC382|NC382i|NC382m|NC382T|NC532i|530FLB|530FLR-SFP|530m|530SFP+]/i){
		$nicdriver="Netxtreme2";
	}
	elsif ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /530SFP+|530FLR-SFP+|530FLB|530M/i){
		$nicdriver="bnx2x";
	}
	elsif ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /533FLR-T|534FLB|534FLR-SFP|534m|630FLB|630m|CN1100R/i){
		$nicdriver="cnu";
	}
	elsif ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /330i|332T|331FLR|331T|331i|NC107i|NC105i|NC325m|NC326m|NC324i|NC325i|NC326i|NC150T|NC320|NC1020|NC67|NC77|NC320m|331i-SPI|332i/i){
		$nicdriver="tg3";                              
	}
	elsif ( $nic[$no1] =~ /Emulex/ and $nicv[$no1] =~ /554FLB|554M|554FLR-SFP+|CN1100E|CN1000E|553m|553i|551m|551i/i){
		$nicdriver="be2iscsi";
	}
	elsif ( $nic[$no1] =~ /Emulex/ and $nicv[$no1] =~ /FC2243|FC2242|FC2143|FC2142|SN1000E|82E|81E|CN1000E|CN1100E|552m|NC553m|NC553i|NC552m|NC552SFP|NC551m|NC551i|NC550SFP|554m|554FLR-SFP|NC550m|LPe1205|LPe1105|SN1100E|556FLR-SFP|650FLB|650m|CN1200E/i){
		$nicdriver="lpfc|HP-CNA-FC-Emulex-Enablement";
	}
	elsif ( $nic[$no1] =~ /Emulex/ and $nicv[$no1] =~ /552M|554FLB|554M|554FLR-SFP+|CN1000E|CN1100E|552SFP|550SFP|553m|553i|552m|551m|551i|550m|554FLR-SFP|556FLR-SFP|650FLB|650m|CN1200E|NC550SFP|NC550m|NC551m|NC551i|NC552m|NC552SFP|NC553i|NC553m|552m/i){
		$nicdriver="be2net";                                                                                        
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /375i|375T|522SFP|524SFP|510F|510C|512m|522m/i){
		$nicdriver="hp-nx_nic";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /CN1000Q/i){
		$nicdriver="hp-qla4xxx";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /NC522SFP|NC552m|NC375i|NC375T/i){
		$nicdriver="nx-nic";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /QMH2672|QMH2572|FC1243|FC1143|FC1242|FC1142|SN1000Q|82Q|81Q|CN1000Q|526m|526FLR-SFP|526FLB|QMH2562|QMH2462/i){
		$nicdriver="qla2xxx|HP-CNA-FC-hpqlgc";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /526FLR-SFP|CN1000Q/i){
		$nicdriver="qla4xxx";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /CN1000Q|523SFP/i){
		$nicdriver="hp-qlcnic";
	}
	elsif ( $nic[$no1] =~ /Mellanox/ and $nicv[$no1] =~ /Nc542m|NC543i|10GbE Dual Port Mezzanine/i){
		$nicdriver="mellanox-mlnx|mlnx";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /NC340T|NC310F/i){
		$nicdriver="hp-e1000";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /361i|361FLB|361T|363i|364i|366FLR|366i|366m|367i|560FLB|P560FLR-SFP+|560m|560SFP+|561FLR-T|561T|562i/i){
		$nicdriver="ocsbbd";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /560FLB|560FLR-SFP|560m|560SFP+|561FLR-T|561T|562i/i){
		$nicdriver="hp-ixgbef";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /562i|561T|561FLR-T|560SFP+|P560FLR-SFP+|560FLB/i){
		$nicdriver="hp-ixgbe";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /Intel|NC112i|NC112T|NC110T|NC364m|NC360m|NC364T|NC360T/i){
		$nicdriver="hp-e1000e|e1000e";                        
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /366m|366i|361FLB|361i|362i|365T|361T|NC362i|NC365T|366FLR|367i/i){
		$nicdriver="hp-igb";                          
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /560FLB|560SFP+/i){
		$nicdriver="hp-ixgbe";
	}
	elsif ( $nic[$no1] =~ /Brocade/ and $nicv[$no1] =~ /82B|42B|81B|41B/i){
		$nicdriver="bfa";
	}
	elsif ( $nic[$no1] =~ /Brocade/ and $nicv[$no1] =~ /82B|81B|42B|41B|804/i){
		$nicdriver="bfa|HP-FC-Brocade";
	}
=cut



	#print " nic driver =>>>> $new   ++> $nicdriver\n";
	$dir.="rhel-12.txt" if ($no1 == 0);
	open (OUT,"<./temp.txt")       || die " Could not open data file \n";
	#open (IN1,">>./temp/rhel-1.txt")    || die " Could not open reinsert file \n";
	open (IN12,">>./output123.txt")  || die " Could not open output file \n";
	$ilo="Lights-Out 4" if ($rom =~ /Gen8|G8|Gen9|G9/);
	$ilo="Lights-Out 3" if ($rom =~ /Gen7|G7/);
	$ilo="Lights-Out 2" if ($rom =~ /Gen6|G6/);
	$ilo1="iLO 3/4" if ($rom =~ /Gen8|G8|G9|Gen9/);
	$ilo1="iLO 3" if ($rom =~ /Gen7|G7/);
	$ilo1="iLO 2" if ($rom =~ /Gen6|G6/);	
	$ilo2="Gen[769]" if ($rom =~ /Gen8|G8/);
	$ilo2="Gen[869]" if ($rom =~ /Gen7|G7/);
	$ilo2="Gen[879]" if ($rom =~ /Gen6|G6/);
	$ilo2="Gen[876]" if ($rom =~ /Gen9|G9/);
	
	
	 
	#### Filtering output file data 			
		while ($line =<OUT>){
			next if ($line =~ /^ 0/);
			$sta=0 if ($line =~ m/\s+/);
			$sta=1 if ($line !~ m/^\s+$/);
			@add=0 if ($sta==0);
			if ($sta == 1){
			    push(@add,$line);
				#print " add is => @add[1] \n";
				$flag=0;
					if(defined(@add[4]) and @add[4] =~ m/Software - Network/i  ){
							foreach (@add){
								next if ($_ =~ /^0/);
								#print " ======> $rom ==> \@add[1] @nic[$no1] === $harddrive \n";
								$spa = @nic[$no1];
						        $spa   =~ s/^\s+|\s+$//g;
								if (@add[1] =~ /$spa/i and @add[3] =~ /$fc1/i){
								#print " ======> $nicdriver ==> @add[4] \n";
									print IN12 "\n\n" if ($_ =~ /Component Name/);
									print IN12 "$_";
								}
								elsif(@add[1] !~ /Broadcom|Emulex|QLogic|Mellanox|Intel|Brocade/i and $no1 == 0){
									print IN12 "\n\n" if ($_ =~ /Component Name/);
									print IN12 "$_";
								}
							}
						}
				elsif(defined(@add[4]) and @add[4] =~ m/Driver - Network/i){
					foreach (@add){
						next if ($_ =~ /^0/);
						$n   =~ s/^\s+|\s+$//g;
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$spa/i and  @add[3] =~ /$fc1/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
					elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Network/i){
						foreach (@add){
							next if ($_ =~ /^0/);
							$n   =~ s/^\s+|\s+$//g;
							$spa = @nic[$no1];
							$spa   =~ s/^\s+|\s+$//g;
							#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
							$hdriv[$no1]=~ s/^\s+|\s+$//g;
							if (@add[1] =~ /Qlogic/i and $spa =~ /Qlogic/i){
								print IN12 "\n\n" if ($_ =~ /Component Name/ and @add[1] =~ /$fc1/i);
								print IN12 "$_"   if (@add[1] =~ /$fc1/i);
							}
							elsif (@add[1] =~ /$spa/i ){
								#print " ======> $nicdriver ==> @add[4] \n";
								print IN12 "\n\n" if ($_ =~ /Component Name/);
								print IN12 "$_";
							}
							elsif (@add[1] =~ /$nicv[$no1]/i ){
								#print " ======> $nicdriver ==> @add[4] \n";
								print IN12 "\n\n" if ($_ =~ /Component Name/);
								print IN12 "$_";
						   }		
						}
					}
				elsif(defined(@add[1]) and @add[4] =~ m/Network|Driver - Storage Fibre Channel/ ){
					foreach (@add){
						next if ($_ =~ /^0/);
						 #print " __________ $_ \n";
						$n   =~ s/^\s+|\s+$//g;
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ok $spa  ::: $nicdriver :: $fc \n " if (@add[3] =~ /$nicdriver/i);
						if (@add[1] =~ /$spa/i and  @add[3] =~ /$fc1/i and @add[3] =~ /$fc/ and $no <= $nicsize){ 
							#print " nicd *************> @nic[$no1] and nic version =  $nicdriver\n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);$flag=1;
							print IN12 "$_";
						}
						elsif (@add[1] =~ /$spa/i  and @add[3] =~ /$fc/ and $no <= $nicsize){ 
							#print " nicd *************> @nic[$no1] and nic version =  $nicdriver\n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);$flag=1;
							print IN12 "$_";
						}
						elsif (@add[1] =~ /$spa/i  and  @add[3] =~ /$fc1/i and $no <= $nicsize and @add[3] !~ /kmod-cciss|kmod-hpsa|kmod-mpt2|kmod-hpvsa/i){ 
							#print " nicd *************> @nic[$no1] and nic version =  $nicdriver\n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);$flag=1;
							print IN12 "$_";
						}
						elsif (@add[1] =~ /$spa/i and @add[3] =~ /scexe|txt|rpm/ and $no <= $nicsize and @add[3] !~ /kmod-cciss|kmod-hpsa|kmod-mpt2|kmod-hpvsa/i and $flag==0){ 
							#print " nicd *************> @nic[$no1] and nic version =  $nicdriver\n";
							#print IN12 "\n\n" if ($_ =~ /Component Name/);
							#print IN12 " 4 $_";
						}
						
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Software - Storage Fibre Channel HBA/){
					foreach (@add){
						next if ($_ =~ /^0/);
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /Qlogic/i and $spa =~ /Qlogic/i ){
							print IN12 "\n\n" if ($_ =~ /Component Name/ and @add[1] =~ /Qlogic/i and $no1 == 0);
							print IN12 "$_"   if (@add[1] =~ /Qlogic/i and $no1 == 0);
						}
						elsif (@add[3] =~ /$spa/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Storage Fibre Channel/){
					foreach (@add){
						next if ($_ =~ /^0/);
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$fnet1/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/BIOS - System ROM/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						@roms=split(/\s+/,$rom);
						$rom2="Gen8|G8" if ($roms[1] =~ /Gen8|G8/);
						$rom2="Gen7|G7" if ($roms[1] =~ /Gen7|G7/);
						$rom2="Gen6|G6" if ($roms[1] =~ /Gen6|G6/);
						$rom2="Gen9|G9" if ($roms[1] =~ /Gen9|G9/);
						#print " ####################======> $rom ==> @add[1] \n";
						if (@add[1] =~ /$roms[0]/i and @add[1] =~ /$rom2/){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
											
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Blade Infrastructure/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						@roms=split(/\s+/,$rom);
						$rom2="Gen8|G8" if ($roms[1] =~ /Gen8|G8/);
						$rom2="Gen7|G7" if ($roms[1] =~ /Gen7|G7/);
						$rom2="Gen6|G6" if ($roms[1] =~ /Gen6|G6/);
						$rom2="Gen9|G9" if ($roms[1] =~ /Gen9|G9/);$rom5=64 if ($osbit =~ /64/); $rom5 ='BL' if ($osbit =~ /32/);
						#print "###################==> $rom5 \n";
						if ($roms[0] =~ /BL/i and @add[1] =~ /$rom5/i){
							#print " @@@@@@@@@@@@@@@======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Driver - Storage Controller/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						
						#print " controler is ==> $controller =$add[1] = fc is + $fc \n";
						$con3="Smart Array" if ($controller =~ /P/i);
						$con3="SATA RAID|SATA" if ($controller =~ /B/i);
						$con3="H2xx" if ($controller =~ /H/i);
							if ( @add[3] =~ /$fc/){
								print IN12 "\n\n" if ($_ =~ /Component Name/);
								print IN12 "$_";	
							}
							elsif( @add[1] =~ /$controller/i ){
								#print " ======> $nicdriver ==> @add[4] \n";
								print IN12 "\n\n" if ($_ =~ /Component Name/);
								print IN12 "$_";
						   }	
						   elsif( @add[1] =~ /$con3/i ){
								#print " ======> $nicdriver ==> @add[4] \n";
								#print IN12 "\n\n" if ($_ =~ /Component Name/);
								#print IN12 " 3 $_";
						   }
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Storage Controller/ and $no1 == 0 and $flag123 == 1 and $osbit == 64){
					foreach (@add){
						next if ($_ =~ /^0/);
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$controller/i and @add[1] =~ /x64|64/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Storage Controller/ and $no1 == 0 and $flag123 == 0 and $osbit == 64){
					foreach (@add){
						next if ($_ =~ /^0/);
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$controller/i ){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Storage Controller/ and $no1 == 0  and $osbit == 32){
					foreach (@add){
						next if ($_ =~ /^0/);
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$controller/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - SAS Storage Disk|Firmware - SATA Storage Disk/ and $no <= $hdrsize){
					#print " hard drive => $hdriv[$no1] \n";
					foreach (@add){
						next if ($_ =~ /^0/);
						$hdriv[$no1]=~ s/^\s+|\s+$//g; $hd=64 if ($osbit =~ /64/i);$hd=$hdriv[$no1] if ($osbit =~ /32/i);
						if (@add[1] =~ /$hdriv[$no1]/ and @add[1] =~ /$hd/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Lights-Out Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						
						if (@add[1] =~ /$ilo/){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Software - System Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						next if (@add[1] =~ /HP ProLiant Agentless Management Service/i and $rom =~ /Gen6|G6|Gen7|G7/i );
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Power Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						@array = ( $rom =~ m/../g );
						#print " ======> @array[0]  = $nicdriver ==> @add[4] \n";
						next if ( $rom !~ /DL580/i and @add[1] =~ /DL580/i ); 
						if ( $rom !~ /DL580/i ){
							if ( @add[1] =~ /@array[0]/ | @add[1] !~ /BL|DL|ML/ and @add[1] !~ /$ilo2/i){
								print IN12 "\n\n" if ($_ =~ /Component Name/);
								print IN12 "$_";
							}
						}
						elsif ( $rom =~ /DL580/i ){
							if ( @add[1] =~ /DL580/  and @add[1] !~ /$ilo2/i){
								print IN12 "\n\n" if ($_ =~ /Component Name/);
								print IN12 "$_";
							}
							
						}
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Driver - System Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						@array = ( $rom =~ m/../g );
						#print " ======> @array[0]  = $nicdriver ==> @add[4] \n";
						
						if ( @add[1] =~ /$ilo1/i and @add[1] !~ /$ilo2/i){
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
						if ( @add[1] !~ /ilo/i and @add[1] !~ /$ilo2/i){
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "%%%%% $_";
						}	
					}
				}
				elsif  (defined(@add[4]) and @add[4] !~ m/Network|Firmware - Storage Controller/ and $no1 == 0 ){
					#print " ==> network \n";
					#print " ==> network \n";
					foreach (@add){
						#print " ======>  $_ \n";
						@zz=split(/:/,@add[4]);#print " \n\nn  ----------> @zz[1] \n";
						next if (@zz[1] !~ /-/i);
						next if ($_ =~ /^0|^ /);
						print IN12 "\n\n" if ($_ =~ /Component Name/);
						print IN12 "$_";
					}	
				}
           	}		
			}
		close(OUT);	close(IN);close(IN12);	
	}
open (OUT6,"<./output123.txt")       || die " Could not open temp file \n";
open (IN6,">$ofile")   || die " Could not open output file \n";

while ($line =<OUT6>){
#print  "$line  \n";
	if ( $line =~ /Deploying component/i ){
		#print " PPPPPPPPPPPPPPPPPPPPPPPPPP\n";
		@xx[0]="$line";
	}
	elsif ( $line =~ /Component Name/i ){
		@xx[1]="$line";
	}
	elsif ( $line =~ /Version/i ){
		@xx[2]="$line";
	}
	elsif ( $line =~ /Sub/i ){
		@xx[3]="$line";
	}
	if (defined @xx[3]){
		#print " KKKKKKKKKKKKKKKKKKKKKKKKKKKKK\n";
		foreach(@xx){
			print IN6 "\n\n" if ( $_ =~ /Deploying component/);
			print IN6 "$_";
		}
		undef(@xx);		
	}
				
}

				
close(OUT6);close(IN6); 
	
unlink("./temp.txt");unlink("./temp123.txt");unlink("./output123.txt");unlink("./diff.txt");
}
1;