#!\usr\bin\perl

use File::Basename;

$sfile=$ARGV[0];$ofile=$ARGV[1];$ifile=$ARGV[2];#$sername=$ARGV[0]
my($file, $dir, $ext) = fileparse($ofile);
#print "Directory: " . $dir . "\n";print "File:      " . $file . "\n";
open (IN,"$sfile")               || die " Could not open source file \n";
open (WIN,">./temp.txt")         || die " Could not open output file \n"; 
open (INPUT,"<$ifile")           || die " Could not open win-input file \n";
  ## perl windows.pl ./temp/contents.html  ./temp/win.txt  ./input.txt 

	while ( $in = <INPUT> ){
        #print " $in \n";
        push(@input,$in) if ( $in !~ /#|^\s/ );
    }  
    $os = $input[1] ; $ver1  = $input[1]; $kern  = $input[2];	$osbit = $input[3]; $proce = $input[4];
	$nicdri= $input[5]; $nicver= $input[6]; $rom   = $input[7]; $controller = $input[8];
	$harddrive = $input[9];$nicspeed=$input[11];
	@nic=split(/,/,$nicdri);@nicv=split(/,/,$nicver);@hdriv=split(/,/,$harddrive);
	$nicsize=scalar(@nic);$hdrsize=scalar(@hdriv);
	#print " \n sizes are  => $nicsize == $hdriv\n nic ver => @nicv \n";
	
	$ver1   =~ s/^\s+|\s+$//g;$kern  =~ s/^\s+|\s+$//g;	$osbit  =~ s/^\s+|\s+$//g;$proce =~ s/^\s+|\s+$//g;
	$nicdri =~ s/^\s+|\s+$//g;$nicver=~ s/^\s+|\s+$//g; $rom    =~ s/^\s+|\s+$//g;$controller =~ s/^\s+|\s+$//g;
	$harddrive =~ s/^\s+|\s+$//g;$nicspeed =~ s/^\s+|\s+$//g;
	print " \n\n\n  \$nicspeed  $nicspeed  \n";
	if ( $osbit == 32 ){
		$redhat="Windows Server 2008|Windows";
	    $bit="x64 Editions|R2|2012|x64|64-bit|[xX]64";
		$bit1="Windows";
		$bit2="<|>|README";
	}	
	elsif ( $osbit == 64 ){
	    $redhat="Windows Server 2008|Windows";
	    $bit="i686|x86|X86|R2|2012";
		$bit1="x64|X64" ;
		$bit2="<|>|README";
	}
        	
	
	print " inputs are++ ====> $os \n @input\n";
    while ($line = <IN>){
        $status=0 if ($line =~ /<tr>/);
	    @add=()   if ($status == 0);
	
	if ($status == 1){
	     #print " lines 1111 ==>  $status \n";
	   	$sp=$line; 
        @sp=split(/<|>/,$sp);
	    push(@add,"Version                : ".@sp[2]) if (@sp[2] =~ /\d+/);
	    
		if ( $line =~ /<p>/ ){
		    @a=split(/<P>|<br\/>|<p>/,$line); 
			
			foreach $b(@a) {
			
			    next if ( $b =~ /<\/p><\/td>/ );
				@add[2]="Deploying component R1 : $b" if ( $b !~ /<|>|README/ and $b !~ /$bit/ );
				@add[2]="Deploying component R2 : $b"  if ( $b !~ m/$bit/  and $b !~ /<|>|README/);
				#print " input ver1 is ==> ++  ::  $add[2]\n";
				$siz=scalar(@add);
				@add[3]=$head1 if (defined @add[2] );
		
				foreach (@add){
				#print " ++input ver1 is ==> $ver1 and @add[2] \n";
					
				print WIN "$_ \n"	if ( defined @add[2] and $b =~ /$ver1/  and $b =~ /$kern/ and $b !~ /$bit/  );
				#print WIN "$_ \n"  if (defined @add[2] and $b !~ m/$bit/ and $b !~ m/5u5|5u6|5u7|5u8|5u9|5u10/ and $b !~ /<|>|README/);	
					
				}
			}
			
		}
      	
	}
	
	elsif ( $status == 3 ) {
	    $sp=$line; 
        @sp=split(/<|>/,$sp);
	    push(@add,"Version                : ".@sp[2]) if (@sp[2] =~ /\d+|[HPDB]/); 
	  
	    if ( $line =~ /<p>/ ){
		
	        @a=split(/<P>|<br\/>|<p>/,$line);
			
		    foreach $b(@a){
			
			    next if ( $b =~ /<\/p><\/td>/ );
		        @add[2]="Deploying component L1 : $b"  if ( $b !~ /<|>|README/ and $b !~ /$bit2/ and $b =~ /$bit1/ and $b =~ /$ver1|scexe/ and $b =~ /$kern|scexe/ and $b !~ /$bit/);
				@add[2]="Deploying component L2 : $b"  if ( $b !~ m/sles/ and $b !~ m/5u5|5u6|5u7|5u8|5u9|5u10/ and $b !~ /<|>|README/ and $b !~ /xen|PAE/);
				@add[3]=$head1 if (defined @add[2] );
				
		        foreach (@add){
				   # print " version $ver1 \n";
		             if (defined @add[2] and $b =~ /$ver1|scexe/ and $b =~ /$kern|scexe/ and $b !~ /$bit/){
					 print WIN "$_ \n"
					 }
					 elsif (defined @add[2] and $b !~ m/sles|$bit/ and $b !~ m/5u5|5u6|5u7|5u8|5u9|5u10/){
					 print WIN "$_ \n";
					 }
		        } 
		    }
	    }  
	}	
	
	
		
	if ( $line =~ m/b\// ){
		@head=split(/<|>/,$line);
		$head1="Sub                    : @head[6]";
	}
	#print " ===> proce $proce\n";
	if (  $line =~ m/$redhat/ and $line =~ m/$proce/  and $line !~ m/$bit/ and $line =~ /$bit1/){
	   # print " lines ==> R1 $line \n";
	    $sp=$line; 
        @sp1=split(/<|>/,$sp); 	  
	    $status=1;
	    push(@add,"\n\nComponent Name  R      : ".@sp1[2]);
		#print " input 0 is ==> $bit \n @add \n";
	}
	elsif (  $line =~ m/$redhat/ and $line !~ m/AMD|Intel/  and $line !~ m/$bit/ and $line =~ /$bit1/){
	    #print " lines ==> R2 $line \n";
	    $sp=$line; 
        @sp1=split(/<|>/,$sp); 	  
	    $status=1;
	    push(@add,"\n\nComponent Name  R2     : ".@sp1[2]);
		#print " input 0 is ==> $bit \n @add \n";
	}
	elsif (  $line =~ m/Windows/ and $line =~ m/$proce/ and $line !~ m/$bit/ and $line =~ /$bit1/){
	    #print " lines ==> L1 $line \n";
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name L1      : ".@sp[2]);
	} 
	elsif (  $line =~ m/Windows/ and $line !~ m/AMD|Intel/ and $line !~ m/$bit/ and $line =~ /$bit1/ ){
	    #print " lines ==> L2 $line \n";
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name L2      : ".@sp[2]);
	} 
 }	
 close(WIN); close(IN); close(INPUT);
 
$rhel={"HP ProLiant Integrated SATA Controller for Windows"=>["Integrated SATA Controller"],
"HP H2xx  SAS/SATA Host Bus Adapter Driver for Microsoft Windows"=>[H222,H221,H220,H220i,H210i],
"HP ProLiant Smart Array SAS/SATA Controller Driver for Windows"=>[P822,P822se,P812,P800,P721m,P712m,P711m,P700m,P600,P421,P420,
P420i,P411,P410,P410i,P400,P400i,P222,P220i,P212,P210,E200,E200i,E500,D2220sb,SB40c],
"HP ProLiant Smart Array HPCISSS3 Controller Driver for Windows"=>[P840,P831,P830,P830i,P822,P731m,P721m,P531,P530,P441,P440ar,P440,
P431,P430,P430i,P421,P420,P420i,P244br,P230i,P222,P220i,H241,H240,H240ar,H244br],"HP ProLiant Smart Array Embedded SATA RAID Controller Driver for Microsoft Windows"=>[B110i],
"HP ProLiant Dynamic Smart Array RAID Controller Driver for Microsoft Windows"=>['B120i','B320i'],"HP Dynamic Smart Array B140i Controller Driver for Windows"=>[B140i]};
%rh=%$rhel;
#print keys(%rh),"ok \n";
$rcon="HP ProLiant Integrated SATA Controller for Windows|HP H2xx SAS/SATA Host Bus Adapter Driver for Microsoft Windows|HP ProLiant Smart Array SAS/SATA Controller Driver for Windows|HP ProLiant Smart Array HPCISSS3 Controller Driver for Windows";
foreach ( keys(%rh)){
# print " \n keys are   => $_   \n";
 @a=@{$rhel->{"$_"}};undef(@g);
 @g = grep(/$controller\b/i,@a);
 $fc.="|$_" if @g;
# print " values are =>  @a   \n\n  Match is -> @g  FC is -> $fc \n";
 }
 $fc=reverse($fc);chop($fc);$fc=reverse($fc);
  if ($fc =~ /HPCISSS3/i){
	  @con4=split(/\|/,$fc);
	  #print "&&&&&   @con4[0] \n &&& @con4[1]\n";
	  @fc4 = grep/HPCISSS3/i,@con4;	$fc=@fc4[0];
  }
  print " values are =>   FC is###################### -> $fc \n";
 $no=0;
@loop= @nicv  if ($nicsize >= $hdrsize);
@loop= @hdriv if ($nicsize <= $hdrsize);
print " size is = $nicsize : size1 is = $hdrsize : loop is = @loop \n";
foreach $new(@loop){
     $no++;$no1 = $no;$nicdriver="";
	 $no1 =$no - 1;
	#print " no is -----> $no  & no1 is = $no1\n";
	#print " nicd *************> @nic[$no1] and nic version =  $nicv[$no1] =spa $spa\n";
## NIC card filtering	
$nic[$no1] =~ s/^\s+|\s+$//g; $nicv[$no1] =~ s/^\s+|\s+$//g;

undef $fc1;
 if ( $nic[$no1] =~ /Broadcom/i){
	print "Broadcome \n";
	$nich={"HP Broadcom 1Gb Driver for Windows server x64"=>['NC107i','NC325','330i','331FLR','331i','331T','332i','332T'],
	"HP Broadcom 1Gb Multifunction Drivers for Windows Server x64 Editions"=>['NC382T', 'NC373T', 'NC373F', 'NC382i','NC382m'],
	"HPBroadcom10-20GbE Multifunction Drivers for Windows"=>['NC532i','NC532m','530FLB','530FLR-SFP+','530M','530T','533FLR-T','534FLB','534FLR-SFP+','534M','536FLB','630FLB','630M','CN1100R']};
} 
elsif( "Emulex" =~ /$nic[$no1]/i ){ 
	print "Emulex \n";
	$nich={"HP Emulex 10GbE Driver for Windows Server 2012"=>['CN1000E','CN1100E','CN1200E','NC550SFP', 'NC550m','NC551m','NC551i','NC552m','NC552SFP','553i','553m','552M','554FLB','554FLR-SFP','554M','556FLR-SFP+','554M','556FLR-SFP+','650FLB','650M'],
	"HP Emulex 10GbE iSCSI Driver for Windows"=>['CN1000E','CN1100E','CN1200E','NC551m','NC551i','553i','553m','554FLB','554FLR-SFP','554M','556FLR-SFP+','650FLB','650M'],
	"HP Storage Fibre Channel Adapter Kit for the x64 Emulex Storport Driver"=>['FC2243','FC2242','FC2143','FC2142SR','84E','SN1100E','SN1000E','82E','81E','LPe1605','LPe1205','LPe1105'],
	"HP Storage Fibre Channel Over Ethernet Adapter Kit for the x64 Emulex Storport Driver"=>['CN1200E','CN1100E','CN1000E','650FLB','650M','556FLR-SFP+','NC553m','NC553i','NC551m','NC551i','554M','554FLR-SFP+','554FLB']};
} 
elsif( "QLogic" =~ /$nic[$no1]/i){
	print "QLogic \n";
	$nich={"HP QLogic P3P iSCSI Driver for Windows Server"=>['CN1000Q','526FLR-SFP+'],"HP QLogic P3P Multifunction Driver for Windows Server 2012"=>['CN1000Q','NC375i','NC375T','526FLR-SFP+','523SFP','522SFP'],
	"HP Storage Fibre Channel Adapter Kit for the QLogic Storport Driver for Windows Server 2012 and 2012 R2"=>['QMH2627','QMH2572','FC1243','FC1143','FC1242SR','FC1142SR','SN1000Q','82Q','81Q','QMH2562','QMH2464'],
	"HP Storage Fibre Channel Adapter Kit for the x86 QLogic Storport Driver"=>['FC1143','FC1243','FC1142','FC1242','81Q','82Q','QMH2562','QMH2462','QMH2572','QMH2672','SN1000Q'],
	"HP Storage Fibre Channel Over Ethernet Adapter Kit for the QLogic Storport Driver for Windows Server 2012 and 2012 R2"=>['CN1000Q','526FLR-SFP+'],
	"hp-qlcnic"=>['CN1000Q','523SFP'],};
}
elsif( "Mellanox" =~ /$nic[$no1]/i ){ 
	print "Mellanox \n";
	$nich={"mellanox-mlnx|mlnx"=>['Nc542m','NC543i','10GbE Dual Port Mezzanine'],};
}
elsif( "Intel" =~ /$nic[$no1]/i ){ 
	print "Intel \n";
	$nich={"HP Intel E1R Driver for Windows Server 2012"=>['NC365T','361i','361FLB','361T','363i','364i','366i','366FLR','366M','367i'],
	"HP Intel ixn-ixt Drivers for Windows Server"=>['560FLB','560 FLR-SFP+','560SFP+','560M','561FLR-T','561T','562i'],
	"HP NC-Series Intel E1E Driver for Windows Server 2008 x64 Editions"=>['NC110T','NC360m','NC360T','NC364m','NC364T'],
	"HP NC-Series Intel E1Q Driver for Windows Server 2012"=>['NC112T','NC112i','NC362i'], };
}
elsif( "Brocade" =~ /$nic[$no1]/i ){
	print "Brocade \n";
	$nich={"HP Storage Brocade Storport Fibre Channel Host Bus Adapter Driver for Microsoft Windows Server 2012"=>['82B','81B','42B','41B'],"bfa|HP-FC-Brocade"=>['82B','81B','42B','41B','804'],};
}

 %rh=%$nich;
foreach ( keys(%rh)){
# print " \n keys are   => $_   \n";
 @a=@{$nich->{"$_"}};undef(@g);
@g = grep(/\*|\b$nicv[$no1]\b/i,@a);
 $fc1.="\|$_" if @g;
 #my @foo = split (//,$fc1);$f=shift @foo;$fc1 = join '', @foo;
 #print " values are => FC1 is -> $fc1 \n";

 }

$fc1=reverse($fc1);chop($fc1);$fc1=reverse($fc1);
print " \n Nic mapping => $nic[$no1] -> $nicv[$no1] FC1 is-> $fc1\n";

=head
%hash=('Netxtreme2'=>'Broadcom','HP-CNA-FC-Emulex-Enablement-Kit'=>'Emulex','hp-nx_nic'=>'Qlogic','mellanox-mlnx'=>'Mellanox','hp-e1000'=>'Intel','bfa'=>'Brocade');  	
  if ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /NC370|NC371|NC373|NC374|NC380|NC382|NC382i|NC382m|NC382T|NC532i|530FLB|530FLR-SFP|530m|530SFP+]/i){
		$nicdriver="Netxtreme2";
	}
	elsif ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /530SFP+|530FLR-SFP+|530FLB|530M/i){
		$nicdriver="bnx2x";
	}
	elsif ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /533FLR-T|534FLB|534FLR-SFP|534m|630FLB|630m|CN1100R/i){
		$nicdriver="cnu";
	}
	elsif ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /330i|332T|331FLR|331T|331i|NC107i|NC105i|NC325m|NC326m|NC324i|NC325i|NC326i|NC150T|NC320|NC1020|NC67|NC77|NC320m|331i-SPI|332i/i){
		$nicdriver="tg3";                              
	}
	elsif ( $nic[$no1] =~ /Emulex/ and $nicv[$no1] =~ /554FLB|554M|554FLR-SFP+|CN1100E|CN1000E|553m|553i|551m|551i/i){
		$nicdriver="be2iscsi";
	}
	elsif ( $nic[$no1] =~ /Emulex/ and $nicv[$no1] =~ /FC2243|FC2242|FC2143|FC2142|SN1000E|82E|81E|CN1000E|CN1100E|552m|NC553m|NC553i|NC552m|NC552SFP|NC551m|NC551i|NC550SFP|554m|554FLR-SFP|NC550m|LPe1205|LPe1105|SN1100E|556FLR-SFP|650FLB|650m|CN1200E/i){
		$nicdriver="lpfc|HP-CNA-FC-Emulex-Enablement";
	}
	elsif ( $nic[$no1] =~ /Emulex/ and $nicv[$no1] =~ /552M|554FLB|554M|554FLR-SFP+|CN1000E|CN1100E|552SFP|550SFP|553m|553i|552m|551m|551i|550m|554FLR-SFP|556FLR-SFP|650FLB|650m|CN1200E|NC550SFP|NC550m|NC551m|NC551i|NC552m|NC552SFP|NC553i|NC553m|552m/i){
		$nicdriver="be2net";                                                                                        
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /375i|375T|522SFP|524SFP|510F|510C|512m|522m/i){
		$nicdriver="hp-nx_nic";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /CN1000Q/i){
		$nicdriver="hp-qla4xxx";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /NC522SFP|NC552m|NC375i|NC375T/i){
		$nicdriver="nx-nic";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /QMH2672|QMH2572|FC1243|FC1143|FC1242|FC1142|SN1000Q|82Q|81Q|CN1000Q|526m|526FLR-SFP|526FLB|QMH2562|QMH2462/i){
		$nicdriver="qla2xxx|HP-CNA-FC-hpqlgc";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /526FLR-SFP|CN1000Q/i){
		$nicdriver="qla4xxx";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /CN1000Q|523SFP/i){
		$nicdriver="hp-qlcnic";
	}
	elsif ( $nic[$no1] =~ /Mellanox/ and $nicv[$no1] =~ /Nc542m|NC543i|10GbE Dual Port Mezzanine/i){
		$nicdriver="mellanox-mlnx|mlnx";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /NC340T|NC310F/i){
		$nicdriver="hp-e1000";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /361i|361FLB|361T|363i|364i|366FLR|366i|366m|367i|560FLB|P560FLR-SFP+|560m|560SFP+|561FLR-T|561T|562i/i){
		$nicdriver="ocsbbd";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /560FLB|560FLR-SFP|560m|560SFP+|561FLR-T|561T|562i/i){
		$nicdriver="hp-ixgbef";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /562i|561T|561FLR-T|560SFP+|P560FLR-SFP+|560FLB/i){
		$nicdriver="hp-ixgbe";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /Intel|NC112i|NC112T|NC110T|NC364m|NC360m|NC364T|NC360T/i){
		$nicdriver="hp-e1000e|e1000e";                        
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /366m|366i|361FLB|361i|362i|365T|361T|NC362i|NC365T|366FLR|367i/i){
		$nicdriver="hp-igb";                          
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /560FLB|560SFP+/i){
		$nicdriver="hp-ixgbe";
	}
	elsif ( $nic[$no1] =~ /Brocade/ and $nicv[$no1] =~ /82B|42B|81B|41B/i){
		$nicdriver="bfa";
	}
	elsif ( $nic[$no1] =~ /Brocade/ and $nicv[$no1] =~ /82B|81B|42B|41B|804/i){
		$nicdriver="bfa|HP-FC-Brocade";
	}
	
=cut
	#print " nic is ++ $nicdriver and nicv == $nicv[$no1] \n";
	$dir.="win-12.txt" if ($no1 == 0);
	open (OUT,"<./temp.txt")              || die " Could not open  read file \n";
	#open (IN1,">>./NEW/win-1.txt")    || die " Could not open output1 file \n";
	open (IN12,">>$ofile")  || die " Could not open output2 file \n";
	$ilo="Lights-Out 4" if ($rom =~ /Gen8|G8|Gen9|G9/);
	$ilo="Lights-Out 3" if ($rom =~ /Gen7|G7/);
	$ilo="Lights-Out 2" if ($rom =~ /Gen6|G6/);
	$ilo1="iLO 3/4" if ($rom =~ /Gen8|G8|G9|Gen9/);
	$ilo1="iLO 3" if ($rom =~ /Gen7|G7/);
	$ilo1="iLO 2" if ($rom =~ /Gen6|G6/);	
	$ilo2="Gen[769]" if ($rom =~ /Gen8|G8/);
	$ilo2="Gen[869]" if ($rom =~ /Gen7|G7/);
	$ilo2="Gen[879]" if ($rom =~ /Gen6|G6/);
	$ilo2="Gen[876]" if ($rom =~ /Gen9|G9/);
	 #print " no is -----> $no & $new& no1 is = $no1\n";
		while ($line =<OUT>){
			next if ($line =~ /^ 0/);
			#print " ======>  $line \n";
			$sta=0 if ($line =~ m/\s+/);
			$sta=1 if ($line !~ m/^\s+$/);
			@add=0 if ($sta==0);
			#print IN1 "\n " if ($sta==0);
		    if ($sta == 1){
			
				push(@add,$line);
				#print " add is => @add[4] \n";
				
				
				
				if(defined(@add[4]) and @add[4] =~ m/Software - Network/ and $no <= $hdrsize ){
							foreach (@add){
								next if ($_ =~ /^0/);
								#print " ======> $rom ==> @add[1] === $harddrive \n";
								$spa = @nic[$no1];
						        $spa   =~ s/^\s+|\s+$//g;
								if (@add[1] =~ /$spa/){
								#print " ======> $nicdriver ==> @add[4] \n";
									print IN12 "\n\n" if ($_ =~ /Component Name/);
									print IN12 "$_";
								}
								elsif(@add[1] !~ /Broadcom|Emulex|QLogic|Mellanox|Intel|Brocade/i and $no1 == 0){
									print IN12 "\n\n" if ($_ =~ /Component Name/);
									print IN12 "$_";
								}
							}
						}
				elsif(defined(@add[4]) and @add[4] =~ m/Network|Firmware - Storage Fibre Channel|Driver - Storage Fibre Channel/ ){
					foreach (@add){
						next if ($_ =~ /^0/);
						$n   =~ s/^\s+|\s+$//g;
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " \$spa ******> $spa ** \$nicdriver **> $nicdriver ** \$fc 88> $fc ** \$no $no \$nicsize  = $nicsize\n";
						#print " ======> $nicdriver ==> @add[3] \n";
						if (@add[1] =~ /$spa/ and  @add[1] =~ /$fc1/ and @add[3] =~ /$fc/ and $no <= $nicsize){
							#print " nicd *************> @nic[$no1] and nic version =  $nicdriver\n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
						elsif (@add[1] =~ /$spa/i  and @add[1] =~ /$fc/ and $no <= $nicsize ){ 
							#print " nicd *************> @nic[$no1] and nic version =  $nicdriver\n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
						elsif (@add[1] =~ /$spa/i  and  @add[3] =~ /$fc1/i and $no <= $nicsize and @add[1] !~ /$rcon/i){ 
							#print " nicd *************> @nic[$no1] and nic version =  $nicdriver\n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
						elsif (@add[1] =~ /$spa/i and @add[3] =~ /exe|txt|rpm/ and $no <= $nicsize and @add[1] !~ /$rcon/i){ 
							#print " nicd *************> @nic[$no1] and nic version =  $nicdriver  n01 is = $no1\n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 " 4 $_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Software - Storage Fibre Channel HBA/){
					foreach (@add){
						next if ($_ =~ /^0/);
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[3] =~ /$spa/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/BIOS - System ROM|Firmware - Blade Infrastructure/ and $no1 == 0 ){
				#print " ======> $rom ==> @add[1] \n";
					foreach (@add){
						next if ($_ =~ /^0/);
						@roms=split(/\s+/,$rom);
						$rom2="Gen8|G8" if ($roms[1] =~ /Gen8|G8/);
						$rom2="Gen7|G7" if ($roms[1] =~ /Gen7|G7/);
						$rom2="Gen6|G6" if ($roms[1] =~ /Gen6|G6/);
						$rom2="Gen9|G9" if ($roms[1] =~ /Gen9|G9/);
						#print " ======> $rom ==> @add[1] \n";
						if (@add[1] =~ /$roms[0]/ and @add[1] =~ /$rom2/){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
						if ($roms[0] =~ /BL/i and @add[4] =~ /Firmware - Blade Infrastructure/){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Driver - Storage Controller/ and $no1 == 0 ){
					foreach (@add){
						next if ($_ =~ /^0/);
						#print " ======> $rom ==> @add[1] \n";
						
							if ( @add[1] =~ /$fc/i){
								#print " ======> $rom ==> @add[1] \n";
								print IN12 "\n\n" if ($_ =~ /Component Name/);
								print IN12 "$_";	
							}
							elsif (@add[1] =~ /$controller/i){
								#print " ======> $nicdriver ==> @add[4] \n";
								print IN12 "\n\n" if ($_ =~ /Component Name/);
								print IN12 "$_";
						   }	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Storage Controller/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$controller/){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - SAS Storage Disk|Firmware - SATA Storage Disk/ and $no <= $hdrsize ){
					foreach (@add){
						next if ($_ =~ /^0/);
						#print " ======> $rom ==> @add[1] === $harddrive \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$hdriv[$no1]/){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Lights-Out Management/ and $no1 == 0 ){
					foreach (@add){
						next if ($_ =~ /^0/);
						#print " ======> $rom ==> @add[1] \n";
						if (@add[1] =~ /$ilo/){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Software - System Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						next if (@add[1] =~ /HP ProLiant Agentless Management Service/i and $rom =~ /Gen6|G6|Gen7|G7/i );
						#print " ======> $nicdriver ==> @add[4] \n";
						print IN12 "\n\n" if ($_ =~ /Component Name/);
						print IN12 "$_";
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Power Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						@array = ( $rom =~ m/../g );
						#print " ======> @array[0]  = $nicdriver ==> @add[4] \n";
						
						if ( @add[1] =~ /@array[0]/ | @add[1] !~ /BL|DL/ and @add[1] !~ /$ilo2/i ){
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Driver - System Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						@array = ( $rom =~ m/../g );
						#print " ======> @array[0]  = $nicdriver ==> @add[4] \n";
						
						if ( @add[1] =~ /$ilo1/i and @add[1] !~ /$ilo2/i){
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
						elsif ( @add[1] !~ /ilo/i and @add[1] !~ /$ilo2/i){
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif  (defined(@add[4]) and @add[4] !~ m/Network/ and $no1 == 0){
					#print " ==> network \n";
					foreach (@add){
						#print " ======>  $_ \n";
						next if ($_ =~ /^0/);
						print IN12 "\n\n" if ($_ =~ /Component Name/);
						print IN12 "$_";
					}	
				}
           	}		
		}
	close(OUT);	close(IN1);close(IN12);
	}
#unlink("./temp.txt");
	#print " Out is ===> @add ";
	