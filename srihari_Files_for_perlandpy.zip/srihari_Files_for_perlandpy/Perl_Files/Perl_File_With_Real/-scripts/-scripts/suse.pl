#!\usr\bin\perl

use File::Basename;
$sfile=$ARGV[0];$ofile=$ARGV[1];$ifile=$ARGV[2];#$sername=$ARGV[0];
my($file, $dir, $ext) = fileparse($ofile);
#print "Directory: " . $dir . "\n";print "File:      " . $file . "\n";

@mar=();$a1=0;$a2=0;$flag3=0;

open (IN,"$sfile")          || die " Could not open a file \n";
open (SUSE,">./temp.txt")   || die " Could not open output file \n"; 
open (INPUT,"<$ifile")      || die " Could not open input file \n";
 # perl suse.pl ./temp/contents.html  ./temp/suse.txt  ./input.txt  

	while ( $in = <INPUT> ){
        #print " $in \n";
        push(@input,$in) if ( $in !~ /#|^\s/ );
    }  
    $ver1  = $input[1]; $kern  = $input[2];	$osbit = $input[3]; $proce = $input[4];
	$nicdri= $input[5]; $nicver= $input[6]; $rom   = $input[7]; $controller = $input[8];
	$harddrive = $input[9];$nicspeed=$input[11];
	
	@nic=split(/,/,$nicdri);@nicv=split(/,/,$nicver);@hdriv=split(/,/,$harddrive);
	$nicsize=scalar(@nic);$hdrsize=scalar(@hdriv);
	print " \n sizes are  => $nicsize == $hdriv\n nic ver => @nicv \n";
		
	$ver1   =~ s/^\s+|\s+$//g;$kern  =~ s/^\s+|\s+$//g;	$osbit  =~ s/^\s+|\s+$//g;$proce =~ s/^\s+|\s+$//g;
	$nicdri =~ s/^\s+|\s+$//g;$nicver=~ s/^\s+|\s+$//g; $rom    =~ s/^\s+|\s+$//g;$controller =~ s/^\s+|\s+$//g;
	$harddrive =~ s/^\s+|\s+$//g;$nicspeed =~ s/^\s+|\s+$//g;
	$osver="6" if ($ver1 =~ /5/); $osver="5" if ($ver1 =~ /6/);$osver="5|6" if ($ver1 =~ /7/);
	$osver1="7" if ($ver1 =~ /5/);$osver1="7" if ($ver1 =~ /6/);
	@osv=split(//,$ver1); $ov=$osv[0];
	$ov="[56]";
	$osver=6 if ($ver1 =~ /5/);$osver=5 if ($ver1 =~ /6/);
	@osv=split(//,$ver1); $ov=$osv[0];
	
	print " ===> os version is = $osver = $osv[0] ==ov is  $ov\n";
	if ( $osbit == 32 ){
		$redhat="SUSE LINUX Enterprise Server|SUSE"; #=~
	    $bit="AMD64|EM64T|x86_64|64-bit|Red Hat|rhel|.txt|x64|rpm.sig";#!~
		$bit1="sles|scexe|rpm";						  #=~	
		$bit2="<|>|rhel|README";                      # !=
	}	
	elsif ( $osbit == 64 ){
	    $redhat="SUSE LINUX Enterprise Server|SUSE"; #=~
		$bit="i686|Red Hat|i586|rhel|x86wewqw\b|i386|inux x86\b|.txt|rpm.sig";  #!~
		$bit1="sles|scexe|rpm";                     #=~ 
		$bit2="<|>|rhel|README";                    # !=
	}	
      	
	  $siz=length($ver1);
	  print "===>+  siz is $siz\n +++ $ver1|scexe\n";
	  print " inputs are ====>  @input\n";
    while ($line = <IN>){
        $status=0 if ($line =~ /<tr>/);
	    @add=()   if ($status == 0);
		
		
                if ($status == 1){
                     #print " lines 1111 ==>  $status \n";
                                $sp=$line; 
        @sp=split(/<|>/,$sp);
        push(@add,"Version                : ".@sp[2]) if (@sp[2] =~ /\d+/);
                    
        if ( $line =~ /<p>/ ){
			@a=split(/<P>|<br\/>|<p>/,$line); 
                                                
			foreach $b(@a) {
                 #print " ** lines ==> R2 @add[0]  \n" if ( @add[0] =~ /HP H2xx SAS\/SATA Host Bus Adapter Driver for SUSE LINUX Enterpri/);                               
				next if ( $b =~ /<\/p><\/td>/ );
				#print "********** R is => $b\n"  if (@add[0] =~ /HP Broadcom 1\/10 GbE Multifunction Drivers for SUSE Linux Enterprise Server 11 x86_64/i);
				undef(@add[2]);
				@add[2]="Deploying component R1 : $b"  if ( $b !~ /<|>|README/ and $b =~ /$ver1/ and $b =~ /$kern/ and $b !~ /$bit/ );
				@add[2]="Deploying component R2 : $b"  if ( $b !~ m/$bit/ and $b !~ m/sp1|sp2|sp3|sp0/ and $b !~ /xen|PAE/i and $b !~ /<|>|README/);
				@add[2]="Deploying component R3 : $b"  if (  $b =~ m/$ver1/i and $b !~ /<|>|README/);
				#print " input ver1 is ==> ++  ::  $add[2]\n";
				$siz=scalar(@add);
				@add[3]=$head1 if (defined @add[2] );
                   #print "####@@@@@@@@@@@@@@@@@ lines ==> R1 @add[2] \n" if (@add[0] =~ /HP Broadcom 1\/10 GbE Multifunction Drivers for SUSE Linux Enterprise Server 11 x86_64/i);             
				foreach (@add){
					#print " input ver1 is ==> $ver1 and @add[2] \n";
					#print "  lines ==> R2 $_  \n" if ( $_ =~ /si-mpt2sas-kmp-xen-15.10.02.00-6.sles11sp3/i);				
					if ( defined @add[2] and $b =~ /$ver1/  and $b =~ /$kern/ and $b !~ /$bit/  ){
					#print " * lines ==> R2 $_  \n" if ( $_ =~ /si-mpt2sas-kmp-xen-15.10.02.00-6.sles11sp3/);
						print SUSE "$_ \n";
					}
					elsif ( defined @add[2] and $b !~ m/$bit/ and $b !~ m/sp1|sp2|sp3|sp0/ and $b !~ /xen|PAE/i and $b !~ /<|>|README/){  
					#print " ** lines ==> R2 $_  \n" if ( $_ =~ /si-mpt2sas-kmp-xen-15.10.02.00-6.sles11sp3/);
						print SUSE "$_ \n";
					}
					elsif ( defined @add[2] and $b =~ m/$ver1/i and $b !~ /xen|PAE/i and $b !~ /<|>|README/){
					#print " *** lines ==> R2 $_  \n" if ( $_ =~ /si-mpt2sas-kmp-xen-15.10.02.00-6.sles11sp3/);
						print SUSE "$_ \n";
					}	
				}
			}
        }                     
	}
	
                
                elsif ( $status == 3 ) {
                    $sp=$line; 
					@sp=split(/<|>/,$sp);
                    push(@add,"Version                : ".@sp[2]) if (@sp[2] =~ /\d+|[HPDB]/); 
                  
                    if ( $line =~ /<p>/ ){
                                
                        @a=split(/<P>|<br\/>|<p>/,$line);
                                                
						foreach $b(@a){
                                                
						next if ( $b =~ /<\/p><\/td>/ );
						@add[2]="Deploying component L1 : $b"  if ( $b !~ /<|>|README/ and $b !~ /$bit2/ and $b =~ /$bit1/ and $b =~ /$ver1|scexe/i and $b =~ /$kern|scexe/ and $b !~ /$bit/);
						@add[2]="Deploying component L2 : $b"  if ( $b !~ m/$bit/ and $b !~ m/sp1|sp2|sp3|sp0/ and $b !~ /<|>|README/ and $b !~ /xen|PAE/i );
						@add[2]="Deploying component L22 : $b"  if ( $b !~ m/$bit/ and $b =~ m/$ver1/ and $b !~ /<|>|README/ and $b !~ /xen|PAE/i );
						@add[2]="Deploying component L3 : $b"  if ( $b !~ m/$bit/  and $b !~ /<|>|README/ and @add[0] =~ /AMD64\/EM64T/ and $b =~ /$ver1/ and $b !~ /xen|PAE/i);
						@add[2]="Deploying component L4 : $b"  if ( $b !~ m/$bit/  and $b !~ /<|>|README/ and @add[0] =~ /AMD64\/EM64T/ and $b !~ m/sp1|sp2|sp3|sp0/);
						@add[3]=$head1 if (defined @add[2] );
                           print "####@@@@@@@@@@@@@@@@@ lines ==> R1 @add[3] \n" if (@add[0] =~ /Online Firmware Upgrade Utility \(Linux x86_64\) for HP InfiniBand/i);
						foreach (@add){
												   # print " version $ver1 \n";
									if (defined @add[2] and $b =~ /$ver1|scexe/ and $b =~ /$kern|scexe/ and $b !~ /$bit/){
										print SUSE "$_ \n"
									}
									elsif (defined @add[2] and $b !~ m/$bit/ and $b !~ m/sp1|sp2|sp3|sp0/i){
										print SUSE "$_ \n";
									}
									elsif (defined @add[2] and $b !~ m/$bit/ and $b =~ m/$ver1/ and $b !~ /xen|PAE/i){
										print SUSE "$_ \n";
									}
									elsif (defined @add[2] and $b !~ m/$bit/ and @add[0] =~ /AMD64\/EM64T/ and $b =~ /$ver1/ and $b !~ /xen|PAE/i){
										print SUSE "$_ \n";
									}
									elsif (defined @add[2] and $b !~ m/$bit/ and @add[0] =~ /AMD64\/EM64T/ and $b !~ m/sp1|sp2|sp3|sp0/){
										print SUSE "$_ \n";
									}
									
						} 
					  }
                    }  
                }              

	
	
		
	if ( $line =~ m/b\// ){
		@head=split(/<|>/,$line);
		$head1="Sub                    : @head[6]";
	}
	#print " ===> proce $proce\n";
	if (  $line =~ m/$redhat/ and $line =~ m/$proce/i  and $line !~ m/$bit/ ){
	   # print " lines ==> R1 $line \n";
	    $sp=$line; 
        @sp1=split(/<|>/,$sp); 	  
	    $status=1;
	    push(@add,"\n\nComponent Name  R      : ".@sp1[2]);
		#print " input 0 is ==> $bit \n @add \n";
	}
	elsif (  $line =~ m/$redhat/ and $line !~ m/AMDSS3|IntelSS/  and $line !~ m/$bit/ and $osbit =~ /32/ ){
	    print " @@@@@@@@@@lines ==> R2 $line \n" if ( $line =~ /HP Broadcom Linux iSCSI Offload IO Daemon for SUSE Linux Enterprise Server 11 SP3 x86_64/);
	    $sp=$line; 
        @sp1=split(/<|>/,$sp); 	  
	    $status=1;
	    push(@add,"\n\nComponent Name  R2     : ".@sp1[2]);
		#print " input 0 is ==> $bit \n @add \n";
	}
	elsif (  $line =~ m/$redhat/ and $line !~ m/AMD|Intel/  and $line !~ m/$bit/ and $line !~ m/x86\)/  and $osbit == 64 ){
	   print " @@@@@@@@@@lines ==> R2 $line \n" if ( $line =~ /HP Broadcom 1\/10 GbE Multifunction Drivers for SUSE Linux Enterprise Server 11 x86_64/);
	    $sp=$line; 
        @sp1=split(/<|>/,$sp); 	  
	    $status=1;
	    push(@add,"\n\nComponent Name  R3    : ".@sp1[2]);
		#print " input 0 is ==> $bit \n @add \n";
	}
	elsif ( $line !~ m/$bit/  and $line =~ m/AMD64\/EM64T/ and $line =~ m/$redhat/ and $line !~ m/\(x86\)/ and $line !~ m/Linux x86\b/  and $osbit == 64 ){
	    #print " lines ==> R4# $line \n" if (  $line =~ /HP Mellanox EN Driver for InfiniBand adapters \(SUSE LINUX Enterprise Server 11 SP3 AMD64\/EM64T/i);
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\n Component Name R4      : ".@sp[2]);
	}
	elsif (  $line =~ m/Linux/ and $line =~ m/$proce/ and $line !~ m/$bit/ and $line !~ /x86\b/ and $osbit =~ /64/ ){
	    #print " lines ==> L1 $line \n" if ( $line =~ /HP Lights-Out Online Configuration Utility for Linux/);
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name L1      : ".@sp[2]);
	} 
	elsif (  $line =~ m/Linux/ and $line =~ m/$proce/ and $line !~ m/$bit/ and $line !~ /x64\b/i and $osbit =~ /32/ ){
	    #print " lines ==> L1 $line \n" if ( $line =~ /HP Lights-Out Online Configuration Utility for Linux/);
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name L11      : ".@sp[2]);
	}
	elsif ( $line !~ m/$bit/  and $line !~ m/AMD64|Intel/ and $line =~ m/Linux/i and $osbit =~ /32/  ){
	    print " lines ==> L2 $line \n" if ( $line =~ /HP Mellanox Online Firmware Upgrade Utility for Linux i386/);
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name L2      : ".@sp[2]);
	} 
	elsif ( $line !~ m/$bit/  and $line !~ m/AMD32|Intel/ and $line =~ m/Linux/ and $line !~ m/ x86 |\(x86\)|Linux x86\b/  and $osbit == 64 ){
	    #print " lines ==========> L3 $line \n" if ($line =~ /Insight Diagnostics Online Edition for Linu/i);
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\nComponent Name L33      : ".@sp[2]);
	} 
	elsif ( $line !~ m/$bit/  and $line =~ m/AMD64\/EM64T/ and $line =~ m/Linux/i and $line !~ m/\(x86\)/ and $line !~ m/Linux x86\b/  and $osbit == 64 ){
	   # print " lines ==> L4 $line \n";
	   print " lines ==> R444 $line \n" if ( $line =~ /AMD64\/EM64T/i);
	    $sp=$line; 
        @sp=split(/<|>/,$sp); 
	    $status=3;
	    push(@add,"\n\n Component Name L4     : ".@sp[2]);
	}
 }	
 close(SUSE); close(IN);close(INPUT);
 $rhel={"lsi-mpt2"=>[H222,H221,H220,H220i,H210i],"cciss-kmp"=>[P812,P800,P712m,P711m,P700m,P600,P411,P410,P410i,P400,P400i,P212,E200,E200i,E500],
"hpsa-kmp"=>[P840,P830,P830i,P822,P731m,P721m,P441,P440ar,P440,P431,P430,P421,P420,P420i,P244br,P230i,P222,P220i,H241,H240,H240ar,H244br],
"hpvsa-kmp"=>[B320i,B120i],};   
 %rh=%$rhel;
foreach ( keys(%rh)){
 #print " \n keys are   => $_   \n";
 @a=@{$rhel->{"$_"}};undef(@g);
 @g = grep(/$controller\b/i,@a);
 $fc=$_ if @g;
 #print "&&&&&&&&&&&&&&& values are => FC is -> $fc \n";

 }
 
  print " values are =>   FC is###################### -> $fc \n";
 $no=0;
@loop= @nicv  if ($nicsize >= $hdrsize);
@loop= @hdriv if ($nicsize <= $hdrsize);
#print " size is = $nicsize : size1 is = $hdrsize : loop is = @loop \n";
foreach $new(@loop){
     $no++;$no1 = $no;
	 $no1 =$no - 1;
	#print " no is -----> $no & $new& no1 is = $no1\n";
## NIC card filtering	
$nic[$no1] =~ s/^\s+|\s+$//g; $nicv[$no1] =~ s/^\s+|\s+$//g;
%hash=('Netxtreme2'=>'Broadcom','HP-CNA-FC-Emulex-Enablement-Kit'=>'Emulex','hp-nx_nic'=>'Qlogic','mellanox-mlnx'=>'Mellanox','hp-e1000'=>'Intel','bfa'=>'Brocade');  	

undef $fc1;
if ( $nic[$no1] =~ /Broadcom/i){
	print "Broadcome \n";
	$nich={"cnu"=>['533FLR-T','534FLB','534FLR-SFP','534m,630FLB','630m','CN1100R'],"netxtreme2"=>['NC382i','NC382m','NC382T','NC532i','NC532m','530FLB','530FLR-SFP','530m','530SFP+'],
	"tg3"=>['330i','332T','331FLR','331T','331i',NC107i,NC105i,NC325m,NC326m,NC324i,NC325i,NC326i,NC150T,NC320,NC1020,NC67,NC77,NC320m,'331i-SPI','332i'],
	"iscsiuio"=>[NC382i,NC382m,NC382T,NC532i,NC532m,'534FLB','534FLR-SFP','534m','630FLB','630m'],"tg3sd"=>['330i','331FLR','331i','331i-SPI','331T','332i','332T'],};
} 
elsif( $nic[$no1] =~ /Emulex/i){ 
	print "Emulex \n";
	$nich={"be2iscsi"=>['554FLB','554M','554FLR-SFP+','CN1100E','CN1000E','553m','553i','551m','551i'],"lpfc|HP-CNA-FC-Emulex-Enablement"=>['FC2243','FC2242','FC2143','FC2142','SN1000E','82E','81E','CN1000E','CN1100E','552m','NC553m','NC553i','NC552m','NC552SFP','NC551m','NC551i','NC550SFP','554m','554FLR-SFP','NC550m','LPe1205','LPe1105','SN1100E','556FLR-SFP','650FLB','650m','CN1200E'],
	"be2net"=>['552M','554FLB','554M','554FLR-SFP+','CN1000E','CN1100E','552SFP','550SFP','553m','553i','552m','551m','551i','550m','554FLR-SFP','556FLR-SFP','650FLB','650m','CN1200E','NC550SFP','NC550m','NC551m','NC551i','NC552m','NC552SFP','NC553i','NC553m','552m'],
	"HP Firmware Flash for Emulex Converged Network Adapters"=>['CN1000E','CN1100E','552M','NC553m','NC553i','NC552m','NC552SFP','NC551m','NC551i','NC550SFP','54M','554FLR-SFP+','554FLB','NC550m','CN1200E','650FLB','650M','556FLR-SFP+'],
	"HP Firmware Flash for Emulex Fibre Channel Host Bus Adapters"=>['FC2243','FC2242SR','FC2143','FC2142SR','SN1000E','SN1000E','82E','81E','LPe1205A','LPe1205','LPe1105','SN1100E','SN1100E','LPe1605'],};
} 
elsif( $nic[$no1] =~ /QLogic/i){
	print "QLogic \n";
	$nich={"hp-nx_nic"=>['375i','375T','522SFP','524SFP','510F','510C','512m','522m'],"hp-qla4xxx"=>['CN1000Q'],"nx-nic"=>['NC522SFP','NC552m','NC375i','NC375T'],
	"qla2xxx|HP-CNA-FC-hpqlgc"=>['QMH2672','QMH2572','FC1243','FC1143','FC1242','FC1142','SN1000Q','82Q','81Q','CN1000Q','526m','526FLR-SFP','526FLB','QMH2562','QMH2462'],
	"qla4xxx"=>['526FLR-SFP','CN1000Q'],"hp-qlcnic"=>['CN1000Q','523SFP'],"HP QLogic P3 Online Firmware Upgrade Utility|HP QLogic P2/P3 Online Firmware Upgrade Utility"=>['522SFP','375i','375T'],"HP QLogic P3P Online Firmware Upgrade Utility"=>['CN1000Q','523SFPSFP'],
	"HP Firmware Flash for QLogic Fibre Channel Host Bus Adapters"=>['FC1143 4Gb','FC1243','FC1142SR','FC1242SR','81Q','82Q','QMH2562','QMH2462','QMH2572','SN1000Q','QMH2672'],};
}
elsif( $nic[$no1] =~ /Mellanox/i){ 
	print "Mellanox \n";
	$nich={"mellanox-mlnx|mlnx"=>['Nc542m','NC543i','544i','10GbE Dual Port Mezzanine'],};
}
elsif( $nic[$no1] =~ /Intel/i){ 
	print "Intel \n";
	$nich={"hp-e1000"=>['NC340T','NC310F'],"ocsbbd"=>['361i','361FLB','361T','363i','364i','366FLR','366i','366m','367i','560FLB','P560FLR-SFP+','560m','560SFP+','561FLR-T','561T','562i'],
	"hp-ixgbevf"=>['560FLB','560FLR-SFP','560m','560SFP+','561FLR-T','561T','562i'],"ixgbe"=>['562i','561T','561FLR-T','560SFP+','P560FLR-SFP+','560FLB'],"hp-e1000e|e1000e"=>['Intel','NC112i','NC112T','NC110T','NC364m','NC360m','NC364T','NC360T'],
	"hp-igb"=>['366m','366i','361FLB','361i','362i','365T','361T','NC362i','NC365T','366FLR','367i'],"hp-ixgbe"=>['560FLB','560SFP+'] };
}
elsif( $nic[$no1] =~ /Brocade/){
	print "Brocade \n";
	$nich={"bfa"=>['82B','42B','81B','41B'],"bfa|HP-FC-Brocade"=>['82B','81B','42B','41B','804'],"HP Firmware Flash for Brocade Fibre Channel Host Bus Adapters"=>['41B','42B','81B','82B','Brocade 804']};
}

 %rh=%$nich;
 foreach ( keys(%rh)){
# print " \n keys are   => $_   \n";
 @a=@{$nich->{"$_"}};undef(@g);
@g = grep(/\*|\b$nicv[$no1]\b/i,@a);
 $fc1.="\|$_" if @g;
 #my @foo = split (//,$fc1);$f=shift @foo;$fc1 = join '', @foo;
 #print " values are => FC1 is -> $fc1 \n";

 }

$fc1=reverse($fc1);chop($fc1);$fc1=reverse($fc1);
print " Nic card mapping values are   => $nic[$no1] -> $nicv[$no1]   FC1 is -> $fc1 \n";


$nic[$no1] =~ s/^\s+|\s+$//g; $nicv[$no1] =~ s/^\s+|\s+$//g;
  ###### Mapping NIC cards for firmware network 
undef $fnet1;
 if ( $nic[$no1] =~ /QLogic/i){
	print " F W => QLogic \n";
	$fnet={"HP Firmware Flash for QLogic Fibre Channel Host Bus Adapters"=>['FC1143 4Gb','FC1243','FC1142SR','FC1242SR','81Q','82Q','QMH2562','QMH2462','QMH2572','SN1000Q','QMH2672']};
} 
elsif( $nic[$no1] =~ /Emulex/){ 
	print " F W => Emulex \n";
	$fnet={"HP Firmware Flash for Emulex Fibre Channel Host Bus Adapters"=>['FC2243','FC2242SR','FC2143','FC2142SR','SN1000E','SN1000E','82E','81E','LPe1205A','LPe1205','LPe1105','SN1100E','SN1100E','LPe1605']};
} 
elsif( $nic[$no1] =~ /Brocade/){ 
	print " F W => Brocade \n";
	$fnet={"HP Firmware Flash for Brocade Fibre Channel Host Bus Adapters"=>['41B','42B','81B','82B','Brocade 804']};
} 

 %rh1=%$fnet;
 foreach ( keys(%rh1)){
# print " \n keys are   => $_   \n";
 @a=@{$fnet->{"$_"}};undef(@g);
@g = grep(/\*|\b$nicv[$no1]\b/i,@a);
 $fnet1.="\|$_" if @g;
 #my @foo = split (//,$fc1);$f=shift @foo;$fc1 = join '', @foo;
 #print " values are => FC1 is -> $fc1 \n";

 }
$fnet1=reverse($fnet1);chop($fnet1);$fnet1=reverse($fnet1);
print " Firmware network 2222   =>    Fnet1 is -> $fnet1 \n";


=head
    if ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /NC370|NC371|NC373|NC374|NC380|NC382|NC382i|NC382m|NC382T|NC532i|530FLB|530FLR-SFP|530m|530SFP+]/i){
		$nicdriver="Netxtreme2";
	}
	elsif ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /530SFP+|530FLR-SFP+|530FLB|530M/i){
		$nicdriver="bnx2x";
	}
	elsif ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /533FLR-T|534FLB|534FLR-SFP|534m|630FLB|630m|CN1100R/i){
		$nicdriver="cnu";
	}
	elsif ( $nic[$no1] =~ /Broadcom/ and $nicv[$no1] =~ /330i|332T|331FLR|331T|331i|NC107i|NC105i|NC325m|NC326m|NC324i|NC325i|NC326i|NC150T|NC320|NC1020|NC67|NC77|NC320m|331i-SPI|332i/i){
		$nicdriver="tg3";                              
	}
	elsif ( $nic[$no1] =~ /Emulex/ and $nicv[$no1] =~ /554FLB|554M|554FLR-SFP+|CN1100E|CN1000E|553m|553i|551m|551i/i){
		$nicdriver="be2iscsi";
	}
	elsif ( $nic[$no1] =~ /Emulex/ and $nicv[$no1] =~ /FC2243|FC2242|FC2143|FC2142|SN1000E|82E|81E|CN1000E|CN1100E|552m|NC553m|NC553i|NC552m|NC552SFP|NC551m|NC551i|NC550SFP|554m|554FLR-SFP|NC550m|LPe1205|LPe1105|SN1100E|556FLR-SFP|650FLB|650m|CN1200E/i){
		$nicdriver="lpfc|HP-CNA-FC-Emulex-Enablement";
	}
	elsif ( $nic[$no1] =~ /Emulex/ and $nicv[$no1] =~ /552M|554FLB|554M|554FLR-SFP+|CN1000E|CN1100E|552SFP|550SFP|553m|553i|552m|551m|551i|550m|554FLR-SFP|556FLR-SFP|650FLB|650m|CN1200E|NC550SFP|NC550m|NC551m|NC551i|NC552m|NC552SFP|NC553i|NC553m|552m/i){
		$nicdriver="be2net";                                                                                        
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /375i|375T|522SFP|524SFP|510F|510C|512m|522m/i){
		$nicdriver="hp-nx_nic";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /CN1000Q/i){
		$nicdriver="hp-qla4xxx";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /NC522SFP|NC552m|NC375i|NC375T/i){
		$nicdriver="nx-nic";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /QMH2672|QMH2572|FC1243|FC1143|FC1242|FC1142|SN1000Q|82Q|81Q|CN1000Q|526m|526FLR-SFP|526FLB|QMH2562|QMH2462/i){
		$nicdriver="qla2xxx|HP-CNA-FC-hpqlgc";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /526FLR-SFP|CN1000Q/i){
		$nicdriver="qla4xxx";
	}
	elsif ( $nic[$no1] =~ /QLogic/ and $nicv[$no1] =~ /CN1000Q|523SFP/i){
		$nicdriver="hp-qlcnic";
	}
	elsif ( $nic[$no1] =~ /Mellanox/ and $nicv[$no1] =~ /Nc542m|NC543i|10GbE Dual Port Mezzanine/i){
		$nicdriver="mellanox-mlnx|mlnx";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /NC340T|NC310F/i){
		$nicdriver="hp-e1000";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /361i|361FLB|361T|363i|364i|366FLR|366i|366m|367i|560FLB|P560FLR-SFP+|560m|560SFP+|561FLR-T|561T|562i/i){
		$nicdriver="ocsbbd";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /560FLB|560FLR-SFP|560m|560SFP+|561FLR-T|561T|562i/i){
		$nicdriver="hp-ixgbef";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /562i|561T|561FLR-T|560SFP+|P560FLR-SFP+|560FLB/i){
		$nicdriver="hp-ixgbe";
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /Intel|NC112i|NC112T|NC110T|NC364m|NC360m|NC364T|NC360T/i){
		$nicdriver="hp-e1000e|e1000e";                        
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /366m|366i|361FLB|361i|362i|365T|361T|NC362i|NC365T|366FLR|367i/i){
		$nicdriver="hp-igb";                          
	}
	elsif ( $nic[$no1] =~ /Intel/ and $nicv[$no1] =~ /560FLB|560SFP+/i){
		$nicdriver="hp-ixgbe";
	}
	elsif ( $nic[$no1] =~ /Brocade/ and $nicv[$no1] =~ /82B|42B|81B|41B/i){
		$nicdriver="bfa";
	}
	elsif ( $nic[$no1] =~ /Brocade/ and $nicv[$no1] =~ /82B|81B|42B|41B|804/i){
		$nicdriver="bfa|HP-FC-Brocade";
	}
	
=cut
	$dir.="suse-12.txt" if ($no1 == 0);
	open (OUT,"<./temp.txt")      || die " Could not open data file \n";
	#open (IN1,">>./temp/suse-1.txt")    || die " Could not open reinsert file \n";
	open (IN12,">>$ofile")  || die " Could not open output file \n";
	$ilo="Lights-Out 4" if ($rom =~ /Gen8|G8|Gen9|G9/);
	$ilo="Lights-Out 3" if ($rom =~ /Gen7|G7/);
	$ilo="Lights-Out 2" if ($rom =~ /Gen6|G6/);
	$ilo1="iLO 3/4" if ($rom =~ /Gen8|G8|G9|Gen9/);
	$ilo1="iLO 3" if ($rom =~ /Gen7|G7/);
	$ilo1="iLO 2" if ($rom =~ /Gen6|G6/);	
	$ilo2="Gen[769]" if ($rom =~ /Gen8|G8/);
	$ilo2="Gen[869]" if ($rom =~ /Gen7|G7/);
	$ilo2="Gen[879]" if ($rom =~ /Gen6|G6/);
	$ilo2="Gen[876]" if ($rom =~ /Gen9|G9/);
	  #print " ________ ILO = $ilo  ILO1 = $ilo1 ILO2 = $ilo2 \n";
	 #print " no is -----> $no &  no1 is = $no1\n";
		while ($line =<OUT>){
			next if ($line =~ /^ 0/);
			#print " ======>  $line \n";
			$sta=0 if ($line =~ m/\s+/);
			$sta=1 if ($line !~ m/^\s+$/);
			@add=0 if ($sta==0);
			#print IN1 "\n " if ($sta==0);
		    if ($sta == 1){
			
				push(@add,$line);
				#print " add is => @add[3] \n";
				if(defined(@add[4]) and @add[4] =~ m/Software - Network/i ){
					foreach (@add){
						next if ($_ =~ /^0/);
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " @@@@@@@@@@@@@@@@@@@======> $rom ==> $spa \n";
						if (@add[1] =~ /$spa/i  and @add[3] =~ /$fc1/i){
							#print " @@@@@@@@@@@@@@@@======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
						elsif(@add[1] !~ /Broadcom|Emulex|QLogic|Mellanox|Intel|Brocade/i and $no1 == 0){
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Driver - Network/i){
					foreach (@add){
						next if ($_ =~ /^0/);
						$n   =~ s/^\s+|\s+$//g;
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$spa/i and  @add[3] =~ /$fc1/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Network/i){
					foreach (@add){
						next if ($_ =~ /^0/);
						$n   =~ s/^\s+|\s+$//g;
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /Qlogic/i and $spa =~ /Qlogic/i){
							print IN12 "\n\n" if ($_ =~ /Component Name/ and @add[1] =~ /$fc1/i);
							print IN12 " RRR $_"   if (@add[1] =~ /$fc1/i);
						}
						elsif (@add[1] =~ /$spa/i ){
							#print " ======> $nicdriver ==> @add[1] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
						elsif (@add[1] =~ /$nicv[$no1]/i ){
								#print " ======> $nicdriver ==> @add[4] \n";
								print IN12 "\n\n" if ($_ =~ /Component Name/);
								print IN12 "$_";
						}		
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Network|Driver - Storage Fibre Channel/ ){
					foreach (@add){
						next if ($_ =~ /^0/);
						$n   =~ s/^\s+|\s+$//g;
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ======> $nicdriver ==> fc is = $fc \n";
						if (@add[1] =~ /$spa/ |  @add[3] =~ /$fc1/  and $no <= $nicsize ){
							#print " line123 *************> @nic[$no1] and  \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "ss1$_";
						}
						elsif (@add[1] =~ /$spa/i  and @add[3] =~ /$fc/ and $no <= $nicsize ){ 
							#print " line123 *************> @nic[ and  @nicdriver[$no1]\n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "ss2$_";
						}
						elsif (@add[1] =~ /$spa/i  and  @add[3] =~ /$fc1/i and $no <= $nicsize and @add[3] !~ /lsi-mpt2|cciss-kmp|hpsa-kmp|hpvsa-kmp/){ 
							#print " line123 *************> @nic[ and  @nicdriver[$no1]\n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "ss3 $_";
						}
						elsif (@add[1] =~ /$spa/i and @add[3] =~ /scexe|txt|rpm/ and $no <= $nicsize and @add[3] !~ /lsi-mpt2|cciss-kmp|hpsa-kmp|hpvsa-kmp/){ 
							#print " line123 *************> @add[3]\n" if (@add[1] =~ /$spa/i);
							#print IN12 "\n\n" if ($_ =~ /Component Name/);
							#print IN12 "ss4 $_";
						}
					}
				}
					elsif(defined(@add[4]) and @add[4] =~ m/Software - Storage Fibre Channel HBA/){
					foreach (@add){
						next if ($_ =~ /^0/);
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /Qlogic/i and $spa =~ /Qlogic/i ){
							print IN12 "\n\n" if ($_ =~ /Component Name/ and @add[1] =~ /Qlogic/i and $no1 == 0);
							print IN12 "RRR$_"   if (@add[1] =~ /Qlogic/i and $no1 == 0);
						}
						elsif (@add[3] =~ /$spa/i){
							#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Storage Fibre Channel/){
					foreach (@add){
						next if ($_ =~ /^0/);
						$spa = @nic[$no1];
						$spa   =~ s/^\s+|\s+$//g;
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$fnet1/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/BIOS - System ROM/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						@roms=split(/\s+/,$rom);
						$rom2="Gen8|G8" if ($roms[1] =~ /Gen8|G8/);
						$rom2="Gen7|G7" if ($roms[1] =~ /Gen7|G7/);
						$rom2="Gen6|G6" if ($roms[1] =~ /Gen6|G6/);
						$rom2="Gen9|G9" if ($roms[1] =~ /Gen9|G9/);
						#print " ####################======> $rom ==> @add[1] \n";
						if (@add[1] =~ /$roms[0]/i and @add[1] =~ /$rom2/){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
											
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Blade Infrastructure/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						@roms=split(/\s+/,$rom);
						$rom2="Gen8|G8" if ($roms[1] =~ /Gen8|G8/);
						$rom2="Gen7|G7" if ($roms[1] =~ /Gen7|G7/);
						$rom2="Gen6|G6" if ($roms[1] =~ /Gen6|G6/);
						$rom2="Gen9|G9" if ($roms[1] =~ /Gen9|G9/);$rom5=64 if ($osbit =~ /64/); $rom5 ='BL' if ($osbit =~ /32/);
						#print "###################==> $rom5 \n";
						if ($roms[0] =~ /BL/i and @add[1] =~ /$rom5/i){
							#print " @@@@@@@@@@@@@@@======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Driver - Storage Controller/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						
						if ( @add[3] =~ /$fc/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";	
						}
						elsif ( @add[1] =~ /$controller/i){
							#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Storage Controller/ and $no1 == 0 and @add[1] =~ /$controller/i and $osbit == 64){
					
					foreach (@add){
						next if ($_ =~ /^0/);
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$controller/i){
							$mar[$a1][$a2]="$_";#print " ******************** ==> $mar[$a1][$a2]\n";
							#print IN12 "\n\n" if ($_ =~ /Component Name/);
							#print IN12 "#########$_";
							$a2++;
						}	
					}
					$a1++;
					foreach $item1 (@mar){
						@marr=();
						foreach $item2 (@{$item1}){
							$flag3=1 if ($item2 =~ /x64/i);
							push(@marr,$item2) if ($flag3 == 1);
							#print "___________________$flag3 \n";  
						}
						if ( $osbit =~ /64/i ){
							foreach $new1(@marr){
								print IN12 "\n\n" if ($new1 =~ /Component Name/);
								print IN12 "#########$new1";
								#print "---------- @marr\n";
							}
						}
					}
					#print "  ++++++++++ $_ \n";
					if ($flag3 == 0 ){
						 #print " $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n";
						 #print IN12 "\n\n" if ($_ =~ /Component Name/);
						 #print IN12 "###-----####$_";
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Storage Controller/ and $no1 == 0 and $osbit == 32){
					foreach (@add){
						next if ($_ =~ /^0/);
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;
						if (@add[1] =~ /$controller/i){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - SAS Storage Disk|Firmware - SATA Storage Disk/ and $no <= $hdrsize){
					foreach (@add){
						next if ($_ =~ /^0/);
						#print " ======> $hdriv[$no1] ==$nicdriver ==> @add[4] ==$hdriv[$no1] \n";
						$hdriv[$no1]=~ s/^\s+|\s+$//g;$hd=64 if ($osbit =~ /64/i);$hd=$hdriv[$no1] if ($osbit =~ /32/i);
						if (@add[1] =~ /$hdriv[$no1]/ and @add[1] =~ /$hd/i){
							#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Lights-Out Management/ and $no1 == 0 ){
					foreach (@add){
						next if ($_ =~ /^0/);
						
						if (@add[1] =~ /$ilo/){
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Software - System Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						next if (@add[1] =~ /HP ProLiant Agentless Management Service/i and $rom =~ /Gen6|G6|Gen7|G7/i );
						#print " ======> $nicdriver ==> @add[4] \n";
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Firmware - Power Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						next if (@add[1] =~ /DL580 Gen8/i and $rom !~ /DL580 Gen8/i);
						@array = ( $rom =~ m/../g );
						#print " ======> @array[0]  = $nicdriver ==> @add[4] \n";
						
						if ( @add[1] =~ /@array[0]/ | @add[1] !~ /BL|DL|ML/ and @add[1] !~ /$ilo2/i){
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif(defined(@add[4]) and @add[4] =~ m/Driver - System Management/ and $no1 == 0){
					foreach (@add){
						next if ($_ =~ /^0/);
						@array = ( $rom =~ m/../g );
						#print " ======> @array[0]  = $nicdriver ==> @add[4] \n";
						
						if ( @add[1] =~ /$ilo1/i and @add[1] !~ /$ilo2/i){
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}
						if ( @add[1] !~ /ilo/i and @add[1] !~ /$ilo2/i){
							print IN12 "\n\n" if ($_ =~ /Component Name/);
							print IN12 "$_";
						}	
					}
				}
				elsif (defined(@add[4]) and @add[4] !~ m/Network/i and $no1 == 0 and @add[4] !~ m/Firmware - Storage Controller|Firmware - Network/i){
					#print " ==> network \n";
					foreach (@add){
						#print " ======>  $_ \n";
						@zz=split(/:/,@add[4]);#print " \n\nn  ----------> @zz[1] \n";
						next if (@zz[1] !~ /-/i);
						next if ($_ =~ /^0/);
						print IN12 "\n\n" if ($_ =~ /Component Name/);
						print IN12 "####### $_";
					}	
				}
           	}		
		}
	close(OUT);	close(IN1);close(IN12);
	}
#unlink("./temp.txt");
	#print " Out is ===> @add ";
	