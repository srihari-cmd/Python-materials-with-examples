#!/usr/bin/perl
open(IN,"file1");
open(OUT,">file3");
while($lines=<IN>){
	chomp($lines);
	if($. == $ARGV[0]){
		print OUT " my name is sriram \n";
	}
		else{
			print OUT "$lines\n";
    }
}
		close(IN);
		close(OUT);
