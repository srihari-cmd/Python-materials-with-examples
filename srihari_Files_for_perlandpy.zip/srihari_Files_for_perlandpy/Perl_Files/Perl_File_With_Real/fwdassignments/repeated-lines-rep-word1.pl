#!/usr/bin/perl
%line=();
%words=();
open(IN,"repeated-lines-rep-word.txt")||(die $!);
while($lines=<IN>){
	chomp($lines);
	$l++;
	$line{$lines}++;
	@s=split(/ /,$lines);
		foreach(@s){
		chomp($_);
		$words{$_}++;
		$w++;
	}
}
		print " Total lines in file => $l\n";
		print " Total words in file => $w\n";

		while(($k,$v)=each(%line)){
			print " $k => $v\n";
		}

			while(($k,$v)=each(%words)){
				print " $k => $v\n";
			}
