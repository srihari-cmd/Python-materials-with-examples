#!/usr/bin/perl

# This function is used to find max size file in given directory.

sub max_size{
	%filsiz=();
	$re=$_[0];
	@dir=@$re;
	opendir($IN,"@dir")||die $!;
	while($file = readdir $IN){
  	if( -f $file){
  		$size1 = -s "$file";
  		push(@size,$size1);
  		push(@files,$file);
  		$filsiz{$file}=$size1;
  	}
	}
  		@size= sort  { $a <=> $b } @size;
  			while((my $k,my $v)=each(%filsiz)){
    			if($filsiz{$k} == $size[-1]){
      			print "\n The max size of file is  => $k : size is $v\n";
    			}
  			}
}

# This function is used to find min size file in given directory.

sub min_size{
	%filsiz=();
  $re=$_[0];
  @dir=@$re;
	opendir($IN,"@dir")||die $!;
	while($file = readdir $IN){
  	if( -f $file){
  		$size1 = -s "$file";
  		push(@size,$size1);
  		push(@files,$file);
  		$filsiz{$file}=$size1;
		}
	}
  	@size= sort  { $a <=> $b } @size;
  	while((my $k,my $v)=each(%filsiz)){
    	if($filsiz{$k} == $size[1]){
      	print "\n The Min size of file is  => $k : size is $v\n\n";
    	}
  	}
}


max_size(\@ARGV);
min_size(\@ARGV);
      
