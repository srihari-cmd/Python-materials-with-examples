#!/usr/bin/perl
# To print how many  sriram words in file.
open(IN,"text");
	while($line=<IN>){
		chomp($line);
		@a=split(/\s+/,$line);
    foreach(@a){
    	if($_=~/\b\d+\b/){
			  $c++;
			}
				elsif($_=~/^\D+$/){
					$c1++;
       	}
					elsif($_=~/\D+\d+/ | /\d+\D+/){
						$c2++;
					}
    }
  }
close(IN);
print " The number word count is       => $c\n";
print " The char word count is         => $c1\n";
print " The Alphanumeric word count is => $c2\n";
