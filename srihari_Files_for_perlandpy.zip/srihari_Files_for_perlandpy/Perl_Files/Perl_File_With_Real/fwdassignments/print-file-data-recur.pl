#!/usr/bin/perl
@fname=$ARGV[0];
foreach$f(@fname){
		#print"$f\n";
		open(IN,"$f")||warn "file cant exist";
		while($lines=<IN>){
			if($lines =~ /^file\s\:(.*)/){
			#	print "file names $1\n";
				push(@fname,$1);
			}	
	  }  
	}
	@d= reverse(@fname)," \n";
	shift(@d);
	#print @d," \n";
	foreach(@d){
		open(IN1,"$_");
		while($line=<IN1>){
			chomp($line);
			if($line !~ /^file\s\:(.*)/){
				print"$line\n";
			}
		}
	}
        		
#	foreach(reverse(
#file : filer1.txt
# values : file name is filer.txt

