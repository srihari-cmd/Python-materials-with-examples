#!/usr/bin/perl
@a=qw(a b c d e f g h a b d);
@a1= grep { $count{$_}++ < 2} @a;
print " the unique values are => @a1\n";

@a= grep { $count{$_}++ > 2} @a;
print " the unic value is = @a\n";
