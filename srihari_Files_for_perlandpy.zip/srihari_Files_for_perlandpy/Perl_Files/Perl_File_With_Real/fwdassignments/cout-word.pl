#!/usr/bin/perl
open(IN,"text");
while(<IN>) {
	@a=split(/\s+/,$_);
	$count+=grep /^sriram$/,@a;
}
print "$count\n";
