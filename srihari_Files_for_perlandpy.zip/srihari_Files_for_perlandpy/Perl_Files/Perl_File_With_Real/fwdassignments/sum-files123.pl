#!/usr/bin/perl
# to make sum two files data.
sub sumfiles{
  $file=shift;
  $sum=0;
  open(IN,"$file");
  while($line=<IN>){
    chomp($line);
    #print " the values are :$line\n";
    @a=split(/\s+/,$line);
    foreach(@a){
      next if($line=~/[a-z]/ | /\}/ );
      print "the words are : $_\n";
      $sum+=$_;
    }
  }
  return $sum;
}
$a=sumfiles(@ARGV[0]);
$b=sumfiles(@ARGV[1]);
print  "the file1 tot sum is $a\n";
print  "the file2 tot sum is $b\n";
$sum1=(($a-$b)/$a)*100;
print " The different is => $sum1%\n";


