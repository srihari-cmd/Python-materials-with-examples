#!/usr/bin/perl
%filsiz=();
@files1=@ARGV;
foreach $file(@files1){
  $size1 = -s "$file";
  push(@size,$size1);
  push(@files,$file);
  $filsiz{$file}=$size1;
}
@size= sort  { $a <=> $b } @size;
$ref=\%filsiz;
max(max);

sub max{ 
  %dref=%{$ref};
  while(($k,$v)=each(%dref)){
    if($filsiz{$k} == $size[-1]){
      print "\n The max size of file is  => $k : size is $v\n";
    }
  }
}

min(min);
sub min{
  %dref=%{$ref};
 while(($k,$v)=each(%dref)){
      if($filsiz{$k} == $size[0]){
        print "\n The min size of file is =>  $k: size is $v\n\n";
      }
  }
}

