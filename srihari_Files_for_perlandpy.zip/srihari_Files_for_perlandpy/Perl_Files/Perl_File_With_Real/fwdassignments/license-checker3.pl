#!/usr/bin/perl
use Data::Dumper;
%hash=();
$var=$ARGV[0];
open(IN," license-checker.txt ");
   while($lines=<IN>){
      chomp($lines);
			if($lines=~/^\"(\w+)\"\s+(\w+\.\d{3}),\s+\vendor:\s+(\w+)/){
				$tools=$1;
				$versions=$2;
				$vendorname=$3;
				$hash{$tools}{"vendorname"}=$vendorname;
				$hash{$tools}{"versions"}=$versions;
				
      }
       elsif($lines=~/(\w+.*)\:\s+\((.*)\s(\d{1,3})\s(.*)\;(.*)(\d)(.*)\)/){
					$hash{$tools}{"tot_lic"}=$3;
					$hash{$tools}{"in_use_lic"}=$6;
				 }
						
				else {
        	 	@lines2=split(' ',$lines);
						push(@users,$lines2[0]);
				#$hash{$tools}{"lic"}{$lines2[4]}++ if($lines2[4]);
						$hash{$tools}{"users"}{$lines2[0]}++ if($lines2[0]);
  			}
	 }


while(($k,$v)=each(%hash)){
		if($var eq "all" || $var eq $k){
  		print "Toolname is => $k\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    	while(($k1,$v1)=each(%{$v})){
				if(ref($v1) eq "HASH"){
      	print "$k1 => \n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
      	while(($k2,$v2)=each(%{$v1})){
        	print "User Name is : $k2 --> $v2\n" ;
      	}
    	}
				else {
						print "  $k1 ---> $v1\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
			}
						
 		}
 	}
}

#print "$arg\n";
foreach (@users){
	#print"users $_\n" ;
  next unless($var eq $_ && $_ =~ /\S/);
	   while(($k,$v)=each(%hash)){
  	  	print "Toolname is : $k \n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
				while(($k1,$v1)=each(%{$v})){
					if(ref($v1) ne "HASH"){  
						next if($k1 =~ /lic/);
						print " $k1  $v1 \n";
					}
				}
     }
   
						last;
}
