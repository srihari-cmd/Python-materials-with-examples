#!/usr/bin/perl
use Data::Dumper;
sub fun1 {
%hash=();
$a=$_[0];
$file=$$a;
foreach($file){
open(IN,$_);
		while($lines=<IN>){
		chomp($lines);
		if($lines=~/\w+\s(\w+)\{/){
			print "$1\n";
			$fun=$1;
		}
			elsif ($lines=~/\}/) {
				$hash{$_}{$fun}=$sum;	
				$sum=0;
			}
	
			elsif ($lines=~/\d+/) {	
				@cont=split(' ',$lines);
				$sum+=$_ foreach(@cont);	
			}
		}
	}
	return %hash;
}
%c=&fun1(\$ARGV[0]);
%c1=&fun1(\$ARGV[1]);
print Dumper(%c),"\n";
print Dumper(%c1),"\n";

print "Comparision Report Summary\n";
	while (($k,$v)=each(%c)){
		while(($a,$b)=each(%{$v})){
			while(($k1,$v1)=each(%c1)){
				while(($a1,$b1)=each(%{$v1})){
					if($a eq $a1){
						$base=abs(&func2($b,$b1));
						$refe=abs(&func2($b1,$b));
						#print " the base value is : $base \n";
						#print " the ref  value is : $refe \n";
						print "\n Difference is   :",abs($base-$refe),"% \n";
					}
				}
			}
		}
	}

sub func2 {
	$a1=$_[0];
	$b1=$_[1];
	$c1=(($a1-$b1)/$a1)*100;
	return $c1;
}

