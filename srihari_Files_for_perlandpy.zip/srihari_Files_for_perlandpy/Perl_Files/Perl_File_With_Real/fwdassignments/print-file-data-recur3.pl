#!/usr/bin/perl
print"\n File names are \n~~~~~~~~~~~~~~~~~~~~~~~~~>\n";	
sub fun {
open(IN,$_[0])||warn "file can't open $!";
  while($lines=<IN>){
    push(@files,$_[0]);
    chomp($lines);
    if ($lines=~/file:(.*)/){
      if(-e $1) {
      print " $_[0]\n";
        fun ($1);
      }
    }
    		else{
    			foreach(reverse@files){
      			open(IN,$_);
        		while($lines=<IN>){
        			chomp($lines);
    					if ($lines!~/file:(.*)/){
          			print " $lines\n";
							}
        		}
          	close(IN);
      		}
    		}
  }
  close(IN);
}
fun($ARGV[0]);
