#!/usr/bin/perl
$a="@\n	sriram chowdary ";
@d=split("",$a);
%count=();
foreach(@d){
	$count{$_}++; 

} 
	while (($k,$v)=each( %count)){
		print "$k $v\n";
	}
