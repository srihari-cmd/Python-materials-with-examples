#!/usr/bin/perl
use Data::Dumper;
%hash=();
open(IN,"find-tools.txt");
while($lines=<IN>){
  chomp($lines);
	if ($lines =~ /^"/){
		@a=split(/ /,$lines);
		push(@tools,@a[0]);
		push(@vert,@a[1]);
		push(@vendor,@a[3]);
    $hash{$a[0]}{"vertion"}=$a[1];
		$hash{$a[0]}{"vendor"}=$a[3];
	}
    @c=();
		if($lines =~ /\)$/){
			@b=split(/ /,$lines);
			foreach(@b){
				if($_ =~ /\d+/){
					push(@c,$_);
				}
			}		
          push(@tlic,@c[0]);
	  			push(@ulic,@c[1]);
          $hash{$a[0]}{"totlic"}=$c[0];
          $hash{$a[0]}{"usdlic"}=$c[1];
		}	
					if($lines !~ /^["Uf]/){
						@z=();
						@z=split(/ /,$lines);
						push(@users,$z[0]);
						$hash{$a[0]}{"users"}{$z[0]}++ if($z[0]);
					}
}
#print " tooles   are =>  @tools \n";
#print " vertions are =>  @vert \n";
#print " vendors  are =>  @vendor \n";
#print " Tot lic  are =>  @tlic \n";
#print " Usd lic  are =>  @ulic \n";
#print " The users are =>  @users \n";
#print Dumper(%hash),"\n";
#print keys(%hash),"\n";


print keys(%hash),"\n";
