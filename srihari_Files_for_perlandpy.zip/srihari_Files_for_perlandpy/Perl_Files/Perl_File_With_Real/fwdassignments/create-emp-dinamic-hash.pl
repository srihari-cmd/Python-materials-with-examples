#!/usr/bin/perl
use Data::Dumper;
%emp=();
@enum=(101);
foreach(@enum){
	print " Enter ename : ";           	$emp{$_}{ename}=<STDIN>;
	print " Enter age : ";            	$emp{$_}{age}=<>;
	print " Enter sal : ";             	$emp{$_}{sal}=<>;
	print " Enter No. of Children : ";	$ch=<>;
  while($ch--){
		print " Enter ur child name ";	$name=<>;
		push (@{$emp{$_}{childs}},$name);
	}
		print " Enter emp house no   : ";   $emp{$_}{address}{HNO}=<STDIN>;
		print " Enter emp strit name : ";   $emp{$_}{address}{STRNAME}=<STDIN>;
		print " Enter emp pin no     : ";   $emp{$_}{address}{PIN}=<STDIN>;
}

print Dumper(%emp);
