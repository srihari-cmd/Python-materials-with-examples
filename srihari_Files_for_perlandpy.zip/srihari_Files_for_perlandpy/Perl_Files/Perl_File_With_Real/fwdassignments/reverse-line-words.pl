#!/usr/bin/perl
open(IN,"reverse-line.txt")||(die $!);
while($line=<IN>){
  chomp($line);
  $rev= reverse($line);
  @splw= split(/ /,$rev);
    @r1=();
  foreach(@splw){
    @wrev=split(' ',reverse($_));
    push(@r1,@wrev);
  }
    $d= join(" ",@r1),"\n";
    print "$d\n";
}
    close(IN);


