#!/usr/bin/perl

# This function is used to find max size file in given directory.
sub max_size{
  $ref=$_[0];
  print" ref is  @di1  \n";
  @dir=@$ref;
  print"dir are : @dir \n";
  foreach(@dir){
    print "\n The Directory name is => $_\n~~~~~~~~~~~~~~~~~~~~~~~> \n";
    %filsiz=();
    @size=();
    opendir($IN,"$_")||die $!;
    while($file = readdir $IN){
      if( -f $file){
        $size1 = -s "$file";
        push(@size,$size1); 
        push(@files,$file);
        $filsiz{$file}=$size1;
        print " Files are  :  $file : size is => $size1 \n";
      }
    }
          @size= sort  { $a <=> $b } @size;
          while((my $k,my $v)=each(%filsiz)){
            if($filsiz{$k} == $size[-1]){
            $x=  "\n The max size of file in $_  => $k : size is $v\n\n";
            push(@x1,$x);
            }
          }
}
return "@x1";
}
# This function is used to find min size file in given directory.

sub min_size{
  $di1=$_[0];
  #print"direc  $di1 $di2 \n";
  @dir=@$di1;
  #print"dir are : $dir $dir1 \n";
  foreach(@dir){
    print "\n The Directory name is => $_\n~~~~~~~~~~~~~~~~~~~~~~~> \n";
    %filsiz=();
    @size=();
    opendir($IN,"$_")||die $!;
    while($file = readdir $IN){
      if( -f $file){
        $size1 = -s "$file";
        push(@size,$size1);
        push(@files,$file);
        $filsiz{$file}=$size1;
        print " $_ Files are  => $file size of file is => $size1 \n";
      }
    }
          @size= sort  { $a <=> $b } @size;
          while((my $k,my $v)=each(%filsiz)){
            if($filsiz{$k} == $size[0]){
            $z=  "\n The min size of file in $_  => $k : size is $v\n\n";
						push(@z1,$z);
            }
          }
}
return "@z1";
}
@r1=min_size(\@ARGV);
print "\n @r1 \n";
#@r=max_size(\@ARGV);
#print "\n @r \n";

