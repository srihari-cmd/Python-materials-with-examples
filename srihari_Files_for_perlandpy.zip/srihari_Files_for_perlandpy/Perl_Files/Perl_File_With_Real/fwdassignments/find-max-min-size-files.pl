#!/usr/bin/perl
%filsiz=();
opendir($IN,"dirc-open")||die $!;
while($file = readdir $IN){
  next if($file !~ /\.txt/);
  $size1 = -s "$file";
  push(@size,$size1);
  push(@files,$file);
  $filsiz{$file}=$size1;
}
	@size= sort  { $a <=> $b } @size;
	#print " the big size is = @size\n";
	#print "@files\n";
	#print "@size\n";
	#print keys%{filsiz},"\n";
	#print sort (values%{filsiz}),"\n";
  while(($k,$v)=each(%filsiz)){
		if($filsiz{$k} == $size[-1]){
			print " The max size of file is  => $k : size is $v\n";
	  }
  		if($filsiz{$k} == $size[0]){
    		print "The min size of file is =>  $k : size is $v\n";
    	} 
	}
