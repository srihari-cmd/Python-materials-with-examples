#!/usr/bin/perl
use Data::Dumper; 
%emp=();
opendir($IN,"emp")||die $!;
while($file=readdir $IN){
	chomp($file);
	if ($file =~ /^empl/){
		open(IN1,"$file")|| warn $!;
		while($lines=<IN1>){
			chomp($lines);
			if($. == 1){
				@a=split(/\s+/,$lines);
        push(@c,@a);				
				#print "  \$. is = 1  $. @a[0] ,@a[1], @a[2]\n";
			}
				if($. > 1){
					@b=split(/\s+/,$lines);
					chomp(@b);
				#	print " a is @c[0] ,@c[1] , @c[2],@c[3] \n ";
				#	print " b is @b[0] ,@b[1] , @b[2],@b[3] \n";
					$emp{@b[0]}{@a[1]}=@b[1];
					$emp{@b[0]}{@a[2]}=@b[2];
					$emp{@b[0]}{@a[3]}=@b[3];
					$emp{@b[0]}{@a[4]}{sal}=@b[4];
					$emp{@b[0]}{@a[4]}{"comm"}=800;
					$emp{@b[0]}{@a[4]}{"disc"}=80;
				}
    }
	}
}
print Dumper(%emp),"\n";     # To print hash strcture
print " keys are =>\n ",join("\n",keys(%emp)),"\n";    # To print emp keys
print " keys are =>\n \n",join("\n",keys(%{emp->{500}})),"\n";   # To print 500 employee keys
print "\n values are =>\n\n",join("\n",values(%{emp->{500}})),"\n";  # To print 500 employee values
print " keys are =>\n \n",join("\n",keys(%{emp->{500}->{salary}})),"\n";   # To print 500 employee salary keys
print "\n values are =>\n\n",join("\n",values(%{emp->{500}->{salary}})),"\n";  # To print 500 employee salary values
