#!/usr/bin/perl
$a=$ARGV[0];
print "the value is $a\n";
	open(IN,"file1")||die $!;
	while(<IN>){
  	chomp($_);
    if($_%2==0 && $a eq "even"){
			print"this is even no =$_\n";
 		}
			elsif($_%2==1 && $a eq "odd") {
      	print "this is odd no= $_\n";
			}
	}
close(IN);
