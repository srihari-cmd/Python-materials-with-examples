#!/usr/bin/perl
open(IN,"reverse-line.txt")||(die $!);
while($line=<IN>){
  chomp($line);
	@rev=split(/\s+/,$line);
	print "@rev\n";
  @rev1=reverse(@rev);
  print " @rev1\n";
}    
close(IN);


                                                                                                                                               
                                                                                                                                                 
                                                                                                                                                 
                       
