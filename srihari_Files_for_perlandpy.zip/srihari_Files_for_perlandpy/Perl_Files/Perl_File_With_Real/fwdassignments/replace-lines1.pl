#!/usr/bin/perl
open(IN,"file1");
open(OUT,">file333");
while($lines=<IN>){
	chomp($lines);
	if($. == $ARGV[0]+1){
		print OUT "my name is sriram\n";
	}
		if($. == $ARGV[0]-1){
			print OUT "my name is kumar\n";
		}
			if($. == $ARGV[0]){
				print OUT "my name is srikumar\n";
			}
				else{
					print OUT "$lines\n";
				}
}

