#!/usr/bin/perl

# use module
use XML::Simple;

# create object
$xml = new XML::Simple;
print " 1 $xml\n";
# read XML file
$data = $xml->XMLin("xml-file.xml");

# access XML data
print "$data->{name} is $data->{age} years old and works in the $data->{department} section\n";
#Here's the output:
