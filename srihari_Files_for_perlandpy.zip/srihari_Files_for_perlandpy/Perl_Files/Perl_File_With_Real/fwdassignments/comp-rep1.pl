#!/usr/bin/perl
use Data::Dumper;
sub com{
@a=$_[0];
print "000 @a\n";
%hash=();
#@files=('file2-sum.pl','file1-sum.pl');
foreach $f(@a){
print "11 $f\n";
open(IN,"$f");
while($line=<IN>){
  chomp($line); 
  if ($line=~/\w+\s(\w+)\{/){
    $fu=$1;
    next;
  }
    elsif ($line =~ /\}/){
       $hash{$f}{$fu}=$sum;
				$sum=0;
    }
      elsif($line =~ /\d+/){
        @count=split(' ',$line);
				foreach(@count){
					$sum+=$_;
				}
      }
  }
}
   
return %hash;
}
%hash1=&com($ARGV[0]);
%hash2=&com($ARGV[1]);
print Dumper(%hash1);
print Dumper(%hash2);
while(($k,$v)=each(%hash1)){
	while(($k1,$v1)=each(%{$v})){
		while(($ka,$va)=each(%hash2)){
			while(($k1a,$v1a)=each(%{$va})){
				if($ka eq $k1a){
					
				}
			}
		}
	}
}	

