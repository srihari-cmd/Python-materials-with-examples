#!/usr/bin/perl
%filsiz=();
@files1=@ARGV;
foreach $file(@files1){
#  next if($file !~ /\.txt/);
  $size1 = -s "$file";
  push(@size,$size1);
  push(@files,$file);
  $filsiz{$file}=$size1;
}
  @size= sort  { $a <=> $b } @size;
  print " The files are => @files\n";
  print " The sizes are =>  @size\n";
  while(($k,$v)=each(%filsiz)){
    if($filsiz{$k} == $size[-1]){
      print " The max size of file is  => $k : size is $v\n";
    }
      if($filsiz{$k} == $size[0]){
        print "The min size of file is =>  $k : size is $v\n";
      }
  }

