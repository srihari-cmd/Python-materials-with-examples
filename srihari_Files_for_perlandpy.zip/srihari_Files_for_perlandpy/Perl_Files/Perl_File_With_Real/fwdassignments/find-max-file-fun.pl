#!/usr/bin/perl
sub maxfile {
	%filsiz=();
	$f=$_[0];
  @file=@$f;
	print"@file\n";
	foreach(@file){
		$size= -s $_;
		push(@files,$_);
		push(@sizes,$size);
		$filsiz{$_}=$size;
	}
		@sizes1= sort  { $a <=> $b } @sizes;
 		while(($k,$v)=each(%filsiz)){
    	if($filsiz{$k} == $sizes1[-1]){
      	print " The max size of file is  => $k : size is $v\n";
      }
    }
}
maxfile(\@ARGV);
