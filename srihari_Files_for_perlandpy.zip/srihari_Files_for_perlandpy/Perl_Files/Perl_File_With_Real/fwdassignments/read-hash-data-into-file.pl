#!/usr/bin/perl
use Data::Dumper;
open(OUT,">file232.txt");
%hash=(1,kumar,2,naidu,3,chowdary);
print OUT Dumper(%hash),"\n";



