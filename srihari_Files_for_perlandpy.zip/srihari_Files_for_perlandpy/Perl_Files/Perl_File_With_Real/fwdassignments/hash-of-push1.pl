#!/usr/bin/perl
use Data::Dumper;
@a=qw(1 2 3 4 5 6 7 8 9);
%hash=();
foreach(@a){
push @{$hash{eno}},$_;
}
print Dumper(%hash);
