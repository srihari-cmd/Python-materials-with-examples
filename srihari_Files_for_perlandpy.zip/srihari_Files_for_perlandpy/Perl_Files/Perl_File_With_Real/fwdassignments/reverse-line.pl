#!/usr/bin/perl
open(IN,"reverse-line.txt");
while($line=<IN>){
	chomp($line);
	$rev= reverse($line),"\n";
  print "$rev\n";
}

