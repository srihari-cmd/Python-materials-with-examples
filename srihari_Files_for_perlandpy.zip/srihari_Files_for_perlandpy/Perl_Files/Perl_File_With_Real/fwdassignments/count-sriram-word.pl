#!/usr/bin/perl
open(IN,"text");
while(<IN>) {
	@a=split(/\s+/,$_);
	$count+=grep /^sriram$/,@a;
		#print "111 @a \n";
		foreach (@a){
   if($_ =~ /^sriram$/){
		print"Name is  : $_\n";
	}
	}
}
#print "count is : $count\n";
