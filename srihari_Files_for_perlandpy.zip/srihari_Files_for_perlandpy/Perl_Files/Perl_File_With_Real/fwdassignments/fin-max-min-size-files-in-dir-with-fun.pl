#!/usr/bin/perl
%filsiz=();
opendir($IN,"dirc-open")||die $!;
while($file = readdir $IN){
  next if($file !~ /\.txt/);
  $size1 = -s "$file";
  push(@size,$size1);
  push(@files,$file);
  $filsiz{$file}=$size1;
}
  @size= sort  { $a <=> $b } @size;
 print"\n Max & Min size of files in directory \n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~> \n"; 
$ref=\%filsiz;
max($ref);
sub max{
	%dref=%{$ref};
  while(($k,$v)=each(%dref)){
    if($filsiz{$k} == $size[-1]){
      print " The max size of file is  => $k : size is $v\n";
    }
  }
}

min($ref);
sub min{
	%dref=%{$ref};
  while(($k,$v)=each(%dref)){
      if($filsiz{$k} == $size[0]){
        print "\n The min size of file is =>  $k : size is $v\n\n";
      }
  }
}

