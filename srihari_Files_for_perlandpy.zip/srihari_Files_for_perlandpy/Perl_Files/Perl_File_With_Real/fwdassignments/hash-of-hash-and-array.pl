#!/usr/bin/perl
%emp=(101=>{ename=>'srikumar',age=>26,exp=>'3',child=>[raj,dhiya]},
      102=>{ename=>'chowdary',age=>27,exp=>4,child=>{name1,krish,loc=>{1,narpala,2,narasapuram},name2,kala}},
      103,{ename,'sriram',age,28,exp=>5,child,[prani,[lali,balu,gani],monika]});

#print  " => the emp keys are\n", join("\n",sort keys(%emp));                               # to print emp keys

#print "\n => the emp values are \n", join("\n",sort values(%emp));                      # to print emp values

#print  "\n => the 102  keys are \n",join("\n", sort keys(%{@emp{102}})),"\n";               # to print 102  key

#print  "  => the 102  values are \n ",join("\n", sort values(%{@emp{102}}));             # to print 102 values

#print  " \n => the 103  values are \n ",join("\n", sort values(%{@emp{103}}));             # to print 103 values

print  " \n => the 102 child  keys val are\n ",join("\n", sort %{@emp{102}->{child}});  # to print 102 child  keys &val

#print  " \n => the 102 child  keys are \n ",join("\n", sort keys(%{@emp{102}->{child}}));  # to print 102 child  keys

#print  " \n => the 102 child  values are \n ",join("\n", sort values(%{@emp{102}->{child}}));  #to print 102 child values

print  " \n => the 102 loc keys valu are \n",join("\n", sort %{@emp{102}->{child}->{loc}});  #to print 102 loc keys values

print  " \n => the 102 loc  keys are \n ",join("\n", sort keys(%{@emp{102}->{child}->{loc}}));  #to print 102 locations keys

print  " \n => the 102 loc  values are \n ",join("\n", sort values(%{@emp{102}->{child}->{loc}}));  #to print 102 locations

#print  " \n => the 103 child  values are \n ",join("\n", sort @{$emp{103}->{child}}),"\n"; #to print 103 child values

#print  " \n => the 103 child  firest name \n ",join("\n", sort $emp{103}->{child}[0]),"\n"; #to print child prani

#print  " \n => the 103 child  arrar 1 name \n ",join("\n", sort $emp{103}->{child}[1][0]),"\n"; #to print child lali

#print "\n","101 emp name is :$emp{101}->{ename}\n";            # to print 101 emp name
#print "101 emp age is  :$emp{101}->{exp}\n";                  # to print 101 emp exp
#print "103 emp exp is  :$emp{103}->{exp}\n";                  # to print 103 emp exp
#print "103 child name is : @emp{103}->{child}->[0]\n";             #to print 103 child name
#print "102 child name is : @emp{102}->{child}->{name1}\n";             #to print 102 child name

#print "102 child keys are :", keys%($emp{102}->),"\n";    # to print child keys

#print "102 child keys are : @emp{103}->{child}->[1]->{child}[2]\n";    # to print child keys

#print  join("the emp keys are\n ",keys(%emp),"\n");                # to print emp keys

