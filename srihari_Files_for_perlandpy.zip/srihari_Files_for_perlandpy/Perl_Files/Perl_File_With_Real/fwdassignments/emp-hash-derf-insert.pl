#!/usr/bin/perl
%emp=(101=>{ename=>'srikumar',age=>26,exp=>'3',child=>[raj,dhiya]},
      102=>{ename=>'chowdary',age=>27,exp=>4,child=>{name1,krish,loc=>{1,narpala,2,narasapuram},name2,kala}},
      103,{ename,'sriram',age,28,exp=>5,child,[prani,[lalli,balu,gani],monika]});


$emp{101}->{dept}="10";              # to inser dept key and values into 101 emp
print " 101 emp dept no is : $emp{101}->{dept}\n";
print"the keys of 101 emp is  =",(keys %{$emp{101}},"\n\n");

$emp{102}->{dept}="20";
print "emp 2 dept no is :$emp{102}->{dept}\n\n";

$emp{102}{child}{loc}{3}="gugoodu";   # to insert value in hash of hash
print "the 102 new loc : ", %{$emp{102}{child}{loc}},"\n\n";

$emp{102}{child}={name3,royal,name4,kumaran}; # to


$emp{103}->{child}[4]="balu";                   # to insert a new value in 103 emp child 
print " the 103 child details :$emp{103}->{child}[4]\n\n";

$emp{102}->{child}{3}="ram";                           # to insert a new child in 102 emp
print "the 102 new child is :$emp{102}->{child}{3}\n\n";

$emp{103}{child}[1][4]="royal";    # to insert vaalus in array of array;
print " the child array of array names are ; @{$emp{103}{child}[1]}\n\n"; 

push @{$emp{101}{child}},balu,babu;  
print "the 101 child names are : @{$emp{101}{child}}\n\n";

unshift @{$emp{103}{child}[1]},sri,ram;
print " the 103 child array of array names are :@{$emp{103}{child}[1]}\n\n";
