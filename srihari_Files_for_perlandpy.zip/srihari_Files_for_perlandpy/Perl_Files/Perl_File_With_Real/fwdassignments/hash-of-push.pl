#!/usr/bin/perl
use Data::Dumper;
%emp=();
@enum=(101,102,103,104);
foreach(@enum){
print "enter ename\n";
$emp{$_}{ename}=<STDIN>;
print " enter age\n";
$emp{$_}{age}=<>;
print " enter sal \n";
$emp{$_}{sal}=<>;
print " enter childrens names \n";
@ch=<>;
push @{$emp{$_}{childs}},@ch;
}

print Dumper(%emp);
