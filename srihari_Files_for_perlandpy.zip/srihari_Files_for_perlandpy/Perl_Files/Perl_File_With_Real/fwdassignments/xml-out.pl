#!/usr/bin/perl

# use module
use XML::Simple;
use Data::Dumper;

# create array
@arr = [ 
        {'country'=>'england', 'capital'=>'london'},
        {'country'=>'norway', 'capital'=>'oslo'},
        {'country'=>'india', 'capital'=>'new delhi'} ];

# create object
$xml = new XML::Simple (NoAttr=>1, RootName=>'data');

# convert Perl array ref into XML document 
$data = $xml->XMLout(\@arr);

# access XML data
open (OUT,">xml-file22.xml");
print OUT  Dumper($data) ;
