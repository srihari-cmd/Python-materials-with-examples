#!/usr/bin/perl
# To print how many  sriram words in file.
open(IN,"text");
  while($line=<IN>){
		chomp($line);	
    @a=split(/\s+/,$line);
    	$c+=grep /\b\d+\b/,@a;  
    	$c1+=grep /^\D+$/,@a;  
    	$c2+=grep /\d+\D+/ | /\D+\d+/,@a;  
  }
close(IN);
print "the char word count is  : $c1 \n";
print "the numb word count is  : $c \n";
print "the alpno word count is : $c2 \n";

