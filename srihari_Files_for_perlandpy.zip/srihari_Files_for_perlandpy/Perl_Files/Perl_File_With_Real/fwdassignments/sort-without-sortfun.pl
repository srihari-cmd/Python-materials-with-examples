#!/usr/bin/perl 
@a=qw(1 2 3 0 4 35 7 78 43 4 5 54 6 5);
   for ($i=0;$i<$#a;$i++){
      for ($j=0;$j<$#a;$j++ ){
        if ($a[$j]<$a[$j+1]){
					$temp=$a[$j];
          $a[$j]=$a[$j+1];
          $a[$j+1]=$temp;
        }
      }
    }
	print " @a\n";

@b=qw(a b x z c c d y s te f g h i j k l);
@bi=sort { $a cmp $b} @b;
print "@bi\n";
%hash=();
foreach(@bi){
	$hash{$_}++;
}
use Data::Dumper;
print Dumper(%hash) ,"\n";
