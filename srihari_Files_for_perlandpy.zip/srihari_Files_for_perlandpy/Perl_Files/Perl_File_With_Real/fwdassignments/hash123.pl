#!/usr/bin/perl
%a=(1,kumar,2,naidu,3=>{4,balu,5,babu});
while(($k,$v)=each(%a)){
print "$a{$k}\n";
while(($k1,$v1)=each (%{$v})){
print "$a{$k1}\n";
}
}
print "aaa ($a{1})\n";
