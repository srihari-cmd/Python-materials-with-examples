
#here we are performing to get value using key in hashes data type
# here we can get the value using key with $ symbol like :$hash{'key'};



print %hash =  ('srihari' => 28,'vijay' => 26,'ravindra' => 30);
print "\n";
print $hash{'vijay'};
print "\n";

