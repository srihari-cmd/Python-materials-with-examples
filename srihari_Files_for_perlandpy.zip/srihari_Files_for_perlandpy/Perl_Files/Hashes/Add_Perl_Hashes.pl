#Add Perl Hashes
#As you can see we already have a hash %newHash, and now we need to add more entries into it.


%hash = ('srihari' => 28,'vijay' => 22);
%Newhash = %hash;
@arry = %Newhash;
print "@arry";
print "\n";


@arrykeys = keys(%Newhash);
@arryvalues = values(%Newhash);


print "@arrykeys \n";
print "@arryvalues \n";

