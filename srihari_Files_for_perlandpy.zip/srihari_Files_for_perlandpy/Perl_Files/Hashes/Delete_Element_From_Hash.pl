#here we are performing to delete the values from hash file

%hash = ('srihari' => 28,'vijay' =>26,'ravi' => 30);
%Newhash =%hash;

print %Newhash;
print "\n";

delete $Newhash{'vijay'};

print %Newhash;
print "\n";
