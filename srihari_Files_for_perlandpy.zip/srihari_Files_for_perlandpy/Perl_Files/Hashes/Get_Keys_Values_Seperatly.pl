#here first we define the hash file and we again created new hash name and then create to get keys and values separatly and then 
#we will print all the values in last.

%hash = ('srihari' => 28,'vijay' => 22);
%Newhash = %hash;
@arry = %Newhash;
print "@arry";
print "\n";


@arrykeys = keys(%Newhash);
@arryvalues = values(%Newhash);


print "@arrykeys \n";
print "@arryvalues \n";

