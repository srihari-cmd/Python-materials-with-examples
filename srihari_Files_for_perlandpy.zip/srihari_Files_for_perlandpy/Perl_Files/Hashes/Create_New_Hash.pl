
#Note: Each Key in hash should be unique or else it will override your value, which was assigned previously
#How can we assign a hash to another hash? Simple, same way as we do for We can also print entire hash.

%hash =  ('srihari' => 28,'vijay' => 26,'ravindra' => 30);

%Nhash = %hash;  					# here create a new name 

print %Nhash;
print "\n";

print $Nhash{'vijay'};
print "\n";
