
#here we are performing to create a hash file 

%hash =  ('srihari' => 28,'vijay' => 26,'ravindra' => 30);

%Nhash = %hash;

print %Nhash;
print "\n";
