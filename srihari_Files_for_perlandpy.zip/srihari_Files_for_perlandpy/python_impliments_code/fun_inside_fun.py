
# how to passs values(commands) to the function which ass been repeated code  

def test():
    def sub(var,timeout=None):
        try:
            a = var + " hello world"
            print (timeout)
            print(a)
        except
            print("not coorect")
    
    b = sub("touch")
    c = sub("ls",30)

test()


def file_create(command_interface,vserver,path,size)
             input_args = {'command_interface': node_obj,
                                'vserver': vserver,
                                'path': path,
                                'size': size,
                                'timeout': '120'}
                               
        return VolumeFile(**input_args)
       
       
test_obj1=file_create(command_interface=self.node_obj,
                                vserver=self.data_vserver,
                                path= '/vol/' + self.vol_name + '/' + self.dir_name + '/' + filename,
                                size= '1K')
                               
test_obj1.create()






