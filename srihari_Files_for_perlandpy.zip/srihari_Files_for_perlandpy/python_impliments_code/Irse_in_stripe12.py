from pynacl.ontap.volume import Volume
import os
from pynacl.ontap.vserver import Vserver
import random
import sys
from pynacl import log_global
import pynacl.apiset
import pytest
from pynate.process.fork import NATEProcessFork
from pynacl.ontap.node import Node
from pynacl.ontap.node import Node
from pynacl.ontap.volume.file import VolumeFile
from WaflFit.FITv2.lib.Wfitlib import Volume_lib

def init():
    Test.description("init(): Initialize resources")
top_global_param_file = "ENV['TOP_LOGDIR_UNIX'}/" + "top_global_params"
    ## Initialize Options
    Options = new Options()
    Options.parameters(**{definitions :[
                            'name'  : "TEST_CONTROLLERS",
                            'description' :"test controllers list",
                            'spec'  : "s",
                            'name ' : "SHARED_OBJECTS",
                            'description' : "shared object info file",
                            'spec'  :"s",
                            'name'  :"VOL_INFO_FILE",
                            'description' : "vol info file",
                            'spec'   : "s",
                            'name'  : "NODES",
                            'description' : "List of nodes",
                            'spec'   : "s",
                            'name ' :"NFS_CLIENTS",
                            'description' : "List of nfs clients",
                            'spec'  : "s",
                            'name'  : "CLUSTER_CONFIG_FILE",
                            'description' : "Cluster configuration file",
                            'spec' : "s",
                            'name'  : "MOUNT_INFO_FILE",
                            'description' : "mount info file",
                            'spec'   : "s",
                            'name'  : "SHARE_INFO_FILE",
                            'description' : "share info file",
                            'spec '   :"s",
                            'name '  : "TEST_LOCATION",
                            'description ': "Location of testdir",
                            'spec '   : "s",
                            'name'    : "TEST_COMMON_VOL",
                            'description' : "Location of testdir",
                            'spec'  : "s",
                            'name'  : "COMMON_VOL",
                            'description' : "Location of testdir",
                            'spec' : "s",
                            'name'   : "TIMEOUT",
                            'description' : "Max execution time",
                            'spec '      : "s",
                            'name' : "TPERMUTE",
                            'description ':
                                   "Should I run different permutations of testcases available in a workflow?",
                            'spec' : "s",
                            'name' : "TPARALLELISM",
                            'description' :
                                  "How many instances of testcases I can run in parallel.
                                   DONT CONFUSE THIS WITH SET_SIZE",
                            'spec' : "s",
                            'name '  : "RUN_IRON",
                            'description' : "Should I run iron?",
                            'spec '  : "s",
                            'default'   : "0",
                            'name '  : "TEST_DEDUPE",
                            'description' :"Should I consider dedupe for testing?",
                            'spec'  : "s",
                            'default' : "1",
                            'name '  : "CLUSTER_NAME",
                            'description' : "Name of the cluster",
                            'spec'  : "s"
                            'name'  : "COMPRESSION_TYPE",
                            'description' :
                                  "COMPRESSION TYPES to be considered for testing",
                             'spec'     : "s",
                            'default'  : "all"

        ]})
    Options.process()
    if ( file exist top_global_param_file):
        import top_global_param_file
        Params = \%top_global_params
        self.Log.comment( "global Params in top global - " + Dumper Params)
    else:
         Params = param_global.get()
         self.Log.comment( "global Params - " +Dumper Params)



    ##Initialize variables
    class snaplock():
    pytest.fixture(scope="class",autouse=True)


def setup_cleanup(self,request):
            self.log.info("global params in top global {}".format(Params))
            if (Params.get('SHARED_OBJECTS')):
                self.shared_vols = Params.get('SHARED_OBJECTS').split(' ')
            if (Params.get('NODES')):
                 self.nodes = Params.get('NODES').split(' ')
            self.cluster_config_file = Params.get('CLUSTER_CONFIG_FILE')
            self.log.info(self.cluster_config_file)
            self.cluster_name = Params.get('CLUSTER_NAME')
    ## Pull some files
    if (fileexist cluster_config_file):
        import cluster_config_file"
            or  exit()
        import "Params.get.[VOL_INFO_FILE]"
            or exist()
    else:
        import
            "Params.get['TEST_LOCATION']/Cluster/ConfigFiles/cluster_config_file"
            or exit()
        import "Params.get['TEST_LOCATION']/lib/VolInfo_[cluster_name.py]"
            or exit ()
    if :
        self.params.('TIMEOUT')=param.get('TIMEOUT')
    else:
         self.param.get('TIMEOUT')=3600

    Params.get['TIMEOUT'] = ClusterCommon::parse_time(Params.get['TIMEOUT'])
    timeout = Params.get['TIMEOUT']
    return True
   #end of sub init
class Test_lrse_in_stripe():
    pytest.fixture(scope="class", autouse=True)
    def setup_cleanup(self, request):
        top_global_param_file = Params.get('TOP_LOGDIR_UNIX')

        if (Params.get('SHARED_OBJECTS')):
            self.shared_vols = Params.get('SHARED_OBJECTS').split(',')
            request.cls.shared_volumes = self.shared_vols

        if (Params.get('NODES')):
            self.nodes = Params.get('NODES').split(',')


        self.cluster_config_file = Params.get('CLUSTER_CONFIG_FILE')
        self.log.info(self.cluster_config_file)
        self.cluster_name = Params.get('CLUSTER_NAME')
        self.sisclone_prefix = Params.get('SISCLONE_VOL')
        self.log_dir = Params.get('TOP_LOGDIR_UNIX')
        self.log_dir = self.log_dir + "/TestFiles.py"
        self.vol_infom = Params.get('VOL_INFO_FILE')
        self.vol_infom = self.vol_infom[:-2] + "py"
        self.log.info("self.log.info {}".format(self.vol_infom))
        sys.path.append(os.path.dirname(self.vol_infom))
        filename = os.path.basename(self.vol_infom)
        filename = filename[:-3]
        self.log.info("filename {}".format(filename))
        self.log.info("dirname {}".format(os.path.dirname(self.vol_infom)))
        testfiles1 = Params.get('TESTFILE_INFO_PY')
        test_filename = os.path.basename(testfiles1)
        test_filename = test_filename[:-3]
        sys.path.append(os.path.dirname(testfiles1))
        self.log.info("testfiles1 {}".format(testfiles1))
        if (os.path.isfile(self.cluster_config_file)):
            try:
                mod1 = importlib.import_module((test_filename))
                request.cls.tfiles = mod1.testfiles
            except Exception as e:
                self.log.info("Exception {}".format(e))
            try:
                mod = importlib.import_module((filename))
                request.cls.vol_info = mod.vol_info
            except Exception as e:
                self.log.info("Exception {}".format(e))
        if(Params.get('SHARED_OBJECTS') and self.shared_vols):
            self.temp = random.choice(self.shared_vols).split('#')
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver,request.cls.vol_type,request.cls.vol_lang= v.get_volume_info(volume=  self.temp[0], vserver = self.temp[3])
            self.log.info("self.vol_name={0}, self.node_obj={1}, self.vol_aggr={2}, self.data_vserver={3},self.vol_type,self.vol_lang".format(request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver))
        elif(Params.get('TEST_COMMON_VOL')):
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver = v.get_volume_info(volume= Params.get('COMMON_VOL'))
        else:
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver,request.cls.vol_type,request.cls.vol_lang = v.get_volume_random(volinfo=mod.vol_info)
            self.log.info("Using random volume {}".format(self.vol_name))
        if not(self.vol_name): return
        request.cls.nfs_client_obj, request.cls.nfs_mpt = v.nfs_mount_reuse(command_interface = request.cls.node_obj, volinfo = mod.vol_info, vserver = request.cls.data_vserver, volume = request.cls.vol_name,)
        self.log.info("nfs_mount_reuse param {0}{1}".format(request.cls.nfs_client_obj,request.cls.nfs_mpt))
        request.cls.njpath = v.get_junction_path(command_interface=self.node_obj,volume =self.vol_name, type='unix', volinfo=mod.vol_info)
        self.log.info("njpath {}".format(request.cls.njpath))
        request.cls.wjpath = v.get_junction_path(command_interface=self.node_obj,volume =self.vol_name, type='windows', volinfo=mod.vol_info)
        self.log.info("wjpath {}".format(request.cls.wjpath))
        yield
        self.log.info("cleanup")



    def perform_vol_file_lun_clone_ops(self):
        self.vol_name,self.Node_obj,self.aggr_name,self.src_vserver=v.get_volume_info(**{'command_interface' : self.node_obj,
                                            'volume' : self.vol_name,
                                            'vserver': self.data_vserver, })
        input_args = {'command_interface':self.Node_obj,
                      'allow_empty' : 1,
                       'filter' : {'volume' :self.dest_vol[0],
                       'volume-style-extended' :'flexvol',
                       'is-constituent' :'false'}}
        self.Nacl_obj= Volume.fetch(**{input_args})
        'is-constituent' :'false'}})
        if not (Nacl_obj):
            Log.warn("Unable to find destination volume...")
            Time.sleep(300)
            return CONFIG
        dest_aggr     = self.Nacl_obj.aggregate()
        vol_args={'command_interface' : self.Node_obj,
                  'filter' :{'aggregate' : self.dest_aggr,
                  'type' : "RW",
                  'volume-style-extended' :'flexvol',
                   'is-constituent' : 'false'}}
                self.volume_states=volume.fetch({**vol_args})



        vol_file_lun_clone_ops(volumes_states)
        Time.sleep(300)
        return True



    def vol_file_lun_clone_ops ()
        self.vol_name,self.Node_obj,self.aggr_name,selfdata_vserver,self.vol_type,self.vol_lang =v.get_volume_info(**{
                'command_interface' : self.node_obj,
                'volume'            : self.vol_name,
                'vserver'           : self.data_vserver
            })
       for i in volumes_states:
            ## Create Split and delete Volume Clone
            try :
                NACL::STask::VolumeClone.create(**{ 'command_interface' : self.Node_obj,
                                                       'flexclone' : "clone_vol_name",
                                                       vserver  : self.data_vserver,
                                                        'parent-volume' : selfvol_name,
                                                        'nacltask_if_exists' :'reuse',
                                                        '_was_created' : \was_created})
        for i in volumes_states:    $$$ foreach (@volumes_states)
            ## Create Split and delete Volume Clone
            try:
                NACL::STask::VolumeClone.create(**{'command_interface' :self.Node_obj,'flexclone': "clone_vol_name",
                                                       'vserver' : self.data_vserver,
                                                        'parent-volume' :self.vol_name,
                                                        'nacltask_if_exists' : 'reuse',
                                                        '_was_created ' : \was_created})
            except  Exceptions as e:
                self.log.info("Exception {}".format(e))
            except Exceptions as e:
                self.log.info("Exception {}".format(e))
            except Exception as e:
                self.log.info("Exception {}".format(e))
                Log.warn("Caught exception of type: "+ref(excpn_obj)+"\nException text: "
                        +excpn_obj.text())
            if (not was_created):
                self.Log.comment("Perform Clone split and recrete clone_" +vol_name)
                ## Check if this is clone vol
                try:
                    input_args= {'command_interface' : self.Node_obj,
                                 'filter' :{'flexclone' :"clone_vol_name",
                                 'vserver' : data_vserver}}
                    self.vol_clone_state= VolumeClone.fetch({**input_args})
                except Exception as e:
                     self.log.info("Exception {}".format(e))

                create_vol = 0
                if not (vol_clone_state):
                    ## Purge vol if it is not clone vol
                    try:
                        NACL::STask::Volume.purge(**{'command_interface' :self.Node_obj,
                                                                              'vserver' : self.data_vserver,
                                                                              'volume' :"clone_vol_name",
                        'nacltask_if_purged' : 'pass'})
                            create_vol=create_vol+1
                    except Exception as e:
                        self.log.info("Exception {}".format(e))
                    except Exception as e:
                        self.log.info("Exception {}".format(e))
                        Log.warn("Caught exception of type: " +ref(excpn_obj)+ "\nException text: "
                                +excpn_obj.text())
                elif(vol_clone_state.state() != 'online'):
                    self.Log.comment(
                        "Volclone state - " +vol_clone_state.state())
                    Time.sleep(120)
                else:
                    ## Clone split
                    self.Log.comment( "Volclone state - " +vol_clone_state.state())
                    try:
                        NACL::C::VolumeCloneSplit.start(**{'command_interface' :self.Node_obj,
                                                    'vserver' :self.data_vserver,
                                                    'flexclone' :"clone_vol_name",
                                                    'method-timeout' : 1200})
                    create_vol=create_vol+1
                    except Exceptions as e:
                        Time.sleep(300)
                    except Exception as e:
                        Log.warn("Caught exception of type: "+ref(excpn_obj)+"\nException text: " +excpn_obj.text())
                ## Re-create clone
                try:
                    vol_clone_obj = NACL::STask::VolumeClone.create(**{'command_interface' : self.Node_obj,
                                                                        'flexclone' :"clone_vol_name",
                                                                        'vserver' : self.data_vserver,
                                                                        'parent-volume' : self.vol_name,
                                                                        'nacltask_if_exists' :'reuse'})
                except Exception as  e:
                    Log.warn("Caught exception of type: " +ref(excpn_obj)+"\nException text: " +excpn_obj.text())
                Time.sleep(300)
                ## Delete Clone
                vol_clone_obj.purge()
                   if vol_clone_obj
            ## File Clone Create Delete
            filename = "lrse_in_stripe"
            NACL::STask::VolumeFile.create(**{
                'command_interface'  : self.Node_obj,
               'path'  : "/vol/vol_name/filename",
                'vserver'  : self.data_vserver,
                'filecount' :1,
                'size'  :"20g",
                'nacltask_enable_space_reserve' : 0,
                'nacltask_wait  : 0,
                nacltask_fill_holes :1,
                nacltask_to_cleanup : 0})
           ## Initiate multiple clones of same source file
            src_path = filename
            dst_path = filename + "_" + time()
            for i in range(i < 20):
                NACL::STask::VolumeFileClone.create(**{
                    command_interface :self.Node_obj,
                    volume  : self.vol_name,
                    vserver  : self.data_vserver,
                    "source-path" : self.src_path,
                    "destination-path" : self.dst_path,
                    nacltask_wait: 1})
               full_file_path = "/vol/vol_name/dst_path"
                       ## Continue random delete and creation of clones for long duration
            NACL::STask::VolumeFile.purge(**{ command_interface : self.Node_obj,vserver : self.data_vserver,
                                                       paths :\@clone_file_arr,nacltask_wait : 1})
            #return $TCD::PASS;
            ## Lun Clone
            self.Log.comment("Creating Lun Clone ")
            input_args= {command_interface : self.Node_obj,
                          filter :{vserver : self.data_vserver,
                          volume : self.vol_name,state :'online',
                          lun :'!*cloneAutoDel*'}
            self. lun_path_cs=Lun.fetch(**{input_args})

            lun_path = random.choice(lun_path_cs).['path']##### my $lun_path = $lun_path_cs[rand(@lun_path_cs)]->{'path'}
            self.Log.comment("Lun going to be cloned - lun_path")
            Lclone_props = {}
            Lclone_props['vserver']  = self.data_vserver
            Lclone_props['autodelete']  = 'true'
            Lclone_props['source-path'] = self.lun_path
            ## Create multiple lun clones
            L_name = Lclone_props['source-path']
            RAN    = randint(time())           ######     my $RAN    = int(rand(time()));
            for i in range(i <= 43):
                Lclone_props['destination-path'] = "[L_name}sparse_cloneAutoDel_lun+i"]
                try:
                    NACL::STask::VolumeFileClone.create({'command_interface' : self.Node_obj})
                except Exception as e:
                ## Pick random lun
             input_args=({'command_interface' : self.Node_obj,
                           'filter' :{'vserver' :self.data_vserver,
                           'volume' :'online'})
             self.lun_path_cs=Lun.fetch({**input_args})




    def dedupe_compression(self):
        (vol_name, Node_obj, aggr_name,data_vserver, vol_type, vol_lang)=WaflFit::FITv2::lib::Wfitlib.get_volume_info(**{
                                                                     command_interface :self.Node_obj,
                                                                     volume            :self.vol_name,
                                                                     vserver           :self.data_vserver})
        if((Params.[TEST_DEDUPE]) and (Params.[TEST_DEDUPE])):
            for sm_ele in smobj:
                src_vol =sm_ele.source_volume
                dest_vol =sm_ele.destination_time
            for vol in volume_array:
                se_vol_cs_obj= NACL::CS::Volume.fetch(**{command_interface : self.Node_obj,
                                                    filter :{ vserver : self.data_vserver,volume :vol,
                                                                        'volume-style-extended' : 'flexvol',
                                                                        'is-constituent' : 'false'}
                                                    requested_fields : ['type', 'volume', 'vserver',],
                                                    allow_empty      : 1})
                if(se_vol_cs_obj):
                    ........
            
            
            for vol_cs_obj in se_vol_cs_obj :
            
                try:
                    self.Log.info( "Starting Dedupe & Compression tests in background, on volume "+vol_cs_obj.volume+\n)
                    
                    if ((vol_cs_obj.type()) =='RW'):
                        try:
                            NACL::STask::VolumeEfficiency.on(**{command_interface   :self.Node_obj,
                                                                               volume               : vol_cs_obj.volume,
                                                                                vserver             : self.data_vserver,
                                                                                nacltask_if_enabled :'pass',
                                                                                'method-timeout'    : self.timeout})
                        except Exception as e:
                            self.log.info("Exception is :".format(e))
                            
                            if(('sis operation is currently active or already') in excpn_obj.text()):
                                Log.warn("Dedupe on failed due to: "+excpn_obj.text())
                            
                    elif(vol_cs_obj.type() == 'DP'):
                        sm = NACL::CS::Snapmirror.fetch(**{'command_interface :self.Node_obj,
                                                                    filter :{'destination-volume' :vol_cs_obj.volume}})
                                
                        if('Snapmirrored' in sm.state):
                                    
                            if('IDLE' in sm.status):
                                       
                                try:
                                    NACL::STask::VolumeEfficiency.on(**{command_interface   :self.Node_obj,
                                                                       volume               : vol_cs_obj.volume,
                                                                        vserver             : self.data_vserver,
                                                                        nacltask_if_enabled :'pass',
                                                                       'method-timeout'    : self.timeout})
                                except Exception as e:
                                    self.log.info("Exception is :".format(e))
                                    if(('sis operation is currently active or already') in excpn_obj.text()):
                                        Log.warn("Dedupe on failed due to: "+excpn_obj.text())
                            
                            elif('Transferring' in sm.status):
                                Test.warning("Cound not enable Dedupe on LockVault destination as relationship status is Transferring, Waiting until $timeout seconds for transfer to complete")
                                end_time = timeout
                                do():
                                    time.sleep(100)
                                    end_time=end_time-100
                                    
                                    while(('Transferring' in sm.status) and end_time):
                                if('IDLE' in sm.status):
                                       
                                    try:
                                        NACL::STask::VolumeEfficiency.on(**{command_interface   :self.Node_obj,
                                                                           volume               : vol_cs_obj.volume,
                                                                            vserver             : self.data_vserver,
                                                                            nacltask_if_enabled :'pass',
                                                                           'method-timeout'    : self.timeout})
                                    except Exception as e:
                                        self.log.info("Exception is :".format(e))
                                        if(('sis operation is currently active or already') in excpn_obj.text()):
                                            Log.warn("Dedupe on failed due to: "+excpn_obj.text())
                                else:
                                    Test.error("Could not enable Dedupe on LockVault Destination,as status remains Trnasferring even after $timeout seconds \n")
                        else:
                            Test.error("Enabling Dedupe failed as " + vol_cs_obj.volume + " is not in Snapmirrored state\n")
                except Exception as e:
                    self.log.info("Exception is :".format(e))
                    Log.warn("excpn - " + excpn_obj.text())
                
                
                try:
                    if(vol_cs_obj.type() == 'RW'):
                        input_args={
                            command_interface    : self.Node_obj,
                            volume               : self.(vol_cs_obj.volume),
                            vserver              : self.data_vserver,
                            compression          : 'true',
                            'inline-compression' : 'true',
                            'method-timeout'     :  self.timeout})
                        volumeEfficiency.config(**input_agrs)
                    else(vol_cs_obj.type() == 'DP'):
                        input_args={
                            command_interface    : self.Node_obj,
                            volume               : self.(vol_cs_obj.volume),
                            vserver              : self.data_vserver,
                            compression          : 'true',
                            'inline-compression' : 'true',
                            'method-timeout'     :  self.timeout})
                        volumeEfficiency.config(**input_agrs)
                except Exception as e:
                    self.log.info("Exception is :".format(e))
                    Log.warn("excpn - " + excpn_obj.text())  
            t_o_f    =[True False]
            qos      =('background', 'best-effort')
            se_props ={}
            cnt      =50
            
            while(cnt):
                for vol_cs_obj in se_vol_cs_obj:
                    se_props={}
                    se_props['volume']=vol_cs_obj.volume
                    se_props['scan-old-data']='true'
                    se_props['compression'] = t_o_f[random.randint(qos)]
                    se_props['dedupe']='true'
                    se_props['qos-policy'] =qos[rndom.randint(qos)]
                    se_props['build-metadata']=t_o_f[randam.randint(t_o_f)]
                    se_props['scan-all'] = t_o_f[random.randint(t_o_f)]
                    
                    if(randint(time()) % 2):
                         se_props['use-checkpoint'] ='true'
                    else:
                        se_props['delect-checkpoint'] ='true'
                        
                    try:
                        if(vol_cs_obj.type() =='RW'):
                            NACL::STask::VolumeEfficiency.start
                            input_args{
                                    command_interface :self.Node_obj,
                                    volume            :self.(vol_cs_obj.volume),
                                    'vserver'         :self.(vol_cs_obj.vserver),
                                    'method-timeout'  : self.timeout,
                                    nacltask_wait     : 0}
                            volumeEfficiency(**input_args)
                    except Exception as e:
                        if not( (currently active or currently pending) in excpn_obj.text()):
                            Log.warn("Caught exception: " + excpn_obj.text())
                cn=cn-1
                time.sleep(300)
        time.sleep(300)
        return True
     
    ##end sub dedupe_compression

    def lrsedr_related_test(self):
        self.Log.info("Lrse DR test begins")
        #(vol_name,Node_obj,aggr_name,data_vserver,vol_type,vol_lang)= WaflFit::FITv2::lib::Wfitlib.get_volume_info(**
        input_args={ command_interface :self.Node_obj,
                    volume            :self.lrseDR[0].source_volume(),
                    vserver           :self.lrseDR[0].source_vserver()}
         WaflFit::FITv2::lib::Wfitlib.get_volume_info(**input_agrs)
                                                                        
        for lrseDR in lrseDR :
            source_path =lrseDR.source_path
            self.Log.info("printing::::source_path ")
            destination_path =lrseDR.destination_path
            self.Log.info("Update snapmirror relation...")
            try:
                #NACL::C::Snapmirror.update
                input_args={command_interface  : self.Node_obj,
                                              'source_path'      : self.source_path,
                                              'destination_path' : destination_path}
                Snapmirror.update(**input_args)
                time.sleep(30)
            except Exception as e:
                self.log.info("Exception is :".format(e))
            self.Log.info("Break the sm relation")
            
            try:
                input_args={command_interface  : self.Node_obj,
                                              'source_path'      : self.source_path,
                                              'destination_path' : destination_path}
                Snapmirror.break(**input_args)
                time.sleep(30)
            except Exception as e:
                self.log.info("Exception is :".format(e))
            self.Log.info("Delete the sm relation")
            
            try:
                #NACL::C::Snapmirror.delete(
                input_agrs={command_interface : self.Node_obj,
                          'destination_vserver' : self.data_vserver
                          'destination-volume'  :lrseDR.destination-volume
                          'source_vserver'      :self.data_vserver
                          'source_volume'       :lrseDR.source_volume}
                Snapmirror.delete(**input)
                time.sleep(30)
            except Exception as e:
                self.log.info("Exception is :".format(e))
        for lrseDR_obj in lrseDR_obj:
            dest_vol =lrseDR_obj.destination_volume
            #dest_vol=NACL::CS::Volume.fetch(**
            input_args={command_interface : self.Node_obj
                        allow_empty      : 1
                        filter           :{volume :dest_vol,
                                           type :'RW'
                                           'volume-style-extended':'flexvol'
                                           'is-constituent' :'false'}}
            volume.fetch(**input_agrs)
            if(dest_vol):
                dest_vol.append(dest_vol)
        vol_file_lun_clone_ops(dest_vol)
        nooffiles =["1", "10", "50", "100", "150", "200", "500"]
        nooffiles= random.choice(nooffiles)
        
        if(Params.['SHARED_OBJECTS'] and (Params.['SHARED_OBJECTS'])):
            temp=shared_vols[random.choice(shared_vols_].split('#')
            #(dest_volume, dest_volnode_obj, dest_volaggr,dest_vserver,dest_voltype, dest_vollang)=WaflFit::FITv2::lib::Wfitlib.get_volume_info(**{
            input_args={ command_interface : self.Node_obj,
                         volume            : self.temp[0],
                         vserver           : self.temp[1]}
            wfitlib.get_volume_info(**input_agrs)
                         
            self.Log.info(" Using shared volume dest_volume ")
            
            
        elif:
            #(dest_volume, dest_volnode_obj, dest_volaggr,dest_vserver,dest_voltype, dest_vollang)=WaflFit::FITv2::lib::Wfitlib.get_volume_random(**{
            input_agrs={command_interface : self.Node_obj,
                       volinfo             : self.vol_info}
            wfitlib.get_volume_random(**input_agrs)
            self.Log.info(" Using shared volume dest_volume ")
        if not dest_volume:
            return 
        self.Log.info("destination volume chosen is dest_volume")
        while(if not source_volume):
            for destn_vol in dest_vol:
                source_volume = destn_vol.volume
                break if(source_volume)
            
            index =len(dest_vol)
            source_volume=dest_vol[random.choice(index)].volume()
            ----------------
        #(source_volume, source_volnode_obj, source_volaggr,
            #source_vserver, source_voltype,source_vollang)
                    # = WaflFit::FITv2::lib::Wfitlib.get_volume_info(**{
        input_agrs={ command_interface : self.Node_obj
                    volume            : source_volume}
        Wfitlib.get_volume_info(**input_agrs)
        
        source_node =source_volnode_obj.node()
        self.Log.info("source volume chosen is source_volume")
        self.Log.info("source node - $source_node & vserver - $source_vserver")
        sioffiles=["5k", "10k", "100k", "64m"]
        sioffiles=random.choice(sioffiles)
        #files = WaflFit::FITv2::lib::WfitOndemandops.createfilesod(**{
        
        input_agrs={command_interface : self.source_volnode_obj,
                Node              : self.source_node,
                Size              : self.sioffile,
                Vserver           : self.source_vserver,
                Volume            : self.source_volume,
                Nooffiles         : self.nooffile}
        rfiles=WfitOndemandops.createfilesod(**input_agrs)
        if not rfiles
            return True
        src_volnode  = source_volnode_obj.node()
        
        dest_volnode = dest_volnode_obj.node()
        
        source_volume = "source_volume:source_vserver" + ":src_volnode:source_volaggr:$source_vollang"
        
        dest_volume ="dest_volume:dest_vserver" + "dest_volnode:dest_volaggr:dest_vollang"
        
        #aflFit::FITv2::lib::WfitOndemandops.ondemandoperation(*
        input_agrs={command_interface : self.dest_volnode_obj,
                    Node            : self.dest_volnode,
                    Files           : self.rfiles,
                    Operation       :"copy",
                    Source          : self.source_volume,
                    Destination     : self.dest_volume}
        WfitOndemandops.ondemandoperation(**input_agrs)
        return True
        time.sleep(900)
        for lrseDR_obj in lrseDR_obj :
            self.Log.info("resync snapmirror relation...")
            lrseDR_obj.resync()
        time.sleep(300)
        return True
        
        
    def sis_ops_vol_move_sm_check(self):
        
        (vol_name, Node_obj, aggr_name,data_vserver)==WaflFit::FITv2::lib::Wfitlib.get_volume_info(**{
                                                                     command_interface :self.Node_obj,
                                                                     volume            :self.vol_name,
                                                                     vserver           :self.data_vserver})
        se_opts={}
        app_io_size =["default","8K","16K","32K"]
        compression_type =["none","secondary","adaptive"]
        
        for sm_ele in smobj :
            src_vol  =sm_ele.source_volume
            dest_vol = sm_ele.destination-volume
            
        for vol in volume_array:
            #e_vol_cs_obj = NACL::CS::Volume.fetch(**
            input_agrs={command_interface : self.Node_obj,
                        filter :{ vserver : self.data_vserver,volume :vol,
                                            'volume-style-extended' : 'flexvol',
                                            'is-constituent' : 'false'}
                        requested_fields : ['type', 'volume', 'vserver',],
                        allow_empty      : 1}
            e_vol_cs_obj=volume.fetch(**input_agrs)
            if(se_vol_cs_obj):
                --------------------
        for vol_cs_obj in se_vol_cs_obj :
            se_opts['compression-type]  =compression_type[random.choice(compression_type)]
            se_opts[compression] ='true'
            
            if(se_opts['compression-type'] =='adaptive'):
                se_opts[application-io-size] =app_io_size[random.choice(app_io_size)]
            
           #WaflFit::FITv2::lib::Wfitlib.vol_efficiency_modify(**
                input_agrs= {command_interface  : self.Node_obj,
                                volume              : self.vol_cs_obj.volume,
                                vserver             : self.data_vserver}
            wfitlib.vol_efficiency_modify(**input_agrs)
                                
                                #	'compression-type'  : self.se_opts['compression-type'],
                                #'compression'		: self.se_opts['compression'],
                                #'application-io-size' : self.se_opts['application-io-size'] if defined se_opts['application-io-size']})
            try:
                #ACL::STask::VolumeEfficiency.on(**
                                    input_agrs= {command_interface   :self.Node_obj,
                                                   volume               : vol_cs_obj.volume,
                                                    vserver             : self.data_vserver,
                                                    nacltask_if_enabled :'pass',
                                                    'method-timeout'    : self.timeout}
                volumeEfficiency.on(**input_agrs)
            except Exception as e:
                self.Log.info("Doing a snapmirror update")
            try:
                #ACL::STask::Snapmirror.update(**
                        input_agrs={command_interface : self.Node_obj,
                                                   'source_path'     : vol_cs_obj.source_path
                                                   'destination_path':vol_cs_obj.destination_path})
                Snapmirror.update(**input_agrs)
            except Exception as e:
                time.sleep(5)
                
            Nacl_obj = None
            Nacl_obj =NACL::CS::Volume.fetch(**{command_interface : self.Node_obj
                                                allow_empty      : 1
                                                filter           :{'volume-style-extended':'flexvol'
                                                                   'is-constituent' :'false'}})
            
            if(dest_vol[0].aggregate in Nacl_obj.aggregate):
                try:
                    volume= NACL::STask::VolumeMove.start(**{command_interface : self.Node_obj,
                                                            'volume'           :Nacl_obj.volume
                                                            vserver            : data_vserver
                                                            'destination_aggregate':dest_vol[0].aggregate})
                except Exception as e:
                    time.sleep(5)
        
        for smobject in lrseDR :
            Arrayrray= {}
            vol  = smobject.destination_volume
            Array = NACL::CS::VolumeSnapshot.fetch(**{command_interface : self.Node_obj
                                                       filter :{volume : self.vol,vserver : self.data_vserver}
            Nacl_obj=None
            try:
                Nacl_obj = NACL::STask::Snapmirror.check(**{command_interface : self.Node_obj,
                                                            'source_path'     :smobject.source_path,
                                                            'destination-path' : smobject.destination_path,
                                                            'target-snapshot'  : 'Array[len(Array)].[snapshot]
                                                            'method-timeout'   :'2800'})
            except Exception as e:
        time.sleep(300)
        return True
        
        
        
    def start_IO_paralell_process():
        (vol_name,Node_obj,agrr_name,data_vserver)=WaflFit::FITv2::lib::Wfitlib.get_volume_info(**{
                                                                     command_interface :self.Node_obj,
                                                                     volume            :self.vol_name,
                                                                     vserver           :self.data_vserver})
        try:
           #file_objs= NACL::C::VolumeDirectory.find_files(**
                   input_agrs={command_interface : self.Node_obj,
                                                                path :"/vol/vol_name",
                                                                vserver : self. data_vserver,
                                                                allow_empty :0}
            Array={}
            for file_name in file_objs:
                -----------------------
            for file_r in Array :
                if('100M_file_{vol_name}_[1-5]' in file_r):
                    self.Log.info("file selected is $file_r \n")
                    file_in_use =file_r
                    break
            (cc,mpt) = WaflFit::FITv2::lib::Wfitlib.nfs_mount_reuse(**{command_interface : self.Node_obj,
                                                                       volinfo :vol_info,
                                                                       volume   : vol_name
                                                                       vserver  : data_vserver})
            return True if not cc
            mpt=mpt +"/" +file_in_use
            nclient =cc.client()
            self.Log.info("Mount point is mpt")
            try:
                traffic_obj = NACL::MTask::Traffic.start(**{command_interface : cc
                                                            path              :mpt
                                                            tool              : 'sio',
                                                            read              : '50',
                                                            rand              : '50',
                                                            block_size        : '64k',
                                                            start_byte        : 0,
                                                            'file_size'       : '99m',
                                                            num_of_threads    : 5,
                                                            duration_in_secs  : 1000})
            except Exception as e:
                self.log.info("Exception is :".format(e))
                Log.warn("EXCEPTION :" + exception.text())
            self.Log.info("Creating FH reserved clones \n")
            for i in range(k <=10):
            `   self.Log.info("Create stream of file file_in_use\n")
                try:
                    NACL::STask::VolumeFile.create(**{command_interface : self.Node_obj
                                                       'overwrite-destination' :'true'})
                except Exception as e :
                    Log.warn("EXCEPTION :" + exception.text())
            try:
                traffic_obj.stop()
            except Exception as e:
                self.Log.warn("EXCEPTION :" + exception.text())
        time.sleep(300)
        return True
       
                                 
                                                            
            
                