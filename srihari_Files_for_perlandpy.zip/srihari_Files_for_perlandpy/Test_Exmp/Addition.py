def add(a,b):
    print("the value is ",a+b)
def mul(a,b):
    print("the value is ",a*b)
