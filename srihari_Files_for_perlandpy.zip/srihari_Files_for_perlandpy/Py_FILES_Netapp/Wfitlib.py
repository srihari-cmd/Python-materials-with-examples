from pynacl.ontap.node import Node
from pynacl import log_global ,param_global
from pynacl.ontap.volume import Volume
import random
from pynacl.ontap.snaplock.snaplock import Snaplock
from pynacl.exceptions.base import NoElementsFoundException, CommandFailedException
import re
from pynacl.ontap.network.interface import NetworkInterface
from pynacl.client.mount import Mount
from pynacl.client.client import Client
import inspect
import pynacl.apiset
from pynacl.client.windows.parser.net import _net_use
import string
import os

log = log_global()
datasetloc = "/usr/software/test/noarch/R8.4x/WaflFit/FITv2"

class Volume_lib():
    def get_volume_info(self, *pkg_or_obj, **kwarg):
        self.volume = kwarg["volume"]
        self.vserver = kwarg.get("vserver")
        self.voltype = kwarg.get("voltype")
        if(pkg_or_obj):
            self.ci = pkg_or_obj.command_interface
            self.obj = self.ci
        else:
            self.objlist = Node.find()
            self.ci = self.objlist
        self.vol_filter={}
        if self.volume :self.vol_filter['volume']=self.volume
        if self.vserver :self.vol_filter['vserver']=self.vserver
        if self.voltype :self.vol_filter['voltype']=self.voltype
        self.vol_filter['state']= 'online'
        args = {
            'command_interface': self.ci,
            'filter_fields': self.vol_filter,
        }
        vol_cs_obj = Volume.fetch(**args)
        #try finding without vserver
        if not(vol_cs_obj):
            if(self.vol_filter.has_key('vserver')): del self.vol_filter['vserver']
            args = {
            'command_interface': self.ci,
            'filter_fields': self.vol_filter,
            }
            vol_cs_obj = Volume.fetch(**args)

        if(vol_cs_obj):
            self.vol_aggr = vol_cs_obj[0].aggregate
            self.volume = vol_cs_obj[0].volume
            self.volvs = vol_cs_obj[0].vserver
            self.volnode = vol_cs_obj[0].node
            self.voltype = vol_cs_obj[0].type
            self.vollang = vol_cs_obj[0].language
            self.voljunc = vol_cs_obj[0].junction_path

        self.aggrlist = vol_cs_obj[0].aggr_list
        if (self.volnode):self.volnode_obj = self.ci

        return(self.volume,self.volnode_obj,self.vol_aggr,self.volvs,self.voltype,self.vollang)


    def get_volume_random(self, *pkg_or_obj, **kwargs):
        if (pkg_or_obj): self.ci = pkg_or_obj.comand_interface
        self.ci = kwargs.get("command_interface")
        self.mref = kwargs['volinfo']
        self.vtype = kwargs.get("voltype")
        self.volumes = list(self.mref.keys())

        self.found = 0

        while not (self.found):
            self.myvol = random.choice(self.volumes)
            self.volnode = self.mref[self.myvol]['vol_node']
            self.volaggr = self.mref[self.myvol]['vol_aggr']
            self.volvs = self.mref[self.myvol]['vserver']
            if (self.mref[self.myvol]['vol_type']): self.vtype = self.mref[self.myvol]['vol_type']
            self.get_volume_info_ops = {}
            if (self.ci): get_volume_info_ops['command_interface'] = self.ci
            self.get_volume_info_ops['volume'] = self.myvol
            if (self.volvs): self.get_volume_info_ops['vserver'] = self.volvs
            try:
                self.myvol, self.volnode_obj, self.volaggr, self.volvs, self.voltype, self.vollang = self.get_volume_info(pkg_or_obj = pkg_or_obj, **(self.get_volume_info_ops))
            except Exception as e:
                log.info("Exception: {}".format(e))
            if (self.myvol):
                self.found = 1
            if (self.voltype and self.vtype and (self.voltype != self.vtype)):
                self.found = 0
        return(self.volume, self.volnode_obj, self.vol_aggr, self.volvs, self.voltype, self.vollang)

    def nfs_mount_reuse(self,*pkg_or_obj,**kwarg):
        self.node = kwarg.get('command_interface')
        self.client_obj = kwarg.get('client_interface')
        self.client = kwarg.get('client')
        self.mref = kwarg['volinfo']
        self.vol = kwarg['volume']
        self.vserver = kwarg.get('vserver')
        self.volume_style = kwarg.get('volume_style')
        self.nfs_vers = kwarg.get('nfs_vers')
        if (self.volume_style == 'flexgroup') : self.all_nfs_vers = ['3']
        else : self.all_nfs_vers = ['3'] #['3','4','4.1']
        if not(self.nfs_vers) : self.nfs_vers = random.choice(self.all_nfs_vers)
        else : log.info("NFS MOUNT REUSE : NFS VERS provided is {}".format(self.nfs_vers))
        log.info("NFS MOUNT REUSE : Mounting vol {0} - volume style $volume_style - nfs vers {1}".format(self.vol,self.nfs_vers))
        self.filterd = {}
        self.filterd['volume'] = self.vol
        if (self.vserver) :self.filterd['vserver'] = self.vserver
        # try to mount volume if needed
        retry_count = 5
        jpath = '-'

        while(jpath == '-'):
            #if not self.node:
            self.node = Node.find()
            args = {
                       'command_interface': self.node,
                       'filter_fields': self.filterd,
                     }
            vol_cs_obj = Volume.fetch(**args)
            jpath = vol_cs_obj[0].junction_path

            if ((jpath != '-') or (not(retry_count))):
                break
            try:
                retry_count -= 1
                vol_cs_obj.get_component_instance.mount(junction_path = self.vol)
            except Exception as e:
                log.info("Exception: {}".format(e))

        if (vol_cs_obj[0].state == 'online' and vol_cs_obj[0].junction_path == '-'):
            return ( None,None)
        if (filter(lambda x: re.search(self.vol,x),list(self.mref.keys())) and self.mref[self.vol]['nfs_lifs']):
            self.lifs = self.mref[self.vol]['nfs_lifs']
        elif (self.node):
                #comment "volume is not a shared volume"
            if (vol_cs_obj):
                args = {
                               'command_interface': self.node,
                               'filter_fields': {
                                                 'vserver': vol_cs_obj[0].vserver,
                                                 'data-protocol': 'nfs',
                                                 'status-oper': 'up',
                                                 'status-admin': 'up',
                                                 'address-family': 'ipv4'
                                                }
                    }
                self.lifs = []
                net_cs_obj = NetworkInterface.fetch(**args)
                for obj in net_cs_obj:
                    self.lifs.append(obj.address)
        if not(self.lifs):
            return (None ,None)
        client_list = []
        if(self.client_obj):
            client_list = [self.client_obj[0].name]
        elif(self.client): client_list = self.client
        elif(filter(lambda x: re.search(self.vol,x),list(self.mref.keys()))):
            if (self.mref[self.vol] and self.mref[self.vol]['linux_clients']):
                client_list = self.mref[self.vol]['linux_clients']
            else:
                for obj in self.mref.keys():
                    if not(self.mref['linux_clients']): continue
                    if (self.mref[self.vol]['linux_clients']): break
        mpt = None
        log.info("client_list {}".format(client_list))
        while (not(mpt) and self.lifs != 0):
            print("self.lifs {}".format(self.lifs))
            mlif = random.choice(self.lifs)
            self.lifs.remove(mlif)

            while (not(mpt) and len(client_list)):
                lclient = random.choice(client_list)
                client_list.remove(lclient)
                    #comment - Trying to mount on client
                    #mount options
                io_size = random.choice([32768, 65536, 131072, 262144, 524288, 1048576])
                mount_ops = {}
                mount_ops['mount_point'] = "/t/" + mlif + "/root_v" + self.nfs_vers +jpath
                mount_ops['mountopts'] = "-o vers=" + str(self.nfs_vers) +",hard,intr,noac,rsize="+ str(io_size) + ",wsize=" +str(io_size) + ",rw,exec"
                mount_ops['server'] = mlif
                mount_ops['path'] = jpath
                mount_ops['nacltask_address_family'] = 'ipv4'
                if(re.search(r':',mlif)):mount_ops['nacltask_address_family'] = 'ipv6'
                    ## get client object
                if (self.client_obj and self.client_obj[0].name == lclient):
                    cli_obj = Client.find(name=lclient)
                else:
                    cli_api = None
                    cli_obj = Client.find(name = lclient)
                    while(not(cli_api)):
                            try:
                                cli_api = cli_obj[0]._apiset(interface = 'CLI')
                            except Exception as e:
                                self.log.info("Exception:{}".format(e))
                                break
                if not(cli_obj): continue
                try:
                    mount_ops['command_interface']=cli_obj[0]
                    mpt_obj = Mount(**mount_ops)
                    mpt_obj.create(**mount_ops)

                    if (mpt_obj):
                        mpt = mpt_obj.mount_point
                        jpath = vol_cs_obj[0].junction_path
                except Exception as e:
                    log.info("Mount exception {}".format(e))

                if not(mpt): continue

                try:
                    lsout = cli_obj[0]._apiset(interface = 'CLI').execute_raw_command(command = "ls -h -l "+mpt).get_raw_output()
                    resp_hash ={}
                    resp_hash['command'] = 'ls'
                    resp_hash['processed_output'] = lsout
                    if not(lsout) or lsout == '':
                        raise CommandFailedException(message='Stale file handle')
                except Exception as e:
                    log.info("Exception: {}".format(e))
                    if (re.search(r'stale file handle',e)):
                        mpt = None
                        try:
                            mptobj = Mount({
                                    'command_interface' : cli_obj[0],
                                    'nacltask_if_exists' : 'purge',
                                    'nacltask_verify' : 1,
                                })
                            mpt = mptobj.create({
                                    'command_interface' : cli_obj[0],
                                    'nacltask_if_exists' : 'purge',
                                    'nacltask_verify' : 1,
                                }).mount_point
                            if (mpt): mpt = mpt + vol_cs_obj[0].junction_path
                        except Exception as e:
                            log.info("Exception {}".format(e))

        if (mpt):
            return(cli_obj,mpt)
        else:
            return (None ,None)

    def protocol_circuit_loop_error(self,*pkg_or_obj,**kwarg):
        client_obj = kwarg['client_interface']
        wclient = client_obj.client
        out = 'ABC'
        eval(out = client_obj.apiset(interface = 'CLI').execute_raw_command(command = 'echo _HEALTHY_'))
        if (re.search('\b_HEALTHY_\b',out,re.IGNORECASE)): return None
        elif(re.search('(No route to host|unable to create process )',out,re.I)):
            c = Client()
            c.reboot()
            return True

    def get_junction_path(self, *pkg_or_obj, **kwarg):
        self.ci = kwarg.get("command_interface")
        self.volinfo = kwarg["volinfo"]
        self.type = kwarg.get("type",'unix')
        self.volume = kwarg["volume"]
        self.vserver = kwarg.get("vserver")

        if (pkg_or_obj):
            self.node = pkg_or_obj.command_interface
            self.obj = self.node
        if 'command_interface' in kwarg:self.node= kwarg['command_interface']
        self.mref = kwarg["volinfo"]
        self.type = kwarg["type"]
        self.volume = kwarg["volume"]
        if (self.vserver): self.vserver = kwarg["vserver"]
        self.volumes = self.mref.keys()
        if not (re.match(r'\bunix\b', self.type) or re.match(r'\bwindows\b', self.type)):
            return None
        self.jpath = '';
        if (filter(lambda x: re.search(self.volume, x), list(self.mref.keys()))):
            self.jpath = self.mref[self.volume]['junction-path']
        else:
            filter1 = {}
            filter1[self.volume] = self.volume
            filter1[self.vserver] = '*'
            if self.vserver: filter1[self.vserver] = self.vserver

            kwargs = {'command_interface': self.node,
                      'filter_fields': filter1,
                      }
            self.jpath = (Volume.fetch(**kwargs))[0].junction_path
        return self.jpath


    def ensure_file_exist(self, *pkg_or_obj, **kwarg):
        self.mref = kwarg["volinfo"]
        self.filee = kwarg["file"]
        self.volume = kwarg["volume"]
        self.test_location = kwarg["test_location"]
        self.vserver = kwarg.get("vserver")
        self.mount_path = kwarg.get("mount_path")
        if (pkg_or_obj):
            self.node = pkg_or_obj.command_interface
        if 'command_interface' in kwarg:
            self.node = kwarg['command_interface']
        if 'client_interface' in kwarg:
            self.client = kwarg["client_interface"]
        self.mref = kwarg["volinfo"]
        self.vol = kwarg["volume"]
        if 'vserver' in kwarg: self.vserver = kwarg["vserver"]
        if 'test_location' in kwarg: self.test_loc = kwarg["test_location"]
        if 'mount_path' in kwarg: self.mptp = kwarg["mount_path"]
        self.volumes = self.mref.keys()
        log.info("ENSURE FILE EXISTS : File is {}".format(self.filee))

        if self.mptp:
            self.nclient, self.mpt = self.client, self.mptp
            # check client
            self.mptp = None
            if (pkg_or_obj): self.protocol_cricuit_loop_error(client_interface = self.nclient)
        if not (self.mptp):
            args = {
                'command_interface': self.node,
                'client_interface': self.client,
                'volinfo': self.mref,
                'volume': self.vol,
                }
            # Mount the volume
            self.nclient,self.mpt = self.nfs_mount_reuse(**args)
        if not self.nclient or self.nclient == '':
            return False
        if not self.mpt or self.mpt == '/':
            return False

        found_file = 0
        try:
            self.out = self.nclient[0]._apiset(interface = 'CLI').execute_raw_command(command= "ls -h -l "+self.mpt + "/dataset/" + self.filee).get_raw_output()
            c = re.search(r'No such file',self.out,re.I)
            print(c)
            if ((self.out)  or self.out != '') and not(re.search(r'No such file',self.out,re.I)):
                found_file +=1
        except Exception as e:
            log.info("ENSURE FILE EXISTS : Failed to execute ls command . Error {}".format(e))
            # check if file is same as dataset file
        log.info("ENSURE FILE EXISTS : FILE {0} - found {1}".format(self.filee,found_file))
        if found_file:
            self.oout = self.nclient[0]._apiset(interface='CLI').execute_raw_command(command = "wc -c "+datasetloc + "/Tools/dataset/" + self.filee).get_raw_output()
            grpobj = re.match('(\d+) (\S+)', self.oout)
            if grpobj:
                self.org_file_byte_count = grpobj.group(1)
            self.nout = self.nclient[0]._apiset(interface='CLI').execute_raw_command(command = "wc -c "+ self.mpt + "/dataset/" + self.filee).get_raw_output()
            grpobj = re.match( '(\d+) (\S+)',self.nout)
            self.test_file_byte_count = None
            if grpobj:
                self.test_file_byte_count = grpobj.group(1)
            # both diff size copy the file again
            if not (self.test_file_byte_count == self.org_file_byte_count):
                found_file = 0
        else:
            # delete any existing file
            try:
                apiset = self.nclient[0]._apiset(interface="CLI")
                apiset.execute_raw_command(command="rm " + self.mpt + "/dataset/" + self.filee)
            except Exception as e:
                #log.info("Exception {}".format(e))
                log.info("ENSURE FILE EXISTS : Failed to execute delete dir . Error {}".format(e))
                # try create dir
            try:
                dirname = os.path.dirname(self.mpt + "/dataset/" + self.filee)
                apiset = self.nclient[0]._apiset(interface="CLI")
                apiset.execute_raw_command(command="mkdir " +dirname)
                apiset.execute_raw_command(command="chmod 777 " +dirname)
            except Exception as e:
                #log.info("Exception {}".format(e))
                log.info("ENSURE FILE EXISTS : Failed to execute create dir . Error {}".format(e))
            # sparese file check
            self.sparse = 0
            self.fsize = None
            try:
                filename = datasetloc + "/Tools/dataset/" + self.filee
                self.slist = self.nclient[0]._apiset(interface= 'CLI').execute_raw_command(command = "stat "+filename).get_raw_output()
                '''
                for elem in self.slist:
                    for key in elem.keys():
                        if elem[key]['size']:
                            self.fsize = elem[key]['Size']
                            self.blocks = elem[key]['Blocks']
                        if self.fsize:break
                    if self.fsize:break
                '''
                matobj = re.search('Size: (\d+)\s*Blocks: (\d+)',self.slist)
                if matobj:
                    self.fsize = matobj.group(1)
                    self.blocks = matobj.group(2)
                if(self.fsize and not(self.blocks)):
                    log.info("##### {} is a sparse file ####".format(self.filee))
                    self.sparse = 1
                log.info("ENSURE FILE EXISTS : Scrub - fsize {0} - sparse {1}".format(self.fsize,self.sparse))

            except Exception as e:
                log.info("Exception {}".format(e))

            log.info("ENSURE FILE EXISTS : FILE {0} - fsize {1} - sparse {2}".format(self.filee,self.fsize,self.sparse))

            if(self.fsize and self.sparse):
                self.blocks = v.convert_to_blocks(size = self.fsize)
                try:
                    dirname = os.path.dirname(self.mpt+"/dataset/"+self.filee)
                    self.nclient[0].execute(command = "mkdir "+dirname)
                    apiset.execute_raw_command(command="chmod 777 " + dirname)

                except Exception as e:
                    log.info("ENSURE FILE EXISTS : Failed to execute dirname command . Error {}".format(e))
                    #log.info("Exception {}".format(e))
                log.info("#### Creating sparse of blocks")
                try:
                    self.nclient[0]._apiset(interface ='CLI').dd({
                        'input-file'  : '/dev/zero',
                        'output-file' : self.mpt+"/dataset/"+self.filee,
                        'skipped-output-blocks-count' : self.blocks,
                        'bytes-rate' : 4096, 'block-count' : 1
                    })
                except Exception as e:
                    log.info("Exception {}".format(e))
            elif(self.fsize):
                try:
                    self.nclient[0]._apiset(interface = 'CLI').execute_raw_command(command ="cp -f "+datasetloc+"/Tools/dataset/"+self.filee+" "+self.mpt+"/dataset/"+self.filee )
                except Exception as e:
                    log.info("ENSURE FILE EXISTS : Failed to execute cp . Error {}".format(e))
                    #log.info("Exception {}".format(e))
            try:
                chmode =self.nclient[0]._apiset(interface = 'CLI').execute_raw_command(command="chmod 777 "+self.mpt+"/dataset/"+self.filee)
                found_file = 1
            except Exception as e:
                log.info("ENSURE FILE EXISTS : Failed to execute chmod . Error {}".format(e))
                #log.info("Exception {}".format(e))
        return found_file

    @staticmethod
    def generate_random_string(num):
        chars = []
        chars.extend(list(string.ascii_letters))
        chars.extend(list(string.digits))
        chars.append('_')
        random_string = ''
        for _ in range(num):
            random_string += random.choice(chars)
        return random_string

    def get_data_vserver(self,*pkg_or_obj,**kwarg):
        if(pkg_or_obj):node = pkg_or_obj.command_interface
        node = kwarg.get('command_interface')
        mref = kwarg['volinfo']
        volume = kwarg['volume']
        vserver = kwarg.get('vserver')
        volumes = mref.keys()
       # if (filter(lambda x: re.match(volume, x), list(mref.keys()))):
        if volume in list(mref.keys()):
            return mref[volume]['vserver']
        else:
            log.info("get_data_vserver() volume: {} not found".format(volume))
            filterd = {}
            filterd['volume'] = volume
            if vserver: filterd['vserver'] = vserver
            vol_cs_obj = Volume.fetch(**{
                'command_interface' : node,
                'filter_fields' : filterd,
            })
            if vol_cs_obj:
                return vol_cs_obj[0].vserver
            else:
                return

    def cifs_share_reuse(self, *pkg_or_obj, **kwarg):
        self.volinfo = kwarg["volinfo"]
        self.volume = kwarg["volume"]
        self.vserver = kwarg.get("vserver")
        self.client = kwarg.get("client")
        self.lif = kwarg.get("lif")
        self.client_interface = kwarg.get("client_interface")

        if (pkg_or_obj):
            self.node = pkg_or_obj.command_interface
        if 'command_interface' in kwarg:
            self.node = kwarg['command_interface']
        if (self.client_interface): self.clientobj = kwarg["client_interface"]
        else: self.clientobj = None
        if (self.client): self.client = kwarg["client"]
        self.sref = kwarg["volinfo"]
        self.vol_name = kwarg["volume"]
        if (self.lif): self.lif = kwarg["lif"]
        if (self.clientobj):
            self.cifs_clients = self.clientobj.client
        elif(self.client):
            self.cifs_clients = self.client
        elif(filter(lambda x: re.search(self.vol,x),list(self.sref.keys()))):
            if self.sref[self.vol_name] and self.sref[self.vol_name]["windows_clients"]:
                self.cifs_clients = self.sref[self.vol_name]['windows_clients']
                self.cifs_cred = self.sref[self.vol_name]['cifs']
            else:
                for vol in self.sref.keys():
                    if not self.sref[vol]: continue
                    self.cifs_clients = self.sref[vol]['windows_clients']
                    if self.sref[vol]['windows_clients']:
                        self.cifs_cred = self.cred[vol_name]['cifs']
                    if self.sref[vol]['cifs']:
                        log.debug("cifs_clients - {}".format(self.cifs_clients))
                        log.debug("cifs_credentials -{} ".format(self.cifs_cred))
                    if self.cifs_clients: break
        log.info("cifs_clients - {}".format(self.cifs_clients))
        log.info("cifs_credentials -{} ".format(self.cifs_cred))
        ##CIFS domain user info
        if (self.cifs_cred):
            self.domain = self.cifs_cred[0].split('.')
            self.dname = self.domain[0]
            self.duser = self.cifs_cred[1]
            self.dpasswd = self.cifs_cred[2]
        else:
            self.dname = 'gd1'
            self.duser = 'fit_admin'
            self.dpasswd = 'netapp1!'
        # select random client
        self.mount_point =None
        iter1 = 0
        chklp = 0
        cifs_len = len(self.cifs_clients)
        while (not self.mount_point) and cifs_len:
            # choose the client randomly
            self.wclient =random.choice(self.cifs_clients)
            ##get client object
            if self.clientobj: self.client_obj = self.clientobj
            else: self.client_obj = Client.find(name=self.wclient)
            log.info("self.client {}".format(self.client_obj))
            ##check client health
            ##Get client shares
            self.res = None
            try:
                self.res = self.client_obj[0]._apiset(interface='CLI').execute_raw_command(command='net use').get_parsed_output()
                self.res1 = self.client_obj[0]._apiset(interface='CLI').execute_raw_command(command='net use')
                parsed_output = self.res1.get_parsed_output()
                log.info("self.res1 {}".format(parsed_output))
            except Exception as e:
                log.info("Exception {}".format(e))
            if not self.res: continue
            cifs_len -= 1
            ##check if it is already shared
            self.mount_hash = {}
            for entry in self.res:
                self.mount_hash[entry['local']] = entry['remote']
            log.info("mount option - {}".format(self.mount_hash))
            ##Pick random cifs network lif from volinfo
            if self.sref.get(self.vol_name).get('cifs_lifs'): self.cifs_list = self.sref[self.vol_name]['cifs_lifs']
            log.info("self.cifs_list {}".format(self.cifs_list))
            if self.cifs_list:
                if self.lif:
                    self.cifs_info = filter(lambda x: re.search(self.lif,x),self.cifs_list)
                else:
                    self.cifs_info = self.cifs_list

            chklen = len(self.cifs_info)
            while (not self.mount_point) and chklen:
                for wlif in self.cifs_info:
                    fchk = 0
                    self.wlif = wlif
                    chklen = chklen -1
                    ##Get the mount point
                    self.wlif_name = self.wlif
                    l1 = self.wlif_name.split(':')
                    self.wlif_name = l1[0]+"\\\\"+l1[1]
                    self.mount_share =None
                    for mpoint in self.mount_hash.keys():
                        c1 =re.search(self.wlif_name,self.mount_hash[mpoint])
                        if (c1):
                            fchk=1
                            self.mount_point = mpoint
                            self.mount_share = self.wlif
                            break
                    if fchk: break
                if not self.mount_point: continue
            ##If not found in mount_hash
            self.mount_ip = None
            if not self.mount_share:
                if self.lif:
                    self.cifs_info = filter(lambda x: re.search(self.lif,x),self.cifs_list)
                    log.info("filtered cifs {}".format(self.cifs_info))
                else:
                    self.cifs_info = self.cifs_list
                if self.cifs_info:
                    split_ip = self.cifs_info[0].split(':',1)
                    self.mount_ip = split_ip[0]
                    self.mount_share = split_ip[1]
            if self.mount_share:
                log.info("mount_share - self.mount_share")
                self.mout = self.mount_share.split(':')
                # Trying to use same mount point
                mount_ops = {}
                if self.mount_ip:
                    mount_ops['share_name'] = self.mount_share
                    mount_ops['server'] = self.mount_ip
                elif (len(self.mout) >6) and self.mout[6]:
                    mount_ops['share_name'] = self.mout[6]
                    mount_ops['server'] = self.mout[4]
                else:
                    mount_ops['share_name'] = self.mout[1]
                    mount_ops['server'] = self.mout[0]
                if self.mount_point:
                    if self.mount_point[-1] == ':':
                        mount_ops['mount_point'] = self.mount_point[:-1]
                    else:
                        mount_ops['mount_point'] = self.mount_point
                mount_ops['user'] = self.dname + "\\" + self.duser
                mount_ops['password'] = self.dpasswd
                log.info("cifs share remount options - {}".format(mount_ops))
                if self.mount_point:
                    try:
                        self.client_obj[0]._apiset(interface='CLI').execute_raw_command(command='net use '+self.mount_point)

                    except Exception as e:
                        log.info("Exception {}".format(e))
                else:
                    try:
                        log.info("mount_ops  {}".format(mount_ops))
                        args = {
                            'command_interface': self.client_obj[0],
                            'nacltask_if_exists': 'reuse',
                             }
                        args.update(mount_ops)
                        mptobj1 = Mount(**args)
                        self.mount_point = mptobj1.create(**args).mount_point
                        log.info("self.mount_point {}".format(self.mount_point))
                    except Exception as e:
                        log.info("Exception {}".format(e))
        if self.mount_point: return (self.client_obj, self.mount_point)
        return (None, None)

    def path_to_file_name(self,*pkg_or_obj,**kwarg):
        if pkg_or_obj:
            self.node = pkg_or_obj.command_interface
        if 'command_interface' in kwarg:
            self.node = kwarg['command_interface']
        self.path = kwarg['file']
        t = self.path.split('/')

        return t[len(t)-1]

    def convert_to_blocks(self,*pkg_or_obj,**kwarg):

        size = kwarg['size']
        if not size: return -1
        ck = re.search(r'^(.*)[kK][bB]{0,1}$',size)
        cm = re.search(r'^(.*)[mM][bB]{0,1}$', size)
        cg = re.search(r'^(.*)[gG][bB]{0,1}$', size)
        ct = re.search(r'^(.*)[tT][bB]{0,1}$', size)
        cb = re.search(r'^(.*)[bB]{0,1}$', size)
        if ck:
            size_in_bytes = int(ck.group(1))* 1024
        elif cm:
            size_in_bytes = int(cm.group(1))* 1024 * 1024
        elif cg:
            size_in_bytes = int(cg.group(1)) * 1024 * 1024 * 1024
        elif ct:
            size_in_bytes = int(ct.group(1)) * 1024 * 1024 * 1024 * 1024
        elif ct:
            size_in_bytes = int(cb.group(1))

        return int(size_in_bytes/4096)