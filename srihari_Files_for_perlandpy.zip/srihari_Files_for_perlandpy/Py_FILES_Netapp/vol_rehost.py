from pynacl.ontap.volume import Volume
import os
from pynacl.ontap.vserver import Vserver
import random
import sys
from pynacl import log_global
import pynacl.apiset
import pytest
from pynate.process.fork import NATEProcessFork
from pynacl.ontap.node import Node


#import more libraries as required


log= log_global()
Params= param_global()
LOG_DIR = Params.get(key='TOP_LOGDIR_UNIX')


sub init() {
    $Test->description("init(): Initialize resources");
$top_global_param_file = "$ENV{'TOP_LOGDIR_UNIX'}/"  . "top_global_params"; 
    ### Initialize Options
    $Options = new Options();
    $Options->parameters(
        definitions => [
            {   name        => "SHARED_OBJECTS",
                description => "shared object info file",
                spec        => "s@",
            },
            {   name        => "VOL_INFO_FILE",
                description => "vol info file",
                spec        => "s",
            },
            {   name        => "NODES",
                description => "List of nodes",
                spec        => "s@",
            },
            {   name        => "CLUSTER_CONFIG_FILE",
                description => "Cluster configuration file",
                spec        => "s",
            },
            {   name        => "TEST_LOCATION",
                description => "Location of testdir",
                spec        => "s",
            },
            {   name        => "TIMEOUT",
                description => "Max execution time",
                spec        => "s",
            },
            {   name        => "TPARALLELISM",
                description =>
                    "How many instances of testcases I can run in parallel",
                spec        => "s",
            },
            {   name        => "CLUSTER_NAME",
                description => "Name of the cluster",
                spec        => "s",
            },
        ]
    );
    $Options->process();
if ( -f $top_global_param_file){ 
   require $top_global_param_file; 
     $Params = \%top_global_params; 
    $Log->comment( "global Params in top global - " . Dumper $Params);  
     }else{ 
         $Params = param_global->get(); 
         $Log->comment( "global Params - " . Dumper $Params);  
            } 
 
 
    ##	Initialize variables
@shared_vols =  split(/s*,s*/, $Params->{'SHARED_OBJECTS'}) if {defined $Params->{'SHARED_OBJECTS'}}; 
@nodes = split(/\s*,\s*/, $Params->{'NODES'}) if (defined $Params->{'NODES'}); 
    $cluster_name        = $Params->{'CLUSTER_NAME'};
    $cluster_config_file = $Params->{'CLUSTER_CONFIG_FILE'};
    ## Pull some files
    if (-f $cluster_config_file) {
        require "$cluster_config_file"
            or die "$cluster_config_file does not exist $!";
        require "$Params->{VOL_INFO_FILE}"
            or die "VOL_INFO_FILE not found";
    } else {
        require
            "$Params->{'TEST_LOCATION'}/Cluster/ConfigFiles/$cluster_config_file"
            or die "$cluster_config_file does not exist $!";
        require "$Params->{'TEST_LOCATION'}/lib/VolInfo_${cluster_name}.pm"
            or die "VolInfo_${cluster_name}.pm does not exist $!";
    }
    $Params->{'TIMEOUT'}
        = defined $Params->{'TIMEOUT'} ? $Params->{'TIMEOUT'} : 3600;
    $Params->{'TIMEOUT'} = &ClusterCommon::parse_time($Params->{'TIMEOUT'});
    $timeout = $Params->{'TIMEOUT'};
    return $TCD::PASS;
} ## end sub init

class Test_vol_rehost():
    @pytest.fixture(scope="class", autouse=True)
    def setup_cleanup(self, request):
        top_global_param_file = Params.get('TOP_LOGDIR_UNIX')
 
        if (Params.get('SHARED_OBJECTS')):
            self.shared_vols = Params.get('SHARED_OBJECTS').split(',')
            request.cls.shared_volumes = self.shared_vols
 
        if (Params.get('NODES')):
            self.nodes = Params.get('NODES').split(',')
 
        self.cluster_config_file = Params.get('CLUSTER_CONFIG_FILE')
        self.log.info(self.cluster_config_file)
        self.cluster_name = Params.get('CLUSTER_NAME')
        self.sisclone_prefix = Params.get('SISCLONE_VOL')
        self.log_dir = Params.get('TOP_LOGDIR_UNIX')
        self.log_dir = self.log_dir + "/TestFiles.py"
        self.vol_infom = Params.get('VOL_INFO_FILE')
        self.vol_infom = self.vol_infom[:-2] + "py"
        self.log.info("self.log.info {}".format(self.vol_infom))
        sys.path.append(os.path.dirname(self.vol_infom))
        filename = os.path.basename(self.vol_infom)
        filename = filename[:-3]
        self.log.info("filename {}".format(filename))
        self.log.info("dirname {}".format(os.path.dirname(self.vol_infom)))
        testfiles1 = Params.get('TESTFILE_INFO_PY')
        test_filename = os.path.basename(testfiles1)
        test_filename = test_filename[:-3]
        sys.path.append(os.path.dirname(testfiles1))
        self.log.info("testfiles1 {}".format(testfiles1))
        if (os.path.isfile(self.cluster_config_file)):
            try:
                mod1 = importlib.import_module((test_filename))
                request.cls.tfiles = mod1.testfiles
            except Exception as e:
                self.log.info("Exception {}".format(e))
            try:
                mod = importlib.import_module((filename))
                request.cls.vol_info = mod.vol_info
            except Exception as e:
                self.log.info("Exception {}".format(e))
        if(Params.get('SHARED_OBJECTS') and self.shared_vols):
            self.temp = random.choice(self.shared_vols).split('#')
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver,request.cls.vol_type,request.cls.vol_lang= v.get_volume_info(volume=  self.temp[0], vserver = self.temp[3])
            self.log.info("self.vol_name={0}, self.node_obj={1}, self.vol_aggr={2}, self.data_vserver={3},self.vol_type,self.vol_lang".format(request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver))
        elif(Params.get('TEST_COMMON_VOL')):
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver = v.get_volume_info(volume= Params.get('COMMON_VOL'))
        else:
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver,request.cls.vol_type,request.cls.vol_lang = v.get_volume_random(volinfo=mod.vol_info)
            self.log.info("Using random volume {}".format(self.vol_name))
        if not(self.vol_name): return
        request.cls.nfs_client_obj, request.cls.nfs_mpt = v.nfs_mount_reuse(command_interface = request.cls.node_obj, volinfo = mod.vol_info, vserver = request.cls.data_vserver, volume = request.cls.vol_name,)
        self.log.info("nfs_mount_reuse param {0}{1}".format(request.cls.nfs_client_obj,request.cls.nfs_mpt))
        request.cls.njpath = v.get_junction_path(command_interface=self.node_obj,volume =self.vol_name, type='unix', volinfo=mod.vol_info)
        self.log.info("njpath {}".format(request.cls.njpath))
        request.cls.wjpath = v.get_junction_path(command_interface=self.node_obj,volume =self.vol_name, type='windows', volinfo=mod.vol_info)
        self.log.info("wjpath {}".format(request.cls.wjpath))
        yield
        self.log.info("cleanup")
 

	def volrehost_anothervserer () {
	    $Log->comment("Randomly pick a volume for vol rehost");
	    # Pick a node object
	    my $node = $nodes[rand @nodes];
	    $Node    = NACL::STask::Node->new(node => $node);
	 
######################################################################
#CHANGE STARTS
	    $Node    = NACL::STask::Node->new(node => $node);
	 
#CHANGE ENDS
######################################################################


   my $Node_api;
	    while (!defined $Node_api) {
	        try {
	            $Node->apiset->api_reconnect_session();
	            $Node_api = 'Connected';
	        }
	        catch NATE::BaseException with {Tharn::sleep 30;};
	    }
	    ## Get vserver list...
	    my @vs_objs = NACL::CS::Vserver->fetch(
	              command_interface => $Node,
	              allow_empty       => 1,
	              filter            => {
	                  type    => 'data',
	                  deftype => 'sync-source|default',
	              },
	    );
	    ## Get all volumes...
	    my $rand_vs_obj = $vs_objs[rand @vs_objs];
	    my $rand_vs     = $rand_vs_obj->vserver();
	    my @all_vol_objs = NACL::CS::Volume->fetch(
	        command_interface => $Node,
	        allow_empty       => 1,
	        'method-timeout'  => 1200,
	        filter            => {
	            vserver => $rand_vs,
	            vsroot  => 'false',
	            type    => '!TMP',
	            state   => '!restricted',
	            'volume-style-extended' => 'flexvol',
	            'is-constituent' => 'false',
	        },
	        requested_fields  =>
	        ['junction-path', 'vserver', 'state', 'type', 'language'],
	    );
	 
######################################################################
#CHANGE STARTS
	    my @all_vol_objs = NACL::CS::Volume->fetch(
	        command_interface => $Node,
	        allow_empty       => 1,
	        'method-timeout'  => 1200,
	        filter            => {
	            vserver => $rand_vs,
	            vsroot  => 'false',
	            type    => '!TMP',
	            state   => '!restricted',
	            'volume-style-extended' => 'flexvol',
	            'is-constituent' => 'false',
	        },
	        requested_fields  =>
	        ['junction-path', 'vserver', 'state', 'type', 'language'],
	    );
	 
#CHANGE ENDS
######################################################################


   unless (@all_vol_objs) {
	        $Log->warn("Unbale to find vols");
	        Tharn::sleep 300;
	        return $TCD::CONFIG;
	    }
	    my $vol_obj = $all_vol_objs[rand @all_vol_objs];
	    $vol_name   = $vol_obj->volume();
	    ## Skip shared volumes
	    #undef $vol_name;
	    #while (!defined $vol_name) {
	    #    foreach my $vol_obj (@all_vol_objs) {
	    #        #next if grep /^$vol_obj->volume()$/, @shared_vols;
	    #        $vol_name = $vol_obj->volume();
	    #    }
	    #}
	    unless (@vs_objs || scalar(@vs_objs) < 2) {
	        $Log->warn("Not enough vserers to do rehost");
	        Tharn::sleep 300;
	        return $TCD::PASS;
	    }
	    ## Select dest vs
	    my $dest_vs_obj = $vs_objs[rand @vs_objs];
	    while ($rand_vs eq $dest_vs_obj->vserver()) {
	        $dest_vs_obj = $vs_objs[rand @vs_objs];
	    }
	    ## TODO: export policy and QoS policy
	    ## Get junction path
	    my $jpath = $vol_obj->junction_path();
	    $jpath    = "/$vol_name" if $jpath eq '-';
	    $Log->comment("jpath - $jpath");
	    ## Check if vol is snapmirror
	    my $sm_obj = NACL::CS::Snapmirror->fetch(
	            command_interface => $Node,
	            allow_empty       => 1,
	            filter            => {
	                'destination-volume'  => $vol_obj->volume(),
	                'destination-vserver' => $vol_obj->vserver(),
	            }
	    );
	 
######################################################################
#CHANGE STARTS
  ## Check if vol is snapmirror
	    my $sm_obj = NACL::CS::Snapmirror->fetch(
	            command_interface => $Node,
	            allow_empty       => 1,
	            filter            => {
	                'destination-volume'  => $vol_obj->volume(),
	                'destination-vserver' => $vol_obj->vserver(),
	            }
	    );
	 
#CHANGE ENDS
######################################################################


   return $TCD::PASS if defined $sm_obj;
	    ## Check if vol is snapmirror
	    $sm_obj = NACL::CS::Snapmirror->fetch(
	            command_interface => $Node,
	            allow_empty       => 1,
	            filter            => {
	                'source-volume'  => $vol_obj->volume(),
	                'source-vserver' => $vol_obj->vserver(),
	            }
	    );
	 
######################################################################
#CHANGE STARTS
  ## Check if vol is snapmirror
	    $sm_obj = NACL::CS::Snapmirror->fetch(
	            command_interface => $Node,
	            allow_empty       => 1,
	            filter            => {
	                'source-volume'  => $vol_obj->volume(),
	                'source-vserver' => $vol_obj->vserver(),
	            }
	    );
	 
#CHANGE ENDS
######################################################################


   return $TCD::PASS if defined $sm_obj;
	    try {
	        ## Un-mount vol and start rehost
	        $vol_obj->get_task_instance->unmount(force => 'true');
	 
######################################################################
#CHANGE STARTS
# Un-mount vol and start rehost
	        $vol_obj->get_task_instance->unmount(force => 'true');
	 
#CHANGE ENDS
######################################################################


       ## Volume rehost
	        $vol_obj->get_task_instance->rehost(
	             'destination-vserver' => $dest_vs_obj->vserver(),
	             'auto-remap-luns'     => 'true',
	             #'force-unmap-luns'    => 'true',
	             'apiset_must'         => {interface => 'CLI'},
	        );
	    }
	    catch NATE::BaseException with {};
	    ## Try online
	    try {
	        NACL::STask::Volume->online(
	            command_interface => $Node,
	            volume            => $vol_name,
	            vserver           => $dest_vs_obj->vserver(),
	        );
	 
######################################################################
#CHANGE STARTS
try {
	        NACL::STask::Volume->online(
	            command_interface => $Node,
	            volume            => $vol_name,
	            vserver           => $dest_vs_obj->vserver(),
	        );
	 
#CHANGE ENDS
######################################################################


   }
	    catch NACL::APISet::Exceptions::ResponseException with {}
	    catch NACL::APISet::Exceptions::CommandFailedException with {};
	    ## Mount back
	    try {
	        NACL::STask::Volume->mount(
	            command_interface => $Node,
	            volume            => $vol_name,
	            vserver           => $dest_vs_obj->vserver(),
	            'junction-path'   => $jpath,
	            nacltask_already_mounted => 'die',
	        );
	 
######################################################################
#CHANGE STARTS
try {
	        NACL::STask::Volume->mount(
	            command_interface => $Node,
	            volume            => $vol_name,
	            vserver           => $dest_vs_obj->vserver(),
	            'junction-path'   => $jpath,
	            nacltask_already_mounted => 'die',
	        );
	 
#CHANGE ENDS
######################################################################


   }
	    catch NACL::APISet::Exceptions::UnsupportedOptionException with {}
	    catch NATE::BaseException with {};
	    return $TCD::PASS;
	} ## 
    def test_subrunner(self):
        self.log.info("In subrunner ")
        from collections import OrderedDict
        Testcases=OrderedDict()
        Testcases['dt_io']=Testnfs_io.dt_io
        No_of_wf = len(Testcases.keys())
        i = int(self.get_param(key='ITERATION',default = 1))
        stest = self.get_param(key='SUBTEST',default = 0)
        nos = int(self.get_param(key='TPARALLELISM',default = 3))
        if(No_of_wf < nos):
            nos=No_of_wf
        timeout = self.get_param(key='TIMEOUT',default = 3600)
        if (self.get_param(key='SHARED_OBJECT')):
            volume_obj = self.get_param(key='SHARED_OBJECT').split(",")
            volume = volume_obj[0]
            self.log.info("volume from shared object is :" + volume)
        if stest == "1" :
            while(i > 0):
                for key,value in Testcases.items():
                    self.log.info("Workflow invoked :" + key)
                    proc = NATEProcessFork(target=Testcases[key],runid=key,args=[self,])
                    proc.start()
                    while (proc.is_alive):
                        time.sleep(5)
                i = i - 1
        else:
            self.log.info("Running parallel")
            ctime = time.time()
            end_time = ctime+int(timeout)
            self.log.info("end time is :" + str(end_time))
            slots=[]
            cur_threads={}
            tobedel=[]
            while(time.time() < end_time):
                test=random.choice(list(Testcases.keys()))
                while (len(slots) < nos):
                    test=random.choice(list(Testcases.keys()))
                    if test not in slots :
                        self.log.info("Workflow invoked :" + test)
                        slots.append(test)
                        proc = NATEProcessFork(target=Testcases[test],runid=test,args=[self,])
                        proc.start()
                        cur_threads[test]=proc
                tobedel=[]
                for key,thread in cur_threads.items():
                    if not cur_threads[key].is_alive:
                        slots.remove(key)
                        tobedel.append(key)
                for k in tobedel:
                    del cur_threads[k]
            for kill,val in cur_threads.items():
                self.log.info("killing :" + str(kill))
                cur_threads[kill].terminate()
 
 
 
