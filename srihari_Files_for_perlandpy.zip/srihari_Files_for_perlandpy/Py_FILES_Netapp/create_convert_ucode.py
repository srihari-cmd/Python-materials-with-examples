from pynacl.ontap.volume import Volume
import os
from pynacl.ontap.vserver import Vserver
import random
import sys
from pynacl import log_global
import pynacl.apiset
import pytest
from pynate.process.fork import NATEProcessFork
from pynacl.ontap.node import Node


#import more libraries as required


log= log_global()
Params= param_global()
LOG_DIR = Params.get(key='TOP_LOGDIR_UNIX')


sub init() {
    $Test->description("init(): Initialize resources");
    $Test->description("init(): Initialize resources");
$top_global_param_file = "$ENV{'TOP_LOGDIR_UNIX'}/"  . "top_global_params";
if ( -f $top_global_param_file){
   require $top_global_param_file;
     $Params = \%top_global_params;
    $Log->comment( "global Params in top global - " . Dumper $Params);
     }else{
         $Params = param_global->get();
         $Log->comment( "global Params - " . Dumper $Params);
            }
    ### Initialize variables
@shared_vols =  split(/s*,s*/, $Params->{'SHARED_OBJECTS'}) if {defined $Params->{'SHARED_OBJECTS'}};
    @nodes = split(/\s*,\s*/, $Params->{'NODES'})
        if defined $Params->{'NODES'};
    @clients_arr = split(/\s*,\s*/, $Params->{'NFS_CLIENTS'})
        if defined $Params->{'NFS_CLIENTS'};
    my $cluster_config_file = $Params->{'CLUSTER_CONFIG_FILE'};
    my $cluster_name        = $Params->{'CLUSTER_NAME'};
    if (-f $cluster_config_file) {
        require "$cluster_config_file"
            or die "$cluster_config_file does not exist $!";
        require "$Params->{VOL_INFO_FILE}"
            or die "VOL_INFO_FILE not found";
    } else {
        require
            "$Params->{'TEST_LOCATION'}/Cluster/ConfigFiles/$cluster_config_file"
            or die "$cluster_config_file does not exist $!";
        require "$Params->{'TEST_LOCATION'}/lib/VolInfo_${cluster_name}.pm"
            or die "VolInfo_${cluster_name}.pm does not exist $!";
    }
    $Params->{'TIMEOUT'}
        = defined $Params->{'TIMEOUT'} ? $Params->{'TIMEOUT'} : 3600;
    $Params->{'TIMEOUT'} = &ClusterCommon::parse_time($Params->{'TIMEOUT'});
    $timeout = $Params->{'TIMEOUT'};
    ## Initialize variables
    @nodes = NACL::C::Node->find();
    return $TCD::PASS;
} ## end sub init

class Test_create_convert_ucode():
    @pytest.fixture(scope="class", autouse=True)
    def setup_cleanup(self, request):
        top_global_param_file = Params.get('TOP_LOGDIR_UNIX')
 
        if (Params.get('SHARED_OBJECTS')):
            self.shared_vols = Params.get('SHARED_OBJECTS').split(',')
            request.cls.shared_volumes = self.shared_vols
 
        if (Params.get('NODES')):
            self.nodes = Params.get('NODES').split(',')
 
        self.cluster_config_file = Params.get('CLUSTER_CONFIG_FILE')
        self.log.info(self.cluster_config_file)
        self.cluster_name = Params.get('CLUSTER_NAME')
        self.sisclone_prefix = Params.get('SISCLONE_VOL')
        self.log_dir = Params.get('TOP_LOGDIR_UNIX')
        self.log_dir = self.log_dir + "/TestFiles.py"
        self.vol_infom = Params.get('VOL_INFO_FILE')
        self.vol_infom = self.vol_infom[:-2] + "py"
        self.log.info("self.log.info {}".format(self.vol_infom))
        sys.path.append(os.path.dirname(self.vol_infom))
        filename = os.path.basename(self.vol_infom)
        filename = filename[:-3]
        self.log.info("filename {}".format(filename))
        self.log.info("dirname {}".format(os.path.dirname(self.vol_infom)))
        testfiles1 = Params.get('TESTFILE_INFO_PY')
        test_filename = os.path.basename(testfiles1)
        test_filename = test_filename[:-3]
        sys.path.append(os.path.dirname(testfiles1))
        self.log.info("testfiles1 {}".format(testfiles1))
        if (os.path.isfile(self.cluster_config_file)):
            try:
                mod1 = importlib.import_module((test_filename))
                request.cls.tfiles = mod1.testfiles
            except Exception as e:
                self.log.info("Exception {}".format(e))
            try:
                mod = importlib.import_module((filename))
                request.cls.vol_info = mod.vol_info
            except Exception as e:
                self.log.info("Exception {}".format(e))
        if(Params.get('SHARED_OBJECTS') and self.shared_vols):
            self.temp = random.choice(self.shared_vols).split('#')
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver,request.cls.vol_type,request.cls.vol_lang= v.get_volume_info(volume=  self.temp[0], vserver = self.temp[3])
            self.log.info("self.vol_name={0}, self.node_obj={1}, self.vol_aggr={2}, self.data_vserver={3},self.vol_type,self.vol_lang".format(request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver))
        elif(Params.get('TEST_COMMON_VOL')):
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver = v.get_volume_info(volume= Params.get('COMMON_VOL'))
        else:
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver,request.cls.vol_type,request.cls.vol_lang = v.get_volume_random(volinfo=mod.vol_info)
            self.log.info("Using random volume {}".format(self.vol_name))
        if not(self.vol_name): return
        request.cls.nfs_client_obj, request.cls.nfs_mpt = v.nfs_mount_reuse(command_interface = request.cls.node_obj, volinfo = mod.vol_info, vserver = request.cls.data_vserver, volume = request.cls.vol_name,)
        self.log.info("nfs_mount_reuse param {0}{1}".format(request.cls.nfs_client_obj,request.cls.nfs_mpt))
        request.cls.njpath = v.get_junction_path(command_interface=self.node_obj,volume =self.vol_name, type='unix', volinfo=mod.vol_info)
        self.log.info("njpath {}".format(request.cls.njpath))
        request.cls.wjpath = v.get_junction_path(command_interface=self.node_obj,volume =self.vol_name, type='windows', volinfo=mod.vol_info)
        self.log.info("wjpath {}".format(request.cls.wjpath))
        yield
        self.log.info("cleanup")
 

	 def create_convert_Ucode {
		$Test->description("Test starts here");
		$large_name="AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB";
	    foreach my $node (@nodes) {
		 $host=host($node->node());
		 $vol_cs = NACL::CS::Volume->fetch(
	                    command_interface => $node,
	                    filter            => { 'is-mroot' => 'true' },
	                    apiset_should     => { set => 'Nodescope' },
	                    requested_fields  => [ 'root' ]
	                );
		
######################################################################
#CHANGE STARTS
;
		 $vol_cs = NACL::CS::Volume->fetch(
	                    command_interface => $node,
	                    filter            => { 'is-mroot' => 'true' },
	                    apiset_should     => { set => 'Nodescope' },
	                    requested_fields  => [ 'root' ]
	                );
		
#CHANGE ENDS
######################################################################


 $Root_Vol = $vol_cs;
		$Log->comment("Root Volume is " . $Root_Vol->volume());
		$root_vol = $Root_Vol->volume();
		$dir_name="PRandom";
		$create_dir="mkdir /vol/$root_vol/$dir_name";
		$set_covert_ucode = "vol options $root_vol convert_ucode on";
		$set_create_ucode = "vol options $root_vol create_ucode on";
		$node_scope_obj = $node->get_7m_or_nodescope_apiset();
		$node_scope_obj->execute_command(command => $set_covert_ucode);
		
######################################################################
#CHANGE STARTS
);
		$node_scope_obj->execute_command(command => $set_covert_ucode);
		
#CHANGE ENDS
######################################################################


$node_scope_obj->execute_command(command => $set_create_ucode);
		$directory_c = $node_scope_obj->execute_command(command => $create_dir);
		
######################################################################
#CHANGE STARTS
_c = $node_scope_obj->execute_command(command => $create_dir);
		
#CHANGE ENDS
######################################################################


  if($directory_c =~ /File exists/) {
		       $Log->comment("File $directory_c already exists...");
		   }
		 @dargs= ( "hostobj",   $host,
	                  "category",  "Node",
	                  "interface", "CLI",
	                  "set",       "Systemshell",
	            );
		 $SysSh_Set_Obj = NACL::APISet->new( @dargs, context_definition => {username => 'diag', password => 'netapp1!' } );
		
######################################################################
#CHANGE STARTS
;
		 $SysSh_Set_Obj = NACL::APISet->new( @dargs, context_definition => {username => 'diag', password => 'netapp1!' } );
		
#CHANGE ENDS
######################################################################


 $response = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot;ls 
######################################################################
#CHANGE STARTS
se = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot;ls 
#CHANGE ENDS
######################################################################



######################################################################
#CHANGE STARTS
se = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot;ls 
######################################################################
#CHANGE STARTS
se = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot;ls 
#CHANGE ENDS
######################################################################



#CHANGE ENDS
######################################################################


-ld */ | grep -w $dir_name");
		 @capture_dir_fields = split(/\s+/,$response);
		 $size_of_dir=$capture_dir_fields[4];
		$Log->comment("The size of directory is  $size_of_dir");
		   if( $size_of_dir >=2097152) {
	         $Log->comment("The created directory $dir_name is a large directory");
	       }
	       else {
	            $Log->comment("The created directory $dir_name is not a large directory: Converting it to a large directory...");
	            my $i;
	            for($i=0;$i<13000;$i++) {
	               try {
	                    $node_scope_obj->execute_command(command => "mkfile 1b /vol/$root_vol/$dir_name/$large_name$i");
	 
######################################################################
#CHANGE STARTS
     $node_scope_obj->execute_command(command => "mkfile 1b /vol/$root_vol/$dir_name/$large_name$i");
	 
#CHANGE ENDS
######################################################################



######################################################################
#CHANGE STARTS
     $node_scope_obj->execute_command(command => "mkfile 1b /vol/$root_vol/$dir_name/$large_name$i");
	 
######################################################################
#CHANGE STARTS
     $node_scope_obj->execute_command(command => "mkfile 1b /vol/$root_vol/$dir_name/$large_name$i");
	 
#CHANGE ENDS
######################################################################



#CHANGE ENDS
######################################################################


              }
	            }
	            catch NATE::BaseException with {
	                     my $exception = shift;
	                     my $error = $exception->text() ;
	                     $Log->comment("MKFILE : Failed to create file . Error $error");
	            };
	      }
		 $response = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot;ls 
######################################################################
#CHANGE STARTS
se = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot;ls 
#CHANGE ENDS
######################################################################



######################################################################
#CHANGE STARTS
se = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot;ls 
######################################################################
#CHANGE STARTS
se = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot;ls 
#CHANGE ENDS
######################################################################



#CHANGE ENDS
######################################################################


-ld */ | grep -w $dir_name");
		 @capture_dir_fields = split(/\s+/,$response);
		 $size_of_dir=$capture_dir_fields[4];
		$Log->comment("The size of directory is  $size_of_dir");
	    if( $size_of_dir >= 2097152) {
	       $Log->comment("The created directory $dir_name is a large directory");
	    }
	     #Delete some files
	       my $i;
	       for($i=1000;$i<2000;$i++) {
	             try {
	                   $node_scope_obj->execute_command(command => "rm /vol/$root_vol/$dir_name/$large_name$i");
	 
######################################################################
#CHANGE STARTS
     $node_scope_obj->execute_command(command => "rm /vol/$root_vol/$dir_name/$large_name$i");
	 
#CHANGE ENDS
######################################################################


                  $Log->comment("File deleted: $large_name$i");
	             }
	             catch NATE::BaseException with {
	                     my $exception = shift;
	                     my $error = $exception->text() ;
	                     $Log->comment("Delete : Failed to delete file . Error $error");
	             };
	      }
	   #Recreate files
	       for($i=1000;$i<2000;$i++) {
	                    try {
	                          $node_scope_obj->execute_command(command => "mkfile 1b /vol/$root_vol/$dir_name/$large_name$i");
	 
######################################################################
#CHANGE STARTS
     $node_scope_obj->execute_command(command => "mkfile 1b /vol/$root_vol/$dir_name/$large_name$i");
	 
#CHANGE ENDS
######################################################################



######################################################################
#CHANGE STARTS
     $node_scope_obj->execute_command(command => "mkfile 1b /vol/$root_vol/$dir_name/$large_name$i");
	 
######################################################################
#CHANGE STARTS
     $node_scope_obj->execute_command(command => "mkfile 1b /vol/$root_vol/$dir_name/$large_name$i");
	 
#CHANGE ENDS
######################################################################



#CHANGE ENDS
######################################################################


                         $Log->comment("File Recreated: $large_name$i");
	                    }
	               catch NATE::BaseException with {
	                     my $exception = shift;
	                     my $error = $exception->text() ;
	                     $Log->comment("MKFILE : Failed to create file . Error $error");
	               };
	       }
	    #Cleaning up the root volume
	       try {
	  $SysSh_Set_Obj = NACL::APISet->new( @dargs, context_definition => {username => 'diag', password => 'netapp1!'});
	 
######################################################################
#CHANGE STARTS
{
	  $SysSh_Set_Obj = NACL::APISet->new( @dargs, context_definition => {username => 'diag', password => 'netapp1!'});
	 
#CHANGE ENDS
######################################################################


             $response = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot; rm
######################################################################
#CHANGE STARTS
se = $SysSh_Set_Obj->execute_raw_command( command =>"cd /mroot; rm
#CHANGE ENDS
######################################################################


 -Rf $dir_name");
	              $Log->comment("Directory $dir_name deleted");
	        }
	               catch NATE::BaseException with {
	                     my $exception = shift;
	                     my $error = $exception->text() ;
	                     $Log->comment("Failed to delete the directory $dir_name . Error $error");
	               };
	    }
	  return $TCD::PASS;
	 } ### def create_convert_Ucode ends here

    def test_subrunner(self):
        self.log.info("In subrunner ")
        from collections import OrderedDict
        Testcases=OrderedDict()
        Testcases['dt_io']=Testnfs_io.dt_io
        No_of_wf = len(Testcases.keys())
        i = int(self.get_param(key='ITERATION',default = 1))
        stest = self.get_param(key='SUBTEST',default = 0)
        nos = int(self.get_param(key='TPARALLELISM',default = 3))
        if(No_of_wf < nos):
            nos=No_of_wf
        timeout = self.get_param(key='TIMEOUT',default = 3600)
        if (self.get_param(key='SHARED_OBJECT')):
            volume_obj = self.get_param(key='SHARED_OBJECT').split(",")
            volume = volume_obj[0]
            self.log.info("volume from shared object is :" + volume)
        if stest == "1" :
            while(i > 0):
                for key,value in Testcases.items():
                    self.log.info("Workflow invoked :" + key)
                    proc = NATEProcessFork(target=Testcases[key],runid=key,args=[self,])
                    proc.start()
                    while (proc.is_alive):
                        time.sleep(5)
                i = i - 1
        else:
            self.log.info("Running parallel")
            ctime = time.time()
            end_time = ctime+int(timeout)
            self.log.info("end time is :" + str(end_time))
            slots=[]
            cur_threads={}
            tobedel=[]
            while(time.time() < end_time):
                test=random.choice(list(Testcases.keys()))
                while (len(slots) < nos):
                    test=random.choice(list(Testcases.keys()))
                    if test not in slots :
                        self.log.info("Workflow invoked :" + test)
                        slots.append(test)
                        proc = NATEProcessFork(target=Testcases[test],runid=test,args=[self,])
                        proc.start()
                        cur_threads[test]=proc
                tobedel=[]
                for key,thread in cur_threads.items():
                    if not cur_threads[key].is_alive:
                        slots.remove(key)
                        tobedel.append(key)
                for k in tobedel:
                    del cur_threads[k]
            for kill,val in cur_threads.items():
                self.log.info("killing :" + str(kill))
                cur_threads[kill].terminate()
 
 
 
