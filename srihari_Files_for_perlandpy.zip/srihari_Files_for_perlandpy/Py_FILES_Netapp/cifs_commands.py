#!pytest

# Copyright (c) 2019 NetApp, Inc., All Rights Reserved.
# Any use, modification, or distribution is prohibited
#   without prior written consent from NetApp, Inc.
#Authour  gopinatj@netapp.com
#feature=cifs_commands

"""
Description : Feature interaction on volume,& cifs_commands.
This is a PYTEST based cifs_commands script which
covers the validation of the following operations

     dir_attrib
     copy_comp_del
     mkdir_rmdir
     search_within_file
     search_files
     read_file
     write_file

################################################################
##               Cifs_commands workflow                       ##
################################################################
Usage: Use wfit framework
"""

import os
import sys
from WaflFit.FITv2.lib.Wfitlib import Volume_lib
from pynacl import param_global
from pynacl.ontap.rest import StorageApi
from pynacl.ontap.rest.utils import Helper
from pynacl import log_global
from pynacl.ontap.storage import StorageAggregate
from pynacl.ontap.vserver import Vserver
from pynacl.ontap.node import Node
from pynacl.ontap.rest import Configuration
from pynacl.ontap.rest import ApiClient
from pynacl.ontap.rest import SvmApi
from pynacl.ontap.rest import ClusterApi
from pynacl.ontap.rest import rest
import pytest
from pynate.process.fork import NATEProcessFork
import time
import random
import importlib
import re
from pynacl.exceptions.base import NoElementsFoundException, CommandFailedException

v = Volume_lib()
log= log_global()
Params= param_global()

class Testcifs_cmd():
    @pytest.fixture(scope="class",autouse=True)
    def setup_cleanup(self,request):
        self.log.info("global params in top global {}".format(Params))
        if (Params.get('SHARED_OBJECTS')):
            self.shared_vols = Params.get('SHARED_OBJECTS').split(',')
        if (Params.get('NODES')):
            self.nodes = Params.get('NODES').split(',')

        self.cluster_config_file = Params.get('CLUSTER_CONFIG_FILE')
        self.log.info(self.cluster_config_file)
        self.cluster_name = Params.get('CLUSTER_NAME')
        self.sisclone_prefix = Params.get('SISCLONE_VOL')
        self.log_dir = Params.get('TOP_LOGDIR_UNIX')
        self.log_dir = self.log_dir + "/TestFiles.py"
        self.vol_infom = Params.get('VOL_INFO_FILE')
        self.vol_infom = self.vol_infom[:-2] + "py"
        self.log.info("self.log.info {}".format(self.vol_infom))
        sys.path.append(os.path.dirname(self.vol_infom))
        filename = os.path.basename(self.vol_infom)
        filename = filename[:-3]
        self.log.info("filename {}".format(filename))
        self.log.info("dirname {}".format(os.path.dirname(self.vol_infom)))
        testfiles1 = Params.get('TESTFILE_INFO_PY')
        test_filename = os.path.basename(testfiles1)
        test_filename = test_filename[:-3]
        sys.path.append(os.path.dirname(testfiles1))
        self.log.info("testfiles1 {}".format(testfiles1))
        if (os.path.isfile(self.cluster_config_file)):
            try:
                mod1 = importlib.import_module((test_filename))
                request.cls.tfiles = mod1.testfiles
            except Exception as e:
                self.log.info("Exception {}".format(e))
            try:
                mod = importlib.import_module((filename))
                request.cls.vol_info = mod.vol_info
            except Exception as e:
                self.log.info("Exception {}".format(e))
        if(Params.get('SHARED_OBJECTS') and self.shared_vols):
            self.temp = random.choice(self.shared_vols).split('#')
            request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver,request.cls.vol_type,request.cls.vol_lang= v.get_volume_info(volume=  self.temp[0], vserver = self.temp[3])
            log.info("self.vol_name={0}, self.node_obj={1}, self.vol_aggr={2}, self.data_vserver={3},self.vol_type,self.vol_lang".format(request.cls.vol_name, request.cls.node_obj, request.cls.vol_aggr, request.cls.data_vserver))
        elif(Params.get('TEST_COMMON_VOL')):
            self.vol_name, self.node_obj, self.vol_aggr, self.data_vserver = v.get_volume_info(volume= Params.get('COMMON_VOL'))
        else:
            self.vol_name, self.node_obj, self.vol_aggr, self.data_vserver = v.get_volume_random(volinfo=mod.vol_info)
            log.info("Using random volume {}".format(self.vol_name))
        if not(self.vol_name): return
        request.cls.nfs_client_obj, request.cls.nfs_mpt = v.nfs_mount_reuse(command_interface = request.cls.node_obj, volinfo = mod.vol_info, vserver = request.cls.data_vserver, volume = request.cls.vol_name,)
        self.log.info("nfs_mount_reuse param {0}{1}".format(request.cls.nfs_client_obj,request.cls.nfs_mpt))
        request.cls.njpath = v.get_junction_path(command_interface=self.node_obj,volume =self.vol_name, type='unix', volinfo=mod.vol_info)
        log.info("njpath {}".format(request.cls.njpath))
        request.cls.wjpath = v.get_junction_path(command_interface=self.node_obj,volume =self.vol_name, type='windows', volinfo=mod.vol_info)
        log.info("wjpath {}".format(request.cls.wjpath))
        yield
        self.log.info("Cleanup")

############    WORKFLOW SPECIFIC CODE/SUBROUTINES GOES HERE     ###########

    def dir_attrib(self):
        client_obj, mapp = v.cifs_share_reuse(command_interface = self.node_obj, volinfo = self.vol_info, vserver = self.data_vserver, volume = self.vol_name)
        if not(client_obj): return
        filee = random.choice(list(self.tfiles.keys()))
        self.log.info("filee {}".format(filee))
        if not(v.ensure_file_exist(command_interface = self.node_obj,
                                   client_interface  = self.nfs_client_obj,
                                   volinfo           = self.vol_info,
                                   volume            = self.vol_name,
                                   vserver           = self.data_vserver,
                                   file              = filee,
                                   test_location     = Params.get('TEST_LOCATION'),
                                   mount_path        = self.nfs_mpt)):return True
        filee = re.sub(r'/','\\\\',filee)
        print("self.wjpath",self.wjpath)
        wjpath = self.wjpath[1:]
        try:
            response = client_obj[0].execute(command= "chdir "+mapp+"\\"+wjpath+"\\dataset")
        except Exception as e:
            self.log.info("Exception {}".format(e))
        response = None
        dirn = os.path.dirname(filee)
        try:
            response = client_obj[0].execute(command= "dir "+mapp+"\\"+wjpath+"\\dataset\\"+dirn)
        except Exception as e:
            self.log.info("Exception {}".format(e))
        try:
            response = client_obj[0].execute(command="attrib " + mapp +"\\"+ wjpath + "\\dataset\\" + filee)
        except Exception as e:
            self.log.info("Exception {}".format(e))
        return True

    def copy_comp_del(self):
        client_obj,mapp =v.cifs_share_reuse(command_interface = self.node_obj,volinfo = self.vol_info,volume = self.vol_name,vserver = self.data_vserver)
        if not client_obj: return
        file1 = random.choice(list(self.tfiles.keys()))
        fpath1 = v.path_to_file_name(file=file1)
        if not v.ensure_file_exist(command_interface = self.node_obj,
                                   client_interface  = self.nfs_client_obj,
                                   volinfo           = self.vol_info,
                                   volume            = self.vol_name,
                                   vserver           = self.data_vserver,
                                   file              = file1,
                                   test_location     = Params.get('TEST_LOCATION'),
                                   mount_path        = self.nfs_mpt):
            return True
        file1 = re.sub(r'/','\\\\',file1)
        file2 = random.choice(list(self.tfiles.keys()))
        fpath2 = v.path_to_file_name(file=file2)
        if not v.ensure_file_exist(command_interface = self.node_obj,
                                   client_interface  = self.nfs_client_obj,
                                   volinfo           = self.vol_info,
                                   volume            = self.vol_name,
                                   vserver           = self.data_vserver,
                                   file              = file2,
                                   test_location     = Params.get('TEST_LOCATION'),
                                   mount_path        = self.nfs_mpt):
            return True
        file2 = re.sub(r'/', '\\\\', file2)
        #copy
        response =None
        self.log.info("copying {0} to {1}".format(file1,fpath1))
        wjpath = self.wjpath[1:]
        try:
            response = client_obj[0].execute(command = "copy /Y "+mapp+"\\"+wjpath+"\\dataset\\"+file1+" "+mapp+"\\"+wjpath+"\\"+fpath1)
        except Exception as e:
            self.log.info("Exception {}".format(e))
        # Copy to different volume
        vol_name2, node_obj2, vol_aggr2, data_vserver2,vol_type2,vol_lang2 = v.get_volume_random(volinfo= self.vol_info)
        self.log.info(" Using destination volume {}".format(vol_name2))
        dwjpath = v.get_junction_path(command_interface=self.node_obj,volume=vol_name2, type="windows",volinfo=self.vol_info)
        if (dwjpath):
            self.log.info(" Using junction path of destination volume {}".format(dwjpath))
            response = None
            try:
                response = client_obj[0].execute(command = "copy /Y "+mapp+"\\"+wjpath+"\\dataset\\"+file1+" "+mapp+"\\"+wjpath)
            except Exception as e:
                self.log.info("Exception {}".format(e))
                response = None
        #dir
        response = None
        try:
            response = client_obj[0].execute(
                command="fc "+mapp+"\\"+wjpath+"\\dataset\\"+file2+" "+mapp+"\\"+wjpath+"\\"+fpath1+" >>"+mapp+"\\"+wjpath+"\\copy_comp_del_"+str(random.randint(1,1000)))
        except Exception as e:
            log.info("Exception :{}".format(e))

        #rename
        response = None
        try:
            response = client_obj[0].execute(
                command="rename "+mapp+"\\"+wjpath+"\\"+fpath1+" h_"+fpath1)
        except Exception as e:
            log.info("Exception :{}".format(e))

        # move
        response = None
        try:
            response = client_obj[0].execute(command ="move /Y "+mapp+"\\"+wjpath+"\\h_"+fpath1+" "+mapp+"\\"+wjpath+"\\"+fpath1)
        except Exception as e:
            log.info("Exception :{}".format(e))

        #del
        response = None
        try:
            response = client_obj[0].execute(command="del /Q "+mapp+"\\"+wjpath+"\\"+fpath1)
        except Exception as e:
            log.info("Exception :{}".format(e))

    def mkdir_rmdir(self):
        client_obj, mapp = v.cifs_share_reuse(command_interface = self.node_obj,volinfo = self.vol_info,volume = self.vol_name,vserver =self.data_vserver)
        if not client_obj: return
        # choose a file in dataset
        filee = random.choice(list(self.tfiles.keys()))
        #mkdir
        dirr = time.time()
        try:
            wjpath = self.wjpath[1:]
            response = client_obj[0].execute(command= "mkdir "+mapp+"\\"+wjpath+"\\"+str(dirr)+ "\\a\\b\\c\\d\\e\\f\\g\\h\\i\\j\\k\\l\\m\\n\\o\\p\\q\\r\\s\\t\\u\\v\\w\\x\\y\\z")
        except Exception as e:
            self.log.info("Exception {}".format(e))
        return True

    def search_within_file(self):
        client_obj,mapp = v.cifs_share_reuse(command_interface = self.node_obj,volinfo = self.vol_info,volume = self.vol_name,vserver =self.data_vserver)
        if not client_obj: return

        filee = random.choice(list(self.tfiles.keys()))
        if not v.ensure_file_exist(command_interface = self.node_obj,
                                   client_interface  = self.nfs_client_obj,
                                   volinfo           = self.vol_info,
                                   volume            = self.vol_name,
                                   vserver           = self.data_vserver,
                                   file              = filee,
                                   test_location     = Params.get('TEST_LOCATION'),
                                   mount_path        = self.nfs_mpt):
            return
        dirn = os.path.dirname(filee)
        filee = re.sub(r'/','\\\\',filee)
        wjpath = self.wjpath[1:]
        try:
            response = client_obj[0].execute(command="findstr /i \"a\" "+mapp+"\\"+wjpath+"\\dataset\\"+dirn+"\\* >>"+mapp+"\\"+wjpath+"\\search_within_file_"+ str(random.randint(1, 10000)),timeout ='600')
        except Exception as e:
            self.log.info("Exception {}".format(e))
        return True

    def search_files(self):
        client_obj, mapp = v.cifs_share_reuse(command_interface = self.node_obj,volinfo = self.vol_info,volume = self.vol_name,vserver =self.data_vserver)
        if not client_obj : return
        #choose a file in dataset
        filee = random.choice(list(self.tfiles.keys()))
        ftypes = ['f','d']
        ftype = random.choice(ftypes)

        # mkdir
        response = None
        wjpath = self.wjpath[1:]
        try:
            response = client_obj[0].execute(command="x:\\cygwin\\bin\\find.exe "+mapp+"\\"+wjpath+ " -type "+ftype+" >>"+mapp+"\\"+wjpath+"\\search_files_"+str(random.randint(1,10000)),timeout = '600')
        except Exception as e:
            self.log.info("Exception {}".format(e))
        return

    def read_file(self):
        client_obj,mapp = v.cifs_share_reuse(command_interface = self.node_obj,volinfo = self.vol_info,volume = self.vol_name,vserver =self.data_vserver)

        if not client_obj:
            return
        wjpath = self.wjpath[1:]
        filee = random.choice(list(self.tfiles.keys()))
        log.info("filee {}".format(filee))
        cmds = ['head.exe','tail.exe']
        cmd = random.choice(cmds)
        if not (v.ensure_file_exist(command_interface = self.node_obj,
                                   client_interface  = self.nfs_client_obj,
                                   volinfo           = self.vol_info,
                                   volume            = self.vol_name,
                                   vserver           = self.data_vserver,
                                   file              = filee,
                                   test_location     = Params.get('TEST_LOCATION'),
                                   mount_path        = self.nfs_mpt)):return True
        filee = re.sub(r'/','\\\\',filee)
        try:
            response = client_obj[0].execute(command="x:\\cygwin\\bin\\"+cmd+" -1000 "+mapp+"\\"+wjpath+"\\dataset\\"+filee+" >>"+mapp+"\\"+wjpath+"\\read_file",timeout ='600')
        except Exception as e:
            self.log.info("Exception {}".format(e))
        return True

    def write_file(self):
        client_obj, mapp = v.cifs_share_reuse(command_interface = self.node_obj,volinfo = self.vol_info,volume = self.vol_name,vserver =self.data_vserver)
        if not client_obj:
            return
        wjpath = self.wjpath[1:]
        for _ in range(100):
            try:
                filee = v.generate_random_string(random.randint(1,1000))
                response = client_obj[0].execute(command = "echo "+filee+">>"+mapp+"\\"+wjpath+"\\write_file")
            except Exception as e:
                self.log.info("Exception {}".format(e))
        return True

    def test_subrunner(self):
        self.log.info("In subrunner ")
        from collections import OrderedDict
        Testcases=OrderedDict()
        Testcases['dir_attrib']=Testcifs_cmd.dir_attrib
        Testcases['copy_comp_del'] = Testcifs_cmd.copy_comp_del
        Testcases['mkdir_rmdir'] = Testcifs_cmd.mkdir_rmdir
        Testcases['search_within_file'] = Testcifs_cmd.search_within_file
        Testcases['search_files'] = Testcifs_cmd.search_files
        Testcases['read_file'] = Testcifs_cmd.read_file
        Testcases['write_file'] = Testcifs_cmd.write_file
        No_of_wf = len(Testcases.keys())
        i = int(self.get_param(key='ITERATION',default = 1))
        stest = self.get_param(key='SUBTEST',default = 0)
        nos = int(self.get_param(key='TPARALLELISM',default = 3))
        if(No_of_wf < nos):
            nos=No_of_wf
        timeout = self.get_param(key='TIMEOUT',default = 3600)
        if (self.get_param(key='SHARED_OBJECT')):
            volume_obj = self.get_param(key='SHARED_OBJECT').split(",")
            volume = volume_obj[0]
            self.log.info("volume from shared object is :" + volume)
        if stest == "1" :
            while(i > 0):
                for key,value in Testcases.items():
                    self.log.info("Workflow invoked :" + key)
                    proc = NATEProcessFork(target=Testcases[key],runid=key,args=[self,])
                    proc.start()
                    while (proc.is_alive):
                        time.sleep(5)
                i = i - 1
        else:
            self.log.info("Running parallel")
            ctime = time.time()
            end_time = ctime+int(timeout)
            self.log.info("end time is :" + str(end_time))
            slots=[]
            cur_threads={}
            tobedel=[]
            while(time.time() < end_time):
                test=random.choice(list(Testcases.keys()))
                while (len(slots) < nos):
                    test=random.choice(list(Testcases.keys()))
                    if test not in slots :
                        self.log.info("Workflow invoked :" + test)
                        slots.append(test)
                        proc = NATEProcessFork(target=Testcases[test],runid=test,args=[self,])
                        proc.start()
                        cur_threads[test]=proc
                tobedel=[]
                for key,thread in cur_threads.items():
                    if not cur_threads[key].is_alive:
                        slots.remove(key)
                        tobedel.append(key)
                for k in tobedel:
                    del cur_threads[k]
            for kill,val in cur_threads.items():
                self.log.info("killing :" + str(kill))
                cur_threads[kill].terminate()