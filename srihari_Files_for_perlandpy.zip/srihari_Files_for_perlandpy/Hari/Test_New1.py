'''import pytest

def one(x):
    return x+1
    
def test_ans():
    assert one(5)==6,"the condition is mismatched"
    
    
def test_ans1():
    assert one(4)==5,"the condition is mismatched"
    


def two(y):
    return y+10
    

def test_aws():
    assert two(2)==12,"the values are equal"
''' 
"""
class TestClass(object):
    def test_one(self):
        x = "this"
        assert 'h' in x

    def test_two(self):
        x = "hello"
        assert 'lo' in x
"""

'''
def first(a):
    return a+4
    

def test_first():
    r = first(10)
    assert r==14,"the value is not valid"
'''



