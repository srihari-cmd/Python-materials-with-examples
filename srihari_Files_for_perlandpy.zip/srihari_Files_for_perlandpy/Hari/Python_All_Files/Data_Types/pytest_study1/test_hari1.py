
import pytest

@pytest.mark.xfail
def test_add1():
    x=3
    y=4
    assert x+1==y,"test failed"    
@pytest.mark.skip 
def test_add2():
    x=3
    y=3
    assert x==y,"test failed"

@pytest.mark.xfail
def test_string1():
    assert "hai hello"=="hai hello","test failed"

@pytest.mark.skip 
def test_string2():
    return "hai sri"+"hello"
    assert "hai sri hello"=="hai sri hello","test failed"
 


'''
def add(x,y):
    return x+y
    
@pytest.mark.parametrize('arg1,arg2,result',[(5,5,9),("sri","hari","srihari"),(10.5,25.5,36)])
def test_add(arg1,arg2,result):
    assert add(arg1,arg2)==result,"test failed"
'''

'''
import pytest
@pytest.fixture(scope="module")
def supply_Id_Name_Branch():
    print("===========setup==============")
    Id=81312
    Name="srihari"
    Branch="IT"
    yield [Id,Name,Branch]
    print("===========teardown============")
    
def test_comparewithId(supply_Id_Name_Branch):
    result = 81312
    assert supply_Id_Name_Branch[0]==result,"Id and result comparsion failed"
    
def test_comparewithName(supply_Id_Name_Branch):
    result = "srihari"
    assert supply_Id_Name_Branch[1]==result,"Name and result comparsion failed"

def test_comparewithBranch(supply_Id_Name_Branch):
    result = "IT"
    assert supply_Id_Name_Branch[2]==result,"Branch and result comparsion failed"
'''