

# import numpy

# a = numpy.array([1,2,3,4,5,6,7,8,9,10])
# a1 = a/2
# print(a1)

# l = [1,2,3,4,5,6,7,8,9,10]

# l1 = l/2

# print(l1)


s = "hai"
print(dir(s))
