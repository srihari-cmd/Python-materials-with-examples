
import pytest
@pytest.fixture()
def setup():
    print("\n the setup before will execute the method")
    
def test_method1(setup):
    print("\n the method1 will executed")
    
def test_method2(setup):
    print("\n the method2 will executed")
    

