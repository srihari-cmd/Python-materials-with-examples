l = [1,2,4]
print(l)