t = ((1,4,2,6),(6,4,2),(8,6,5,5))
t1 = [sum(i) for i in zip(*t)]

print(t1)
print()
print("the max value is:",max(t1))


t1 = ((1,4),(6,4,2),(8,6,5,5))
t2 = [sum(i) for i in zip(*t1)]

print(t2)
print()
print("the max value is:",max(t2))


'''#the max and min values can find in tuple values after adding  tuple values.

t = ((2,3,4),(4,3,5),(7,5,6))

t1 = [sum(i) for i in zip(*t)]
print(t1)

print("the minimum value is:",min(t1))
print("the maximum value is:",max(t1))

#the max and min values can find in tuple values after adding  tuple values.

l = [[3,4,6],[5,6,2],[8,7,3]]

l1 = [sum(i) for i in zip(*l)]
print(l1)

print("the minimum value is:",min(l1))
print("the maximum value is:",max(l1))'''


