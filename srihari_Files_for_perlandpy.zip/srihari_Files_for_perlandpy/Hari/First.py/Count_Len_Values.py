
#using list comprihension
l = ["hai","hello","hi","srihari","pampana"]
l1  = [(len(i),i) for i in l]
print(l1)


#using lambda function

l2 = ["hai","hello","hi","srihari","234","pampana"]

l3 = list(map(lambda x:(len(x),x),l2))
print(l3)