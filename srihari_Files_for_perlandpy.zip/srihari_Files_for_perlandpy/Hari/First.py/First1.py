'''#the max and min values can find in tuple values after adding  tuple values.

t = ((2,3,4),(4,3,5),(7,5,6))

t1 = [sum(i) for i in zip(*t)]
print(t1)

print("the minimum value is:",min(t1))
print("the maximum value is:",max(t1))

#the max and min values can find in tuple values after adding  tuple values.

l = [[3,4,6],[5,6,2],[8,7,3]]

l1 = [sum(i) for i in zip(*l)]
print(l1)

print("the minimum value is:",min(l1))
print("the maximum value is:",max(l1))'''
import math


''''capitalize', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'index',\
'isalnum', 'isalpha', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', \
'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', \
'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip',\
'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill'


'append', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort'

'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values'


#d = {"name":"srihari","id":588}
#d1 = {"1":"srihari","2":"vijay","3":"hari"}

#d2 = [number for number,name in d1.items() if name == "srihari"]
#print(d2)

#print(d1)
#print(dir(d))

'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint',\
 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update'''''


'''
import logging

logging.basicConfig(level = logging.CRITICAL,
                    format='%(asctime) -5s,%(level) -5s %(message) s',
                    filename = "sri.log",
                    timefmt = "%H : %M : %m : %d : %y")



logging.debug("this is debug file")
logging.info("the info message")
logging.warning("the warn message")
logging.error("the error message")
logging.critical("the critical message")'''



'append', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort'




'''num = int(input("enter hte number:"))
rev = 0

while num>0:
    dig = num%10
    rev = rev *10+dig
    num = num//10
print("reverse the number:",rev)'''



'''a = int(input("enter the a value is :"))
b = int(input("enter the b value is :"))

a = a+b
b = a-b
a = a-b

print("the value of a is :",a)
print("the value of b is :",b)




n1 = 12
n2 = 21

n1,n2 = n2,n1
print(n1)
print(n2)



x =100
y = 200

temp = x
x = y
y = temp
print(x)
print(y)'''



a = 3423
b = int("".join(reversed(str(a))))
print(b)





