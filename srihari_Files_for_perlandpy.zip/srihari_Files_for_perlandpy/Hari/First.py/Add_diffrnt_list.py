#the max and min values can find in tuple values after adding  tuple values.

t = ((2,3,4),(4,3,5),(7,5,6),(4,3,2),(75,4,3))

t1 = [sum(i) for i in zip(*t)]
print(t1)

print("the minimum value is:",min(t1))
print("the maximum value is:",max(t1))

#the max and min values can find in tuple values after adding  tuple values.

l = [[3,4,6],[5,6,2],[8,7,3]]

l1 = [sum(i) for i in zip(*l)]
print(l1)

print("the minimum value is:",min(l1))
print("the maximum value is:",max(l1))

#how to add two different list values using diff methods and different ways

import operator

l = [1,2,3]
l1 = [2,3,4]

l12 = list(map(lambda x,y: x+y,l,l1))
print(l12)

l2 = list(map(operator.add,l,l1))
print(l2)


l21 = list(map(sum,zip(l,l1)))
print(l21)


l22 = [sum(i) for i in zip(l,l1)]
print(l22)






#how to remove file using os module in python


'''import os

if os.path.exists("D:\\Hari\\First.py\\Haru.txt"):
    os.remove("D:\\Hari\\First.py\\Haru.txt")

else:
    print("the file does not exist")'''


#here we are performing  the number data type contains two magic words ceil and floor

'''import math

n = 123.1
#print(dir(n))
n1 = math.ceil(n)
print(n1)
n = 123.3
#print(dir(n))
n1 = math.floor(n)
print(n1)
n = math.ceil(-45.23)
print(n)

n1 = math.ceil(1.0)
print(n1)

n2 = math.ceil(1.1)
print(n2)

n3 = math.ceil(math.pi)
print(n3)

m = max(4,56,22,4,12,67)
print(m)

m1 = max(-10,-53,-66,-5)
print(m1)

e = math.exp(2)
print(e)

'''

'''#using endcoding we can reverse the string



b = bytearray('this is srihari', 'UTF-8')
b.reverse()
b1 = b.decode('UTF-8')
print(b1)

b2 = bytearray("srihari pampana","UTF-8")
b2.reverse()
b3 = b2.decode("UTF-8")
print(b3)'''

'''
how to handle the math module using for loop
import math

for i in range(10):
    if i %2==0:
        print(int(math.pow(i,2)))

    else:
        print(int(math.sqrt(i)))


n1 = [int(math.pow(i,2)) if i%2==0 else int(math.sqrt(i)) for i in range(10)]
print("the values are :",n1)'''







