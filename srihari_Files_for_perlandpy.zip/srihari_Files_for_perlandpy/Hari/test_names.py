
'''
import pytest
@pytest.mark.skip(reason ="i am not intrested on it")
def test_file1_method1():
    x=3
    y=4
    assert x+1==4,"test failed"
    
def test_file1_method2():
    x = 4
    y = 5
    assert x+1 ==5,"test failed"

def test_file1_string1():
    x = "hello"
    y = "hello"
    assert x==y ,"test failed"
    
def test_file1_string2():
    x = "hello world"
    y = "hello world"
    assert x==y ,"test failed"
'''


import pytest

def test_add1():
    return 10+10
    assert 20==20,"test failed"

def test_add2():
    return 10+20
    assert 30==30,"test failed"
    
def test_string1():
    return "hai"+"hello"
    assert "hai hello"=="hai hello","test failed"
    
def test_string2():
    return "hai sri"+"hello"
    assert "hai sri hello"=="hai sri hello","test failed"
    
