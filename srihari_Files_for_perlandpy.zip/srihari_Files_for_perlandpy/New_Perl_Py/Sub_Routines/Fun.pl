


=abc
my @ab=("abc.com 12","gef.com 76","hari.org 12","sri.org 32");

&abc();


sub abc{
	print "Hello";
	foreach (@ab)
	{
		if($_ =~ /com/)
		{
			print "$_ \n";
		}
	}	
}
=cut


my @ab=("abc.com 12","gef.com 76","hari.org 12","sri.org 32");

&abc($m);
my $m = "org";

sub abc{
	$m = shift;
	foreach (@ab)
	{
		if($_ =~ /$m/)
		{
			print "$_ \n";
		}
	}	
}



