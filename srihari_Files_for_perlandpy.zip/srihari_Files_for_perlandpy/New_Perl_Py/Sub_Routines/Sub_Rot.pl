#!/usr/bin/perl
#use strict;
#use warnings;

=abc
my @x=("srihari.com 100","yahoo.com 200","microsoft.com 300");


sub y{
	foreach(@x)
	{
		if ($_ =~ /com/)
		{
			print $_;
		
		}
	}
}
y();
=cut












