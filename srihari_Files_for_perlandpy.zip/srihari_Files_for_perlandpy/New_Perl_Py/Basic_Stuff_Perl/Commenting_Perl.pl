#single comment

print"hello world!\n";
#print"hello world!\n";
print"hello world!\n";


# documentation

my $doc = <<"DOC";
hai here we performed the types of commenting in different ways
DOC

print $doc,"\n";


# multi line comments

print"hai !\n";
=head
print"hello!\n";
print"world!\n";
print"good!\n";
=cut
print"morning\n";
print"all!\n";


# another way of multi line comment

<<HAI
dsfdlfklbdf
sdflkjdsflgf
dfkllskgbd
flddsbgk
dfsdlbj
xclvfgdl
HAI





