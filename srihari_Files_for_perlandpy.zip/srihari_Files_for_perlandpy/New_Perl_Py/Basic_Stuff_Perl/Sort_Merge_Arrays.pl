

@x = ("B","C","E","D","W","S","F");

@x = sort(@x);
print "@x\n";

$[ = 1;

print "$x[1]\n";

