
# using split we can split the string separatly

$x = "Hai/Hello/how/are/you";
@y = split("/",$x);
print "@y\n";

# using join we can join the string separatly
$z = join("==",@y);
print "$z\n";


