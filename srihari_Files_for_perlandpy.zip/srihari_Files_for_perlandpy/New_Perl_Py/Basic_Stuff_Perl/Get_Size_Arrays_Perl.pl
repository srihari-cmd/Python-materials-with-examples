
# to get size of the array

@names  = ("a",1,3,4,"b","c");
# 1
print scalar @names;

# 2
print $#names + 1;
print $#names ;

# 3
@names  = ("a",1,3,4,"b","c");
$x = @names;
print $x,"\n";
