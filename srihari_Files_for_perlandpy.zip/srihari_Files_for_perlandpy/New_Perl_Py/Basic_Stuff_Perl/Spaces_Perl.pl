
my $x    = "hari";
my $y    = '$x';
print $y,"\n";

my $x    = "hari";
my $y    = "$x";
print $y,"\n";

my $x    = "hari";
my $y    = "\$x";
print $y,"\n";


