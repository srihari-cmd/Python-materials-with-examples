
print "we are testing perl! \n";

my $doc = <<"DOC";

this is testing file for perl 
DOC

print $doc,"\n";

<<HELLO;
print "we are testing perl! \n";
print "we are testing perl! \n";
print "we are testing perl! \n";
HELLO

print "we are testing perl! \n";
print "we are testing perl! \n";
