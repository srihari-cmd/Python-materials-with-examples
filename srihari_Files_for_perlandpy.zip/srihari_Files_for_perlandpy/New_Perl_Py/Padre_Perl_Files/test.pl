
#!/usr/bin/perl
#use strict;
#use warnings;

=abc
my $x ="srihari \n" x 5;
my $y = "$x";
print "$y \n";
 
my $a = 123;
my $b = "srihari";
print $a."-".$b."\n" ;
print "=" x 10,"\n";


my @ary= ("py",12,"pl",32,"c",14);
print "@ary\n ";
print "first value: $ary[0]\n";
print "last value: $ary[-1]\n";
print "last 2nd value: $ary[-2]\n";
print "b/w values: @ary[2..4]\n";
print "b/w values: @ary[3..$#ary]\n";
print "b/w values: @ary[$#ary-2..$#ary]\n";

print "$#ary\n";

my @ary = (1..10);
print "@ary\n";
print "the size of the array:", scalar @ary,"\n";
print "the size of the array:", $#ary+1,"\n";

push(@ary,"srihari");
print "@ary \n";

unshift(@ary,"rebal");
print "@ary \n";

shift(@ary);
print "@ary \n";

pop(@ary);
print "@ary \n";


my @ary = (1,2,3,4,5);
print "@ary \n";
splice(@ary,2,4, 12..15);
print "@ary \n";
splice(@ary,-3);
print "@ary \n";


my $str = "hair=sdf=sdlfsd=sdfs=sdf=sdfk=1=3=4=3";
my @ary = split("=",$str);
print "@ary\n";

$str = join(" ",@ary);
print "$str\n";



my @ary = ("perl","python","java","c","dotnet","ruby");
my @ary1 = sort(@ary);
print "@ary1\n";
$[= 3;
print "@ary1[3]\n";


my @ary1 = (1..5);
my @ary2 = (6..10);
my @ary = (@ary1,@ary2);
print "@ary\n";


my %hashs = (name=>"srihari",branch=>"cse",id=>5889);
print %hashs,"\n";

print "=" x 20, "\n";

my @hash1 = keys %hashs;
print "keys are: @hash1 \n";

my @hash2 = values %hashs;
print "vlaues are:@hash2 \n";

print scalar @hash1,"\n";
print scalar @hash2, "\n";

if (exists($hashs{name})){
	print "Exists\n";
}
else{
	print "not exists\n";
}

if (!exists($hashs{vijarf})){
	print "not exists\n";
}
else{
	print "exists\n";
}

$hashs{real} = 2048;
print $hashs{real},"\n";

delete $hashs{name};
if (exists($hashs{name})){
	print "exist \n";
}
else{
	print "not exist\n";
}


print "enter the skill name:";
my $input = <STDIN>;
print "$input";
chomp($input);
print "$input";

my @ary = ("perl\n","python\n","java\n");
print "@ary\n";
chomp(@ary);
print "@ary \n";

my %hash1 = (A=>"1\n",B=>"2\n",C=>"3\n");
print %hash1;
chop(%hash1);
print %hash1;
my %hash2 = (A=>"1~",B=>"2~",C=>"3~");
print %hash2,"\n";
chop(%hash2);
print %hash2,"\n";


print "enter a skill:";
my $input = <STDIN>;
print "$input";
chomp($input);
print "$input";
	

my $str = "srihari";
chop($str);
print "$str \n";

my @ary = ("sri\n","hari\n","vijay\n");
print "@ary \n";
chop(@ary);
print "@ary \n";


my @ary = ("sri@","hari@","vijay\@");
print "@ary\n";
chop(@ary);
print "@ary \n";



my %ary = (name=>"sri\n",nik=>"hari\n",babu=>"vijay\n");
print %ary ,"\n";
chop(%ary);
print %ary," \n";


my %ary1 = (name1=>"sri@",name2=>"hari@",name3=>"vijay\@");
print %ary1,"\n";
chop(%ary1);
print %ary1," \n";


#map and grep

my @ary = ("python","perl","java","ruby");
my @ary1 = map{$_ . "=Tech"}@ary;
print "@ary1\n";

#here hashs we are performing

my @ary = ("python","perl","java","ruby");
my %ary1 = map{$_ =>"Tech"}@ary;
print %ary1,"\n";

#remove dup values 

my @ary = ("python","perl","java","ruby","java","ruby");
my %ary1 = map{$_ =>"Tech"}@ary;
print keys %ary1,"\n";

#grep 

my @ary = ("python","perl","java","ruby","pro","java","ruby");
my @ary1 = grep{/^p/}@ary;
print "@ary1\n";

#map and grep

my @ary = ("python","perl","java","ruby","pro","java","ruby");
my %ary1 = map{$_ =>"tech"} grep{/^p/}@ary;
print %ary1,"\n";



sub fun {
	local $str = "srihari pampana";
	print "inside the fun: $str\n";
}

print "outside the fun : $str\n";

fun();

sub pampana {
	my $str = "srinuvasulu";
	local $str1 = "aliveni";
	print "$str \n";
	print "$str1 \n";
	srihari();
}
sub srihari {
	print "$str \n";
	print "$str1 \n";
}

pampana();

#condition statements

my @ary = ("python","perl","java","dotnet");

if ($ary[-2] eq "jav"){
	print "if condition true \n";
}
elsif ($ary[0] eq "pytho"){
	print "elsif statement is correct \n";
}

else {
	print "else condition true \n";
}


my @ary = ("python","perl","java","dotnet");

if ($ary[2] eq "perl"){
	if ($ary[-1] eq "dotnet"){
		print "True dsfdj\n";
	}
}

#unless ,elsif,else

my @ary = ("python","perl","java","dotnet");

unless (scalar @ary == 4){
	print "unless....true\n";
}
elsif($ary[0] eq "perl"){
	print "elsif ...true\n";
}
else{
	print "else ...true\n";
}

print "enter the user id :\n";

my $input = <STDIN>;
chomp($input);
(length($input)==4) ? print "length is 4\n " : print "length is not 4\n";


my @ary = ("hai","name","hai","hari","sri","hai");
my $i = 0;
my $count = 0;

while ($i< scalar @ary){
	if ($ary[$i] =~ /hai/ ){
		$count++;
	}
	$i++;
}
print "from while loop : $count\n";

my $ary1 = grep{ /hai/} @ary;
print " from grep count:$ary1\n";



my @ary = ("python","perl","java","dotnet");

foreach(@ary){
	print "$_\n";
}




my @ary = ("python","perl","java","dotnet");

foreach(0..$#ary){
	print "$ary[$_]\n";
}


my @ary1 = ([1,2,3], [4,5,6], [7,8,9]);
for (my $i=0; $i<3 ; $i++){
	for (my $j=0; $j<3;$j++){
		print "$ary1[$i][$j]";
	}
	print "\n";
}



#goto 

sub fun1 {
	goto & fun2();
}
sub fun2{
	print "fun2 \n";
}

fun1();



for (;;){
	print "srihari\n";
}


$x = 15;
$y=15;

$r = $x<=>$y;
print "$r \n";


$i = 10;
$j = 5;

$i**=$j;
print "$i\n";



@ary1 = ("perl","python","ruby","c");

if (($ary1[0] eq "perl") and (scalar @ary1==4)){
	print "both are true \n";
}

if (($ary1[0] eq "perl") && (scalar @ary1==4)){
	print "both are true \n";
}

if (($ary1[0] ne "perl") or (scalar @ary1==4)){
	print "either one or  two\n";
}

if (($ary1[0] ne "perl") || (scalar @ary1==4)){
	print "either one or  two\n";
}
if (not(($ary1[0] eq "perl") and (scalar @ary1==5))){
	print "reverse \n";
}


$x = q{perl};

$y = qq{perl};

print "$x\n$y\n";


@ary = qw(perl python 2 4 5 7);
print "@ary\n ";


my @ary = ("vij.com 121","google.com 100","youtube.com 200","hari.org 120","dfjd.org 400");


my $msg = "org";


sub fun1{
	$msg = shift;
	foreach(@ary){
		if ( $_ =~ /$msg/){
			print "$_ \n";
		}
	}
}

fun1($msg);



my @ary = ("vij.com 121","google.com 100","youtube.com 200","hari.org 120","dfjd.org 400");




sub fun1{
	my ($msg,$code) = @_;
	
	foreach(@ary){
		if ( $_ =~ /$msg.*$code/){
			print "$_ \n";
		}
	}
}

fun1("com",100);


my @ary = ("vij.com 121","google.com 100","youtube.com 200","hari.org 120","dfjd.org 400");

sub fun1{
	
	foreach(@ary){
		if ($_ =~ /com/ ){
			$_.= ": srihari";
		}
		else{
			$_.=":rebal";
		}
	}
	return (@ary);
}
@ary1 = fun1(@ary);
print "@ary1\n";



# decriment the values which is having the extention of com
my %hash = ("yoohoo.com"=>100,"youtube.com"=>200,"google.com"=>132,"hari.org"=>321,"sahoo.org"=>421);


sub fun1{
	%hash = @_;
	foreach(keys %hash){
		if ($_ =~ /com/){
			$hash{$_}--;
		}
		else{
			$hash{$_}--;
		}
	}
	return (%hash);
}

%hash = fun1(%hash);
while (my($key, $value) = each (%hash)){
print "$key=>$value \n";
}


#here we are using references for respective datatypes

my $x = "srihari pampana";
my @y = ("perl","python","ruby","c","java");
my %z = (A=>1,B=>2,C=>3);

my $scalarRef = \$x;
print "$$scalarRef\n";

my $arrayRef =\@y;
print "@$arrayRef\n";

my $hashRef = \%z;
print %$hashRef," \n";


my @y = ("perl","python","ruby","c","java");
my %z = (A=>1,B=>2,C=>3);


my $y = ["perl","python","ruby","c","java"];
my $z = {A=>1,B=>2,C=>3};

print "@$y \n";
print %$z,"\n";

print $y->[0],"\n";
print $z->{A},"\n";

my @x = ("perl","python","ruby","c","java");
my %y = (A=>1,B=>2,C=>3);
my %z = ("py","pl","c","re");

sub fun1{
	my ($ref1,$ref2,$ref3) = @_;
	
	print "@$ref1\n";
	print %$ref2,"\n";
	print %$ref3,"\n";
}

fun1(\@x,\%y,\%z);

	
my $x = ["perl","python","ruby","c","java"];
my $y = {A=>1,B=>2,C=>3};
my $z = {"py","pl","c","re"};

sub fun1{
	my ($ref1,$ref2,$ref3) = @_;
	
	print "@$ref1\n";
	print %$ref2,"\n";
	print %$ref3,"\n";
}

fun1($x,$y,$z);



#array of arrays 

my @y = (["perl","python"],[1..5],["hello.com","yahoo.com","google.com"]);

print @{$y[0]},"\n";
print @{$y[1]},"\n";
print @{$y[2]},"\n";

print @{$y[1]}[2],"\n";



my $y = [["perl","python"],[1..5],["hello.com","yahoo.com","google.com"]];

print @{$y->[0]},"\n";
print @{$y->[1]},"\n";
print @{$y->[2]},"\n";

print @{$y->[1]}[2],"\n";
=cut


my @y = ("perl.org","python.org","hello.com","yahoo.com","google.com",1..5);

my @aoA;


foreach(@y){
	if ($_ =~ /org/ ){
		push( @{$aoA[0]}, $_);
	}
	elsif( $_ =~ /com/ ){
		push( @{$aoA[1]}, $_);
	}
	else{
		push( @{$aoA[2]}, $_};
	}
}

print "@aoA\n";








	
	
	
	
	
	
	
	
	
	
	
	
	
	
















































			
	















































































