
#read file

=head
open(FHR,"<test.txt") or die "cannot open file or $!";
my @x = <FHR>;
foreach(@x){
	print "$_";	
}
close(FHR);

#write file
open(FH,">test.txt") or die "cannot open file or  $!";
print FH "ball for bat \n";
close(FH);

 
#append file 

open(FHA,">>test.txt") or die "cannot open file or $!";

print FHA "sfjakfj asfkdlslk saerjwe sdafdhkfv \n";
close(FHA);


#read and write file

open(FHRW,"+<test.txt") or die "cannot open a file or $!";

while(<FHRW>){
	print "$_";
}

print FHRW "dfjfkdj dfsldlls sdkfjsdlfjsl sdflsdlflsjf sdfldsj low high and asddkggfdglh";

close(FHRW);
=cut

#create and write file 

open(FHCW,"+>sample.txt") or die "cannot open a file or $!";

print FHCW "challoo hail ssjkadsfjs bollooow dkfvfdj hollywood sahoo \n";

while(<FHCW>){
	print "$_";

}
close(FHCW);

  
  
  