

# slicing operator

@list = (0,1,2,3,4,5,6);
print "@list\n";
print "@list[2..4]\n";

# using splice we can replace the values 

splice(@list,3,2,2,3);
print "@list\n";

# using the splice we can remove the values. 

@list1 = (1,2,3,4,5,6);
splice(@list1,-3);
print "@list1\n";




