
@skills = ("Perl",2,"Python",3,"Java",2);
print "@skills\n";

print "$skills[2]\n";

print "First element: $skills[0]\n";
print "last element: $skills[-1]\n";
print "last to second element : $skills[-2]\n";
print "between the elements of 1 to 4: @skills[1..4]\n";
print "between 0th index to 3rd : @skills[0..3]\n";
print "given 2nd index to last : @skills[2..$#skills]\n";
print "display last three elements : @skills[$#skills-2..$#skills]\n";


# here we can define a range value of 10

@list = (1..10);
print "the values of list:@list \n";


# array size 

print "array size first way:",scalar @list,"\n";
print "array size second way:",$#list + 1,"\n";


# add values from ending to the array using push method

@l = (1,2,4,6,7,"sri",9,4,"hari");
print "@l\n";

push(@l,"vijay","rebal");
print "@l\n";

# remove value from starting using shift

@l1 = (1,2,4,6,7,"sri",9,4,"hari");
print "@l1\n";

shift(@l1);	
print "@l1\n";

#add values from starting usnig unshift

@l2 = (1,2,4,6,7,"sri",9,4,"hari");
print "@l2\n";

unshift(@l2,588,589);
print "@l2\n";

#remove values from ending using pop

@l3 = (1,2,4,6,7,"sri",9,4,"hari");
print "@l3\n";

pop(@l3);
print "@l3\n";

# display the removed last element in output 

@l4 = (1,2,4,6,7,"sri",9,4,"hari");
print "@l4\n";

$poped = pop(@l4);
print "@l4\n";
print "$poped\n";

# display the removed first element in output 

@l5 = (1,2,4,6,7,"sri",9,4,"hari");
print "@l5\n";

$poped1 = shift(@l5);
print "@l5\n";
print "popped string:$poped1\n";








