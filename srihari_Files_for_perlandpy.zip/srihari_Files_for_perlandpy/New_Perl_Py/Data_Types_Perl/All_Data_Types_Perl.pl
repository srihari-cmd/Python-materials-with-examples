# scalar

$ name = "srihari";

# arrays

@names = ("srihari","vijay",1,4,6);

# % hashes

%names1 = (name=>"srihari",id=>588,branch=>"IT");


print "$name\n@names\n",%names1,"\n";

