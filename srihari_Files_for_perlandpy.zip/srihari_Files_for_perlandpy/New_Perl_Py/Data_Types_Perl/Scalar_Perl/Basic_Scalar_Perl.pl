
# numeric scalar 

$numScalar = 100;

#string scalar

$strScalar = "perl";

# vstring
$vString = v85.78.43.13;

# here . (dot) is used to concatenate the values

print $numScalar."-".$strScalar."-".$vString."\n";


print "=" x 10,"\n";





