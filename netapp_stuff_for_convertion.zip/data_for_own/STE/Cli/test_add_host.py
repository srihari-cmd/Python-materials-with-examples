import subprocess, sys,os
import pytest

@pytest.mark.host
def test_add_host():

    s='Add-SmHost -HostType Windows -HostName 10.226.17.12 -CredentialName admin'
    install_plugin = 'Install-SmHostPackage -HostNames vm2016_3_3 -PluginCodes SCW'
    login_path = r'C:\Users\Administrator\Desktop\Project\STE\Cli\login.ps1;'
    p = subprocess.Popen(['powershell.exe',f'{login_path}{s}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    output,err=p.communicate()

    if output:
        a = output.decode('UTF-8')
        print(a.splitlines())

        # p = subprocess.Popen(['powershell.exe', f'{login_path}{s}'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # output, err = p.communicate()
    else:
        a = err.decode('UTF-8')
        print(a)


    # assert str(output1[2].split(':')[1]).strip() == '10.226.17.12','Ip not matching'





















































































# s='Add-SmHost -HostType Windows -HostName 10.226.17.12 -CredentialName admin'
# install_plugin = 'Install-SmHostPackage -HostNames vm2016_3_3 -PluginCodes SCW'
# login_path = r'C:\Users\Administrator\Desktop\Project\STE\Cli\login.ps1;'
# p = subprocess.Popen(['powershell.exe',f'{login_path}{s}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
# output,err=p.communicate()
#
# if output:
#     a = output.decode('UTF-8')
#     li = a.splitlines()
#     dict = {}
#     for i in li:
#         if re.findall('^HostName*', i):
#             split_value = i.split()
#             dict[split_value[0]] = split_value[-1].strip()
#         if re.findall('^IP', i):
#             split_value = i.split()
#             dict[split_value[0]] = split_value[-1].strip()
#
#     print(dict)
#     g=dict['HostName']
#     install_plugin = f'Install-SmHostPackage -HostNames {g} -PluginCodes SCW,SCSQL'
#     d = subprocess.Popen(['powershell.exe', f'{login_path}{install_plugin}'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
#     output, err = d.communicate()
#     if output:
#         print(output)
#     else:
#         print(err)
# else:
#     a = err.decode('UTF-8')
#     print(a)
