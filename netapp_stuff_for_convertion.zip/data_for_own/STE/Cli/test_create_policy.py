import subprocess, sys,os
import pytest

@pytest.mark.policy
def test_create_policy():
    s = 'Add-SmPolicy -PolicyName sample -PluginPolicyType SCSQL -PolicyType Backup -SqlBackupType FullBackup -ScheduleType Hourly'
    login_path = r'C:\Users\Administrator\Desktop\Project\STE\Cli\login.ps1;'
    output = subprocess.Popen(['powershell.exe', f'{login_path}{s}'], stdout=subprocess.PIPE)
    output1 = output.communicate()
    output2 = output1[0].decode('UTF-8')
    print(output2)

