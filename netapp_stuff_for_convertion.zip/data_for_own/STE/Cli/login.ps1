$pass = ConvertTo-SecureString netapp1! -asplaintext -force
$cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList administrator, $pass
Open-SmConnection -SMSbaseUrl https://10.226.17.7:8146 -RoleName SnapCenterAdmin -Credential $cred



