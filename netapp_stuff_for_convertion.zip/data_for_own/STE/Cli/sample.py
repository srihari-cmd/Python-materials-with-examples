import subprocess, sys,os,re

s='Get-SmResources -HostName set2-vm9.gdl.englab.netapp.com -PluginCode SCO'
login_path = r'C:\Users\Administrator\Desktop\Project\STE\Cli\login.ps1;'
p = subprocess.Popen(['powershell.exe',f'{login_path}{s}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
output1,err=p.communicate()

if output1:
    a=output1.decode('UTF-8')
    print(a.splitlines())
else:
    a = err.decode('UTF-8')
    print(a)








