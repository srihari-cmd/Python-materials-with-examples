import subprocess, sys,os

pass1 = 'ConvertTo-SecureString netapp1! -asplaintext -force'
cred = f'New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList administrator, {pass1}'

# subprocess.call([r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",f'Open-SmConnection -SMSbaseUrl https://10.226.17.7:8146 -RoleName SnapCenterAdmin -Credential {cred}'],shell=True,stdout=sys.stdout)
# subprocess.Popen([r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",'Get-Process'],stdout=sys.stdout,shell=True)
# c=f'Open-SmConnection -SMSbaseUrl https://10.226.17.7:8146 -RoleName SnapCenterAdmin -Credential {cred}'



# os.system('powershell.exe [Open-SmConnection -SMSbaseUrl https://10.226.17.7:8146 -RoleName SnapCenterAdmin -Credential New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList administrator,ConvertTo-SecureString netapp1! -asplaintext -force]')
# os.system('powershell.exe',['Open-SmConnection -SMSbaseUrl https://10.226.17.7:8146 -RoleName SnapCenterAdmin -Credential $cred'])

import subprocess,sys,os
a = sys.path.append(r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules\SnapCenter')
# process=subprocess.run('powershell.exe -command "Import-Module SnapCenter"');
process=subprocess.Popen(["powershell.exe","-ExecutionPolicy","unrestricted","Get-module Add-SmHost"],shell=True,stdout=subprocess.PIPE);
result=process.communicate()
print (result)



#
# import  subprocess,os,sys,keyword
# # a=os.system(r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell_ise.exe')
# # os.system(r'C:\ProgramFiles\WindowsPowerShell\Modules')
# a=os.system(r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe "Add-smHost"')
# # print(a)




# # import subprocess, sys
# #
# # p = subprocess.Popen(["powershell.exe",
# #               r"C:\Users\Administrator\Desktop\Project\STE\login.ps1"],
# #               stdout=sys.stdout)
# # p.communicate()
#
# from pypsrp.powershell import PowerShell, RunspacePool
# from pypsrp.wsman import WSMan
#
# wsman = WSMan("https://10.226.17.7:8146", username="administrator", password="netapp1!",cert_validation=False)
# # wsman = WSMan("https://vmm2016_3_5:8146/", username="administrator", password="netapp1!",cert_validation=True)
# # wsman = WSMan("https://vmm2016_3_5:8146/", auth="kerberos", cert_validation=False)
# print(wsman)
# a=RunspacePool(wsman)
#
# # with RunspacePool(wsman) as pool:
# #     # execute 'Get-Process | Select-Object Name'
# #     ps = PowerShell(pool)
#     # ps.add_cmdlet("PsVersionTable")
#     # ps.add_cmdlet("Get-Process").add_cmdlet("Select-Object").add_argument("Name")
#     # output = ps.invoke()
