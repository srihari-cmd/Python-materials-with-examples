import sys, os,subprocess,re
sys.path.append(os.getcwd())
from resources.pageobject.CliPo.cli_po import Clipo
from resources.locators.cli_variable import *


a='set2-vm9.gdl.englab.netapp.com'
# Clipo.get_host_details(a,plugin_sco)

# a,b=Clipo.create_policy('samtt','SCSQL',schedule_time)
# print(a,b)

# Clipo.add_and_install(ip2,host_linux,credential2,plugin_sco)
Clipo.add_host_cli(ip1,host_windows,'admin')


# a,b=Clipo.get_host_details('set2-vm9.gdl.englab.netapp.com','SCO')
# a,b=Clipo.get_host_details('hana122.ste-hive.com','SCO')
print(a)
# print(b)
# a=Clipo.product_resources_im()
# print(a)
