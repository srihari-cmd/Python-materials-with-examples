import os, sys

sys.path.append(os.getcwd())
from resources.pageobject.login import Login
from resources.pageobject.host_po import Host
from resources.pageobject.host_page_upgrade import Upgrade
from resources.locators.locator import *
import time

class upgardeTestsuite():
    @staticmethod
    def upgrade():
        Login().open_url()
        Login.do_login()
        Host.click_host()

        Upgrade.select_all_checkbox()
        Upgrade.click_more()
        Upgrade.get_versions()

        dri.close()


if __name__ == '__main__':
    a = upgardeTestsuite()
    a.upgrade()
