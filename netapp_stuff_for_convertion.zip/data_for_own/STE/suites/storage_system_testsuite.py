import os,sys
sys.path.append(os.getcwd())
from resources.pageobject.login import Login
from resources.locators.variable import *
from resources.locators.locator import *
from resources.pageobject.storage_system_po import StorageSystem
import time

class StorageSystemTest():

    @staticmethod
    def check_ontap_cluster_count():
        Login().open_url()
        Login.do_login()
        StorageSystem.click_storage_system()
        StorageSystem.select_dropdown(ontap_cluster)
        data = StorageSystem.check_ontap_svm_cluster_count()
        print(data)

        StorageSystem.select_dropdown(ontap_svm)
        StorageSystem.verify_ontap_cluster_with_svm(data)

    @staticmethod
    def check_ontap_cluster_modify_storage_system():

        StorageSystem.select_dropdown(ontap_cluster)
        StorageSystem.cluster_modify_storage_system()
        dri.close()


if __name__ == '__main__':
    a=StorageSystemTest()
    a.check_ontap_cluster_count()
    time.sleep(5)
    a.check_ontap_cluster_modify_storage_system()


