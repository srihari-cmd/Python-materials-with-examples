import pytest
import os,sys
sys.path.append(os.getcwd())
from resources.pageobject.login import Login
from resources.locators.locator import *
from resources.locators.variable import *
from resources.pageobject.host_po import Host
from resources.pageobject.storage_system_po import StorageSystem

def setup_module(module):
    Login().open_url()
    Login.do_login()

def teardown_module(module):
    # Host.delete_host(host_details['host'])
    dri.close()

@pytest.mark.host
def test_add_host_and_verify_in_monitor_page():
    Host.click_host()
    global host_details
    host_details = Host.add_values_to_host(windows, win_ip, admin, microsoft_windows)
    Host.verify_host_added_in_monitor_page(host_details)






















