import os

db = 'svm'
if db=='svm':
    os.system(f'python -m pytest test_storage_system.py -k test_verify_that_cluster_svm_count --html={db}.html')
elif db=='host':
    os.system(f'python -m pytest test_host.py -k test_add_host_and_verify_in_monitor_page --html={db}.html')