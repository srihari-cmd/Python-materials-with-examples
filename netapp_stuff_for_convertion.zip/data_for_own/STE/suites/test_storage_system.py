import pytest
import os, sys
sys.path.append(os.getcwd())
from resources.pageobject.login import Login
from resources.locators.variable import *
from resources.locators.locator import *
from resources.pageobject.storage_system_po import StorageSystem
from utils.ssh import SSH


def setup_module(module):
    Login().open_url()
    Login.do_login()


def teardown_module(module):
    dri.close()

@pytest.mark.svm
def test_verify_that_cluster_svm_count():

    StorageSystem.click_storage_system()
    StorageSystem.select_dropdown(ontap_cluster)
    gui_result = StorageSystem.check_ontap_svm_cluster_count()
    print(f'Gui page result:{gui_result}')
    ssh_date = SSH.ssh(gui_result['stoarge connection name'], vserve)
    print(ssh_date)
    list = []
    for i in ssh_date[4:-2]:
        list.append(i.strip())
    row_count = ssh_date[-2].split()
    print(f'CLI page result:{list}')
    print(f'CLI svm count:{row_count[0]}')

    assert gui_result['count'] == int(row_count[0]), "svm count is mismatching"
    for gui_svm, cli_svm in zip(sorted(list), sorted(gui_result['name'])):
        assert gui_svm == cli_svm, "Svm name is not matching"
