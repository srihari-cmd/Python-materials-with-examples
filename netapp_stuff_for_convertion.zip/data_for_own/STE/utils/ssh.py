import os,sys
path = os.path.join(os.getcwd())
sys.path.append(path)
from resources.locators.variable import *
import paramiko
import time

class SSH():

    @staticmethod
    def ssh(ip, cmd, usr=ssh_usr, pwd=ssh_pwd):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            ssh.connect(ip, port=22, username=usr, password=pwd)
            print('SSH connection successfull')
            sin, output, str= ssh.exec_command(cmd)
            cmd_output  = output.readlines()

            return cmd_output
        except:
            print("error")

        finally:
            if ssh:
                ssh.close()
                print('SSH connection closed')

if __name__ == '__main__':
    pass
    # s=SSH()
    # c= s.ssh('10.237.211.54',vserve)
    # print(c)