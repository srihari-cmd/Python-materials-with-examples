import os, sys

sys.path.append(os.getcwd())
from resources.locators.variable import *
from resources.locators.locator import *

import logging
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By


class Login:

    @staticmethod
    def open_url(url=url):
        """
        This method naviagte to the url
        :param url: pass web browser url
        :return:
        """

        dri.get(url)
        WebDriverWait(dri, 20).until(EC.url_matches(url))
        dri.maximize_window()
        logging.info('login successful')

    @staticmethod
    def do_logout():
        dri.find_element_by_css_selector(sign_out).click()
        print('logout successfull')

    @staticmethod
    def do_login(usr=username, pwd=password):
        """
        This method will do login functionality
        enter username and password to login the page
        :param usr: username
        :param pwd: password
        :return:
        """
        WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.ID, username_id)))
        dri.find_element_by_id(username_id).send_keys(usr)
        dri.find_element_by_id(password_id).send_keys(pwd)
        dri.find_element_by_css_selector(sign_in).submit()

        # This line verifies the url is changed or not
        WebDriverWait(dri, 20).until((EC.url_changes(url_changes)))


if __name__ == '__main__':
    pass
