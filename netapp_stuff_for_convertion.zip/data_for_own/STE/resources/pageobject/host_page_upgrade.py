import sys, os

sys.path.append(os.getcwd())
from resources.locators.locator import *
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from resources.locators.variable import *
import time


class Upgrade():

    @staticmethod
    def select_all_checkbox():
        """
        This method click on host page name button
        :return:
        """
        WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.XPATH, name_css)))
        dri.find_element_by_xpath(name_css).click()

    @staticmethod
    def click_more():
        """
                This method upgrade the all
                :return:
                """
        dri.find_element_by_xpath(more_xpath).click()
        dri.find_element_by_link_text(upgrade_text).click()
        # WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.CSS_SELECTOR, version_upgrade_text_ok)))
        WebDriverWait(dri, 20).until(EC.text_to_be_present_in_element((By.ID, upgrade_pop_up),upgrade_pop_up_text))

        dri.find_element_by_css_selector(version_upgrade_text_ok).click()
        WebDriverWait(dri, 35).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, versions_css_selector)))

    @staticmethod
    def get_versions():
        """
        This method will navigate to host tab
        :return:
        """
        WebDriverWait(dri, 35).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, versions_css_selector)))
        versions = dri.find_elements_by_css_selector(versions_css_selector)

        list = []
        matched = 0
        unmatched = 0
        for version in versions:
            list.append(version.text)
        for i in list:
            if i == "4.3":
                matched += 1
            else:
                unmatched += 1
        print("total 4.3 version are matched in host page: {0}".format(matched))
        print("total 4.3 version are unmatched in host page: {0}".format(unmatched))

if __name__ == '__main__':
    pass