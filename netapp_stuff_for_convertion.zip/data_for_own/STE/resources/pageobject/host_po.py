import sys, os

sys.path.append(os.getcwd())
from resources.locators.variable import *
from resources.locators.locator import *
from resources.pageobject.login import Login

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
import time
from datetime import datetime
from selenium.common.exceptions import NoSuchElementException


class Host():

    @staticmethod
    def click_host():
        """
        This method will navigate to host tab
        :return:
        """
        WebDriverWait(dri, 30).until(EC.text_to_be_present_in_element((By.CSS_SELECTOR, host_css), host_text))
        action = ActionChains(dri)
        host_id = dri.find_element_by_id(host)
        action.move_to_element(host_id).click().perform()
        WebDriverWait(dri, 60).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, host_name_row)))
        print('Navigated to host page')

    @staticmethod
    def click_monitor():
        """
        This method will navigate to monitor tab
        :return:
        """
        WebDriverWait(dri, 30).until(EC.presence_of_element_located((By.ID, monitor_id)))
        action = ActionChains(dri)
        host_id = dri.find_element_by_id(monitor_id)
        action.move_to_element(host_id).click().perform()
        WebDriverWait(dri, 100).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, monitor_row)))

    @staticmethod
    def get_total_count(total=host_page_total_count):
        WebDriverWait(dri, 30).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, host_name_row)))
        total_count = dri.find_element_by_css_selector(total).text
        split_value = total_count.split()
        return {split_value[0]: split_value[1]}

    @staticmethod
    def add_values_to_host(os, ip, credential, plugin):
        """
        This method will add the host ip
        :return:
        """
        total_count = Host.get_total_count()

        WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.CSS_SELECTOR, add_host)))
        dri.find_element_by_css_selector(add_host).click()
        WebDriverWait(dri, 20).until(EC.text_to_be_present_in_element((By.XPATH, add_host_xpath), add_host_text))

        dri.find_element_by_css_selector(host_type_dropdown).click()
        os_type = f'(//div[@class="dropdown-menu open"]//li//span[text()="{os}"])[2]'
        WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.XPATH, os_type)))
        dri.find_element_by_xpath(os_type).click()

        dri.find_element_by_css_selector(host_ip_input).send_keys(ip)

        dri.find_element_by_css_selector(credentials_dropdown).click()
        cre_type = f'//li//span[text()="{credential}"]'
        WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.XPATH, cre_type)))
        dri.find_element_by_xpath(cre_type).click()

        dri.find_element_by_css_selector(plugin).click()

        dri.find_element_by_id(submit_button).click()

        count_xpath = f'//div[text()="Total {int(total_count["Total"]) + 1}"]'
        WebDriverWait(dri, 900).until(EC.presence_of_element_located((By.XPATH, count_xpath)))
        date_time = Host.get_date()
        WebDriverWait(dri, 20).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, host_name_row)))
        print('host added successfully')

        for i in range(int(total_count["Total"]) + 1, 1, -1):
            dri.find_element_by_xpath(f'(//table[@id="id-sm-host-table"]//td//span){[i]}').click()
            WebDriverWait(dri, 20).until((EC.presence_of_element_located((By.XPATH, host_details))))
            ip_xpath = f'//span[text()="{ip}"]'
            WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.CSS_SELECTOR, host_details_discovery)))
            WebDriverWait(dri, 100).until_not(EC.presence_of_element_located((By.CSS_SELECTOR, host_details_discovery)))
            if dri.find_element_by_xpath(ip_xpath):
                WebDriverWait(dri, 10).until_not(EC.presence_of_element_located((By.XPATH, host_details_host_name)))
                global host_details_name
                host_details_name = dri.find_element_by_css_selector(host_details_host_name).text
                WebDriverWait(dri, 15).until(EC.presence_of_element_located((By.CSS_SELECTOR, cancel_button)))
                dri.find_element_by_css_selector(cancel_button).click()
                break
            else:
                WebDriverWait(dri, 15).until(EC.presence_of_element_located((By.CSS_SELECTOR, cancel_button)))
                dri.find_element_by_css_selector(cancel_button).click()

        print(host_details_name)
        validation = f'//a[text()="{host_details_name}"]//ancestor::tr//td[contains(text(),"Running")]'
        host_name = f'//a[text()="{host_details_name}"]'
        host_name_version = f'//a[text()="{host_details_name}"]//ancestor::tr//td[6]'

        WebDriverWait(dri, 20).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, host_name_row)))

        WebDriverWait(dri, 100).until(EC.presence_of_element_located((By.XPATH, host_name)))
        WebDriverWait(dri, 900).until(EC.presence_of_element_located((By.XPATH, validation)))
        print('host state is running')

        WebDriverWait(dri, 50).until(EC.presence_of_element_located((By.XPATH, host_name_version)))
        text = dri.find_element_by_xpath(host_name_version).text
        assert str(text) == str('4.3.1'), "failed"

        return {'version': str(text), 'host': host_details_name, 'date': date_time}

    @staticmethod
    def verify_host_added_in_monitor_page(host):

        Host.click_monitor()

        name_xpath = f'(//td[text()="Add Host \'{host["host"]}\'"])[1]'
        strat_data_xpath = f'(//td[text()="Add Host \'{host["host"]}\'"]//..//td[4])[1]'
        status_xpath = f'(//td[text()="Add Host \'{host["host"]}\'"]//..//td[2]//i)[1]'

        WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.XPATH, name_xpath)))
        name = dri.find_element_by_xpath(name_xpath).text
        date = dri.find_element_by_xpath(strat_data_xpath).text
        status = dri.find_element_by_xpath(status_xpath).get_attribute('title')

        assert name == f'Add Host \'{host["host"]}\'', "host name mismatched"
        assert status == 'Completed', "host status mismatched"
        print(host)
        print(f'Host added actual time:{date}')
        print(f'Host added manual time:{host["date"]}')
        # assert date == 'kk', "name mismatch"
        print("host added successfully and verified")

    @staticmethod
    def get_date():
        da = datetime.now()
        return da.strftime('%m/%d/%Y %H:%M:%S %p')

    @staticmethod
    def delete_host(host):
        """
        This method will delete the host in host page
        :param host:
        :return:
        """
        xpath = f'//a[text()="{host}"]//ancestor::tr//td[1]//label'
        Host.click_host()
        WebDriverWait(dri, 100).until(EC.presence_of_element_located((By.XPATH, xpath)))
        dri.find_element_by_xpath(xpath).click()

        uninstall = f'//a[text()="{host}"]//ancestor::tr//td[contains(text(),"UnInstalling plug-in")]'

        WebDriverWait(dri, 5).until(EC.presence_of_element_located((By.ID, host_delete)))
        dri.find_element_by_id(host_delete).click()
        WebDriverWait(dri, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, delete_modal)))
        dri.find_element_by_css_selector(delete_modal).click()
        WebDriverWait(dri, 5).until(EC.presence_of_element_located((By.ID, delete_checkbox)))
        dri.find_element_by_id(delete_checkbox).click()
        WebDriverWait(dri, 5).until(EC.presence_of_element_located((By.ID, delete_checkbox1)))
        dri.find_element_by_id(delete_checkbox1).click()

        WebDriverWait(dri, 5).until(EC.presence_of_element_located((By.ID, ok_button)))
        dri.find_element_by_id(ok_button).click()

        WebDriverWait(dri, 200).until(EC.presence_of_element_located((By.XPATH, uninstall)))
        WebDriverWait(dri, 400).until_not(EC.presence_of_element_located((By.XPATH, uninstall)))

        name = f'//a[text()="{host}"]'

        WebDriverWait(dri, 100).until_not(EC.presence_of_element_located((By.XPATH, name)))

    @staticmethod
    def delete_host_last(host='none', ip='none'):
        """
        This method will delete the host in host page
        :param host:
        :return:
        """
        Host.click_host()
        global host_status
        host_status = True
        if host != 'none':
            print(host)
            xpath = f'//a[text()="{host}"]//ancestor::tr//td[1]//label'
            try:
                WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.XPATH, xpath)))
                dri.find_element_by_xpath(xpath).click()
            except NoSuchElementException:
                host_status = False

        else:
            total_count = Host.get_total_count()
            for i in range(int(total_count["Total"]), 1, -1):
                dri.find_element_by_xpath(f'(//table[@id="id-sm-host-table"]//td//span){[i]}').click()
                WebDriverWait(dri, 20).until((EC.presence_of_element_located((By.XPATH, host_details))))
                ip_xpath = f'//span[text()="{ip}"]'
                WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.CSS_SELECTOR, host_details_discovery)))
                WebDriverWait(dri, 300).until_not(
                    EC.presence_of_element_located((By.CSS_SELECTOR, host_details_discovery)))
                s= ''
                try:
                    s = dri.find_element_by_xpath(ip_xpath)
                except NoSuchElementException:
                    print('No such element found in host page')
                    pass
                if s:
                    WebDriverWait(dri, 10).until_not(EC.presence_of_element_located((By.XPATH, host_details_host_name)))
                    global host_details_name
                    host_details_name = dri.find_element_by_css_selector(host_details_host_name).text
                    WebDriverWait(dri, 15).until(EC.presence_of_element_located((By.CSS_SELECTOR, cancel_button)))
                    dri.find_element_by_css_selector(cancel_button).click()
                    xpath = f'//a[text()="{host_details_name}"]//ancestor::tr//td[1]//label'
                    WebDriverWait(dri, 100).until(EC.presence_of_element_located((By.XPATH, xpath)))
                    dri.find_element_by_xpath(xpath).click()
                    break
                else:
                    if i == 1:
                        host_status = False
                    WebDriverWait(dri, 15).until(EC.presence_of_element_located((By.CSS_SELECTOR, cancel_button)))
                    dri.find_element_by_css_selector(cancel_button).click()
            print(ip)

        if host_status == True:
            uninstall = f'//a[text()="{host}"]//ancestor::tr//td[contains(text(),"UnInstalling plug-in")]'
            WebDriverWait(dri, 5).until(EC.presence_of_element_located((By.ID, host_delete)))
            dri.find_element_by_id(host_delete).click()
            WebDriverWait(dri, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, delete_modal)))
            dri.find_element_by_css_selector(delete_modal).click()
            WebDriverWait(dri, 5).until(EC.presence_of_element_located((By.ID, delete_checkbox)))
            dri.find_element_by_id(delete_checkbox).click()
            WebDriverWait(dri, 5).until(EC.presence_of_element_located((By.ID, delete_checkbox1)))
            dri.find_element_by_id(delete_checkbox1).click()

            WebDriverWait(dri, 5).until(EC.presence_of_element_located((By.ID, ok_button)))
            dri.find_element_by_id(ok_button).click()

            WebDriverWait(dri, 400).until(EC.presence_of_element_located((By.XPATH, uninstall)))
            WebDriverWait(dri, 800).until_not(EC.presence_of_element_located((By.XPATH, uninstall)))

            name = f'//a[text()="{host}"]'

            WebDriverWait(dri, 100).until_not(EC.presence_of_element_located((By.XPATH, name)))
        else:
            print('No such element found in host page')


if __name__ == '__main__':
    pass
