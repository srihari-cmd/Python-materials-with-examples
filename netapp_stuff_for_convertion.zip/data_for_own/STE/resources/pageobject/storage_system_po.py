import sys,os
sys.path.append(os.getcwd())
from resources.locators.variable import *
from resources.locators.locator import *
from resources.pageobject.login import Login

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
import time


class StorageSystem():

    @staticmethod
    def click_storage_system():
        """
        This method will navigate to storage tab
        :return:
        """
        WebDriverWait(dri,25).until(EC.text_to_be_present_in_element((By.CSS_SELECTOR,stoarge_system_css),storage_system_text))
        actions = ActionChains(dri)
        a= dri.find_element_by_id(stoarge_system)
        actions.move_to_element(a).click().perform()
        # WebDriverWait(dri,15).until(EC.text_to_be_present_in_element((By.XPATH,stoarge_connection),storage_connection_text))
        WebDriverWait(dri, 100).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, storage_system_table_row_count)))

    @staticmethod
    def select_dropdown(text):
        WebDriverWait(dri, 100).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, storage_system_table_row_count)))
        WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.ID, stoarge_system_dropdown)))
        dri.find_element_by_id(stoarge_system_dropdown).click()
        text_xpath = f'//option[text()="{text}"]'
        WebDriverWait(dri, 50).until(EC.presence_of_element_located((By.XPATH, text_xpath)))
        dri.find_element_by_xpath(text_xpath).click()

    @staticmethod
    def check_ontap_svm_cluster_count():
        """
        This method will count the number rows is equal to actual count
        :return:
        """
        #This line will wait for all element to be loaded
        WebDriverWait(dri,20).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR,storage_system_table_row_count)))

        WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.XPATH, scnd_optn_link_click_xpath)))
        storage_name = dri.find_element_by_xpath(scnd_optn_link_click_xpath).text
        print(f'stoarge connection name:{storage_name}')

        WebDriverWait(dri,5).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR,stoarge_ip_column)))
        ips_column = dri.find_elements_by_css_selector(stoarge_ip_column)[1].text
        ip_column = ips_column.split()

        dri.find_element_by_xpath(scnd_optn_link_click_xpath).click()
        WebDriverWait(dri, 20).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, storage_system_row_count1)))
        count = dri.find_elements_by_css_selector(storage_system_row_count1)

        name=[]
        for value in count:
            name.append(value.text)

        print(f'GUI Ontap cluster count:{len(count)}')
        dri.find_element_by_id(cncl_btn_id).click()

        return {'stoarge connection name' : storage_name,'count':len(count),'name':name,'ip':ip_column[0]}

    @staticmethod
    def verify_ontap_cluster_with_svm(cluster_list):
        """
        This method will take all ontap svm count and it will check with ontap cluster count
        :return:
        """
        cluster_name = f'//td[text()="{cluster_list["stoarge connection name"]}"]'
        # This line will wait for all element to be loaded
        WebDriverWait(dri, 20).until(EC.visibility_of_all_elements_located((By.XPATH, cluster_name)))
        count = dri.find_elements_by_xpath(cluster_name)
        print(f'Ontap svm cluster count:{len(count)}')

        assert len(count) == cluster_list['count'], "count is not equal"

    @staticmethod
    def cluster_modify_storage_system():
        WebDriverWait(dri, 20).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, storage_system_table_row_count)))

        WebDriverWait(dri, 20).until(EC.presence_of_element_located((By.XPATH, scnd_optn_link_click_xpath)))
        storage_name = dri.find_element_by_xpath(scnd_optn_link_click_xpath).text
        print(f'stoarge connection name:{storage_name}')
        dri.find_element_by_xpath(scnd_optn_link_click_xpath).click()
        WebDriverWait(dri, 20).until(
            EC.visibility_of_all_elements_located((By.CSS_SELECTOR, storage_system_row_count1)))
        count1 = dri.find_elements_by_css_selector(storage_system_row_count1)
        print(f'Ontap cluster row1 count:{len(count1)}')

        count2 = dri.find_elements_by_xpath(storage_system_row_count2)
        print(f'Ontap cluster row2 count:{len(count2)}')
        assert int(len(count1)) == int(len(count2)), "Total count is not equal"

        dri.find_element_by_id(cncl_btn_id).click()

    @staticmethod
    def check_ontap_svm_count():
        """
        This function will take the all svm count in storage system page
        :return:
        """

        WebDriverWait(dri, 25).until(EC.visibility_of_all_elements_located((By.CSS_SELECTOR, storage_system_table_row_count)))
        WebDriverWait(dri,10).until(EC.presence_of_element_located((By.ID,total_count)))
        count = dri.find_element_by_id(total_count).text
        svm_count = count.split()

        return {'Total_count':svm_count[1]}


if __name__ == '__main__':
    pass
