"""
This file constain static variable informations
"""

# browser = 'chrome'
url = 'https://vmm2016_3_5:8146/'
url_changes = 'https://vmm2016_3_5:8146/Dashboard'

username = 'administrator'
password = 'netapp1!'
ssh_usr = 'admin'
ssh_pwd = 'netapp1!'

##################Commands#################
vserve = 'vserver show -type  data -fields vserver *'

######### Stoarge System###################

ontap_svm = 'ONTAP SVMs'
ontap_cluster = 'ONTAP Clusters '
storage_system_text = 'Storage Systems'
storage_connection_text = 'Storage Connections'

######## Host ################
host_text = 'Hosts'
add_host_text = 'Add Host'
cre_title_text = 'Provide information for the Credentials you want to add'

credential_name_text = 'test'
user_name = 'administrator'
password_cre = 'netapp1!'
upgrade_pop_up_text = 'The plug-ins on the selected hosts will be upgraded to 4.3 version.'

win_ip = '10.226.17.12'
windows = 'Windows'
linux = 'Linux'
vsphere = 'vSphere'
admin = 'admin'

hana_ip = '10.226.17.6'
oracle_ip = '10.226.17.9'
