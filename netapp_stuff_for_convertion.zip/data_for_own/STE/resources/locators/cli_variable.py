host_windows = 'Windows'
host_linux = 'Linux'
credential1 = 'admin'
credential2 = 'root'

plugin_scm = 'SCM'
plugin_scsql = 'SCSQL'
plugin_scm_scsql = 'SCW,SCSQL'
plugin_sco = 'SCO'
schedule_time = 'Hourly'
oracle_database = 'Oracle Database'

ip1 = '10.226.17.12'
ip2 = '10.226.17.9'
