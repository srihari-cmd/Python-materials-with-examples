"""
This file contain page locators
"""
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

# browser = 'firefox'
browser = 'chrome'
# browser = 'IE'
if browser == 'chrome':
    dri = webdriver.Chrome()
elif browser == 'firefox':
    dri = webdriver.Firefox()
else:
    dri = webdriver.Ie()

username_id = 'id-sm-username'
password_id = 'id-sm-password'
sign_in = '.sm-dialog-signin-button'
netapp_logo = 'netapp-logo'
sign_out = '.sm-signout-text'

####### storage system page ######

stoarge_system = 'id-sm-nav-storagesystems'
stoarge_system_css = '#id-sm-nav-storagesystems span'
stoarge_connection = '//h4[text()="Storage Connections"]'
stoarge_system_dropdown = 'selectStorageSystemOSType'

storage_system_table_row_count = '#id-sm-storage-connection-table td a.name'
total_count = 'id-sm-storage-connection-table_info'

Dash_B_xpath = '//span[contains(text(),"Dashboard")]'
assrt_button_xpath = '//span[contains(text(),"Storage Systems")]'
click_button_xpath = '//span[contains(text(),"Storage Systems")]'

asst_with_type = '//label[contains(text(),"Type")]'
scnd_optn_click_xpath = '//select/option[contains(text(),"ONTAP Clusters ")]'
scnd_optn_link_click_xpath = '(//span/a[@class="name"])[1]'
Storage_Virtual_Machines_xpath = '//strong[contains(text(),"Storage Virtual Machines")]'
storage_system_row_count1 = "#id-sm-svm-table tr td.col-name"
storage_system_row_count2 = '//td[contains(text(),"ONTAP SVM")]'
cncl_btn_id = "id-sm-btncancel"
stoarge_ip_column = '#id-sm-storage-connection-table tbody tr td.col-ip'

########## host page #################

host = 'id-sm-nav-hosts'
host_css = '#id-sm-nav-hosts span'
add_host = '#id-sm-add-host'
add_host_xpath = '//strong[text()="Add Host"]'
host_ip_input = '#id-host-name'

microsoft_windows = 'label[for="id-chk-windows"]'
microsoft_sql_server = 'label[for="id-chk-sql"]'
microsoft_exchange_serve = 'label[for="id-chk-exchange"]'
sap_hana = 'label[for="id-chk-hana"]'

# ip_host_name = 'vm2016_3_3'
# validation = f'//a[text()="{ip_host_name}"]//ancestor::tr//td[contains(text(),"Running")]'
# host_name = f'//a[text()="{ip_host_name}"]'
# host_name_version = f'//a[text()="{ip_host_name}"]//ancestor::tr//td[6]'

host_page_total_count = '#id-sm-host-table_info'
host_details = '//h3[text()="Host Details"]'
host_details_host_name = '#id-sm-host-name'

cancel_button = '#id-sm-cancel'
host_details_discovery = '#id-hostprogress .processing'

# srihari created the three xpaths

# select_credential ='(//span[@class="filter-option pull-left"])[5]'
# select_credential ='(//button[@class="btn dropdown-toggle selectpicker btn-default"])[5]'
select_credential = '#id-div-add-host div form div:nth-child(3) div button'
# credential_option ='(//span[contains(text(),"admin2")])[2]'
credential_option = '(//span[contains(text(),"test")])[1]'
select_plugins = '//label[@for="id-chk-windows"]'

submit_button = 'id-sm-submit-host'
plus_button = 'btnCreateRunAs'
cre_title = 'id-sm-subtitle'

credential_name = '#id-sm-runas-name'
username_input = 'id-sm-runas-user'
password_input = 'id-sm-runas-pwd'
ok_button = 'id-sm-btn-primary'
host_name_row = '#id-sm-host-table td span'
host_name_row_xpath = '(//table[@id="id-sm-host-table"]//td//span)'
host_type_dropdown = 'button[data-id="id-host-os"]'
credentials_dropdown = 'button[data-id="id-sm-runas-names-dropdown"]'

# Delete
host_delete = 'id-sm-delete-host'
delete_modal = '.ui-draggable-handle'
delete_checkbox = 'id-sm-delete-host-force-checkbox'
delete_checkbox1 = 'id-sm-delete-host-deleteclones-force-checkbox'

######### upgrade version verification ############

name_css = '(//label[@for="id-chk-sm-host-table-all"])[1]'
more_xpath = "//*[@id='id-sm-menu']/i"
upgrade_text = "Upgrade"
version_upgrade_text_ok = "#id-sm-upgrade-ok"
upgrade_pop_up = 'id-sm-batch-upgrade-label'

######### all versions in host page #########
versions_css_selector = "#id-sm-host-table tbody td:nth-child(6)"

####################Monitor Page###################
monitor_id = 'id-sm-nav-monitor'
# name_xpath = '(//td[text()="Add Host \'vm2016_3_3\'"])[1]'
# strat_data_xpath = '(//td[text()="Add Host \'vm2016_3_3\'"]//..//td[4])[1]'
# status_xpath = '(//td[text()="Add Host \'vm2016_3_3\'"]//..//td[2]//i)[1]'
monitor_row = '#id-sm-jobs-table tbody tr td'
