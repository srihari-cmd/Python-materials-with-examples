import subprocess, sys,os
import json


pass1 = 'ConvertTo-SecureString netapp1! -asplaintext -force'

p = subprocess.Popen(['powershell.exe',pass1],stdout=subprocess.PIPE)

a=p.communicate()[0]
print(a)
d=a.decode("UTF-8")
print(d)
t=json.dumps(d)
print(t)
cred = 'New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList administrator,{}'.format(t)

p = subprocess.Popen(['powershell.exe',cred],stdout=subprocess.PIPE)
print(p.communicate())


# s = 'Add-SmPolicy -PolicyName TESTPolicy -PluginPolicyType SCSQL -PolicyType Backup -SqlBackupType FullBackup -ScheduleType Hourly'
# login_path = r'C:\Users\Administrator\Desktop\Project\STE\Cli\login.ps1;'
# p = subprocess.Popen(['powershell.exe', f'{login_path}{s}'], stdout=subprocess.PIPE)
# c = p.communicate()
# d=c[0].decode('UTF-8')
# print(d)
# convert_list = list(c)
# v = str(convert_list[0].strip()).split(r'\r\n')
#
# di={}
# for i in v:
#     a=i.replace(':',' ')
#     c=a.split(' ',2)
#     print(c)
#     if len(c)==2:
#         di[c[0]] = c[-1]
#     else:
#         di[c[0]] = ' '
#
# print(di)
