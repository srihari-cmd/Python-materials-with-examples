import subprocess, sys,os
p = subprocess.Popen(['powershell.exe',r'C:\Users\Administrator\Desktop\Project\STE\Cli\create_policy.ps1'],stdout=subprocess.PIPE)
print(p.communicate())


