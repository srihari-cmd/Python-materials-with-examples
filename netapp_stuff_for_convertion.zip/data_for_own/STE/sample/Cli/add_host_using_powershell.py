import subprocess, sys,os
p = subprocess.Popen(['powershell.exe',r'C:\Users\Administrator\Desktop\Project\STE\Cli\add_host.ps1'],stdout=subprocess.PIPE)
c=p.communicate()

convert_list = list(c)
v=str(convert_list[0].strip()).split(r'\r\n')
for i in v:
    print(i)

assert str(v[2].split(':')[1]).strip() == '10.226.17.12','Ip not matching'

