$pass = ConvertTo-SecureString netapp1! -asplaintext -force
write-host $pass
$cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList administrator, $pass
write-host $cred

Open-SmConnection -SMSbaseUrl https://10.226.17.7:8146 -RoleName SnapCenterAdmin -Credential $cred
$ss = Add-SmHost -HostType Windows -HostName 10.226.17.12 -CredentialName admin

#$ss
#Set-Content -Path ".\Cli\Outputfile.txt" -Value $ss -Force


