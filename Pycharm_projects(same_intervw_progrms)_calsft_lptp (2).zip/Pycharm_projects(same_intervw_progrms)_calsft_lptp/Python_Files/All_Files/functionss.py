def add(a,b):
    print("the function is working fine. the value is",a+b)

add(20,10)


def add1(a=10,b=20):
    print("the value of funtion is ",a+b)

add1(30,40)
add1(33)
add1()

def add2(a,b):
    print("the value of function is ",a+b)
    print(a)
add2(b=20,a=40)


def add3(*c):
    print("the all values are",c)

add3(4,5,7,8,9,12,13,14)
def add3(**d):
    print("the all values are",d)

add3(name="srihari",age="29",organization="calsoft")
