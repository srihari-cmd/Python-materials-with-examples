'''
def facc_fun(n):
    return 1 if(n==1 or n==0) else n * facc_fun(n-1)

num = int(input("enter the number:"))

print("the factorial of",num,"is",facc_fun(num))
'''


# count vowels in sentance
'''
sentance = input("enter the sentance :")
string = sentance.casefold()
print(string)

count = 0

list1 = ["a","e","i","o","u"]
for char in string:
    if char in list1:
        count = count+1

print("number of vowels given in sentance:",count)
'''
num = int(input("enter number:"))
x,y=0,1
count = 0

if num<=0:
    print("please enter the positive integer")

elif num==1:
    print("fibonacci sequence upto",num,":")
    print(x)

else:
    print("fibonacci sequence :")
    while count<num:
        print(x)
        z=x+y
        x=y
        y=z
        count+=1






