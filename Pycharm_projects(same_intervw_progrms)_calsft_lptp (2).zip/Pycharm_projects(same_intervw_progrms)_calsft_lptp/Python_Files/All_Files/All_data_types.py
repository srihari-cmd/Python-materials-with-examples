'''
# string data type

'capitalize', 'casefold', 'count', 'endswith', 'find', 'format', 'index','isalpha', 'isascii', 'isdecimal', 'isdigit', \
'islower', 'isupper','join', 'lower', 'lstrip','partition', 'replace','rsplit', 'rstrip', 'split', 'splitlines', 'startswith',\
'strip', 'swapcase', 'title', 'upper'

s = "sriHaRi PamPAna"
# print(dir(s))

# s1 = s.capitalize()
# s1 = s.casefold()
# s1 = s.count('a')
# s1 = s.endswith('a')
# s1 = s.find('a')
# s1 = s.index('s')
# s1 = s.startswith('s')
# s1 = s.isalpha()
# s1 = s.isdigit()
# s1 = s.islower()
# s1 = s.isupper()
# s1 = s.join("123")
# s1 = s.lower()
# s1 = s.upper()
# s1 = s.rstrip()
# s1 = s.lstrip()
# s1 = s.strip()
# s1 = s.partition(" ")
# s1 = s.replace("sri","srihari")
# s1 = s.split()
# s1 = s.splitlines()
# s1 = s.swapcase()
# s1 = s.title()
# print(s1)

# list data type
'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort'

l = [3,2,1,4,2]
# print(dir(l))
# l.append(5)
# l.extend([5,6,7,8])
# l.clear()
# l1 = l.copy()
# l1 = l.count(2)
# l1 = l.index(3)
# l.insert(3,21)
# l.pop()
# l.remove(4)
# l.reverse()
# l.sort()
# print(l)

# tuple data type
'count', 'index'

t = (4,3,2,1,2)
# print(dir(t))

# t1 = t.count(2)
# t1 = t.index(2)
# print(t1)

# dictionary data type
'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values'

d = {"A":1,"C":3,"B":2}
# print(dir(d))
# d.clear()
# d1 = d.copy()
# d1 = d.get("B")
# d1 = d.items()
# d1 = d.keys()
# d1 = d.values()
# d.pop("B")
# d.popitem()
# d.update({"D":4})
# d.setdefault("B",2)
# d1 = {"B","C","A","D"}
# d2 = "char"
# d3 = dict.fromkeys(d1,d2)
# print(d3)


# set data type
'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint',\
'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update'

s1 = {4,2,1,3,2}

d1 = {1,3,2}
d2 = {3,5,4}
# print(dir(s1))

# s1.clear()
# s1.add(5)
# s2 = s1.copy()
# s1.discard(4)
# d3 = d1.intersection(d2)
# d3 = d1.union(d2)
# s1.pop()
# s1.remove(4)
# print(s1)


dd1 = {"A":1 ,"B":2}
dd1["C"]= {"v" : 7, "w" : 8, "x" : 9}
print(dd1)


dd1 = {"A":1 ,"B":2}
dd1["C"]= [1,2,3,4]
print(dd1)

dd2 = {"A":1 ,"B":2}
print(dd2)

list1 = [3,"A","B","A",2,2,1,3]
list2 = list(dict.fromkeys(list1))
print(list2)

'''

'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', \
'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', \
'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', \
'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill'

# s = "string Data Type"
# print(dir(s))
# print(s.capitalize())
# print(s.casefold())
# print(s.count("r"))
# print(s.endswith("e"))
# print(s.startswith("s"))
# print(s.find("r"))
# print(s.index("t"))
# print(s.isalpha())
# print(s.islower())
# print(s.isupper())
# print(s.upper())
# print(s.lower())
# print(s.lstrip())
# print(s.rstrip())
# print(s.strip())
# print(s.replace("Data","date"))
# print(s.replace("Data","date"))
# print(s.split())
# print(s.splitlines())
# print(s.swapcase())
# print(s.title())
'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort'
# l = [4,2,3,1]
# print(dir(l))
# l.append('srihari')
# print(l)
# l.extend([7,6,5])
# print(l)
# l2 = l.copy()
# print(l2)
# l2 = l.count(1)
# print(l2)
# l.clear()
# print(l)
# l2 = l.index(3)
# print(l2)
# l.insert(1,21)
# print(l)
# l.pop(2)
# print(l)
# l.remove(3)
# print(l)
# l.reverse()
# print(l)
# l.sort()
# print(l)
'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values'
# d = {"A":1,"B":2,"C":3}
# print(dir(d))
# d.clear()
# print(d)
# d1 = d.copy()
# print(d1)
# d1= d.get("B")
# print(d1)
# d1= d.items()
# print(d1)
# d1= d.keys()
# print(d1)
# d1 = d.pop("A")
# print(d1)
# d.popitem()
# print(d)
# d1= d.setdefault("A",12)
# print(d1)

# d.update({"D":4})
# print(d)
# d1 = d.values()
# print(d1)
# d1 = "ABCD"
# d2 = 0
# d3 = dict.fromkeys(d1,d2)
# print(d3)

'count', 'index'
# t = (3,2,1)
# print(dir(t))
# t1= t.count(2)
# print(t1)
# t1 = t.index(2)
# print(t1)


'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', \
'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', \
'union', 'update'
# s = {4,3,1,2}
# s1 = {6,4,5,7}
# print(dir(s))
# s.add(5)
# print(s)
# s.clear()
# print(s)
# s1 = s.copy()
# print(s1)
# s.discard(4)
# print(s)
# s2 = s.intersection(s1)
# print(s2)
# s2 = s.union(s1)
# print(s2)
# s2 = s.pop()
# print(s2)
# s.remove(4)
# print(s)
# s.update({5})
# print(s)

# n=23
# print(dir(n))




