
from collections import OrderedDict
dict = {'rams': '10', 'raghu': '9', 'snantanu': '15', 'sri': '2', 'ssrikanth': '32'}
dict1 = OrderedDict(sorted(dict.items()))
print(dict1)


x = {1: 2, 3: 4, 4: 3, 2: 1, 0: 0}
x1 = {k: v for k, v in sorted(x.items(), key=lambda item: item[1])}
print(x1)

dd1 = {"A":1 ,"B":2}
dd1["C"]= {"v" : 7, "w" : 8, "x" : 9}
# print(type(dd1["C"]))
print(type(dd1["C"]))

dd1 = {"A":1 ,"B":2}
dd1["C"]= [1,2,3,4]
print(dd1)

