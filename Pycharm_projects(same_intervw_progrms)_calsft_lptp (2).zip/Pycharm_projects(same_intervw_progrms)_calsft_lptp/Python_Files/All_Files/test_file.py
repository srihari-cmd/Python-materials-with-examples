dict  = {"A":1,"m":2,"C":None}

# print(dict.keys())
# dict.values()
# dict.update({"D":4})
# print(dict.keys())
# d1 = dict.keys()
# d2.sorted()
# dict.update({"E":5})
# dict["E"]= {‘v’ : 7, ‘w’ : 8, ‘x’ : 9}
dict["F"]=[1,2,3,4]
print(type(dict["F"]))

# D1 = {"A" :1, ‘B’:2}
# D2 = {‘B’:2 , ‘C’:3, ‘a’:1}
# comP_dict = {K : D1[k] for k in D1 if k in D2 and D1[k]==D2[k]}


#
# str = input("")
# t = 1
# for i in range(str):
    # if

