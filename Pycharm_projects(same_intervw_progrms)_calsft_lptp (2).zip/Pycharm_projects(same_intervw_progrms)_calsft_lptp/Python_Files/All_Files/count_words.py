str = "Iterview scheduled at 5 PM get ready for that time"
str1 = str.split()
print(len(str1))



str2 = "srihari is a person"

str3 = str2.split()
print(str3)
print(len(str3))

