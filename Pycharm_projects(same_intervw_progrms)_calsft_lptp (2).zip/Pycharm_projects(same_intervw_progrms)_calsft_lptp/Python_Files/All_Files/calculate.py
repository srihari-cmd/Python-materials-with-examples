
# a = '10'
# b ='20'
# print(a+b)
# # print(int.__add__(a,b))
# print(str.__add__(a,b))


class Calculate:
    def __init__(self,number):
        self.number = number
    def __add__(self, other):
        return self.number + other.number
    def __sub__(self, other):
        return self.number - other.number
    def __mul__(self, other):
        return self.number * other.number
    def __mod__(self, other):
        return self.number % other.number
    def __truediv__(self, other):
        return self.number / other.number

a1 = Calculate(10)
a2 = Calculate(20)
a3 = a1+a2
print(a3)

a1 = Calculate(40)
a2 = Calculate(20)
a3 = a1-a2
print(a3)

a1 = Calculate(10)
a2 = Calculate(5)
a3 = a1*a2
print(a3)

a1 = Calculate(10)
a2 = Calculate(5)
a3 = a1 % a2
print(a3)

a1 = Calculate(10)
a2 = Calculate(5)
a3 = a1 / a2
print(a3)


# s1 = Student(10,20)

# class Calculate:
#     def __init__(self,a,b):
#         self.a=a
#         self.b=b
#
#     def __add__(self, other):
#         return other
#
# inst = Calculate(10,20)


