
fh = open("C:\\Users\\srihari.pampana\\PycharmProjects\\Python_Files\\All_Files\\sriharifile.txt","r")
# fh = open("C:\\Users\\srihari.pampana\\PycharmProjects\\Python_Files\\All_Files\\fileeee.txt","r")
data = fh.read(10)
print(data)
position = fh.tell()
print("the position of the file is",position)

position1 = fh.seek(0,0)
str = fh.read(5)
print("after the position changed",str)

