from selenium import webdriver
import time
url = "https://opensource-demo.orangehrmlive.com/"
username = "Admin"
password = "admin123"

usr_id= "txtUsername"
psswd_name = "txtPassword"
submt_id = "btnLogin"


class HRM:
    def __init__(self,url,user,passwd):
        self.url = url
        self.user=user
        self.passwd=passwd


    def login_page(self):
        self.driver = webdriver.Chrome()
        # self.driver.get(self.url)
        self.driver.maximize_window()
        # Open url
        self.driver.get("https://www.python.org/")
        time.sleep(5)
        self.driver.execute_script("window.open('http://robotframework.org/')")
        time.sleep(3)
        self.driver.execute_script("window.open('https://mail.google.com')")
        time.sleep(4)
        #to get all window tabs

        windows = self.driver.window_handles
        print("\n all the window tabs",windows)
        print("\n default tab title is",self.driver.title)

        ## Switch into first tab from right side
        self.driver.switch_to.window(windows[0])
        time.sleep(3)
        print("the 000 tab title is",self.driver.title)

        self.driver.switch_to.window(windows[1])
        time.sleep(3)
        print("the 111 tab title is",self.driver.title)

        self.driver.switch_to.window(windows[2])
        time.sleep(3)
        print("the 222 tab title is",self.driver.title)

        self.driver.switch_to.window(self.driver.window_handles[2])
        time.sleep(3)
        print("\n the index of 2 tab title is ",self.driver.title)

        self.driver.switch_to.window(self.driver.window_handles[1])
        time.sleep(3)
        print("\n the index of 1 tab title is ",self.driver.title)

        self.driver.switch_to.window(self.driver.window_handles[0])
        time.sleep(3)
        print("\n the index of 0 tab title is ",self.driver.title)




        # self.driver.find_element_by_id(usr_id).send_keys(username)
        # self.driver.find_element_by_name(psswd_name).send_keys(password)
        # self.driver.find_element_by_id(submt_id).click()
        # time.sleep(3)
        # self.driver.find_element_by_id("welcome").click()
        # time.sleep(3)
        # self.driver.find_element_by_link_text("Logout").click()
        # self.driver.close()

s1 = HRM(url,username,password)
s1.login_page()




