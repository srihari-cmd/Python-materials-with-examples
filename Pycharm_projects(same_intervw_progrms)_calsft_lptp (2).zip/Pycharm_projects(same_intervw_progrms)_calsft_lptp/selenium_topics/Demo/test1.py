# file1  = open("C:\\Users\\srihari.pampana\\Desktop\\abc.txt","r")
# data = file1.readlines()
# print(data)
# #
# for i in data:
#     file2 = open("C:\\Users\\srihari.pampana\\Desktop\\xyz.txt","w")
#     data1 = file2.write(i)
#     print(data1)
#

#
# fh  = open("C:\\Users\\srihari.pampana\\Desktop\\abc.txt","r")
# data = fh.readlines()
# print(data)
#
# for i in data:
#     fh2 = open("C:\\Users\\srihari.pampana\\Desktop\\xyz.txt","w")
#     data1 = fh2.write(i)
#     print(data1)

items = ["one", "two", "three"]

for item in items:
    with open("C:\\Users\\srihari.pampana\\Desktop\\{}hello_world.txt".format(item), "w") as f:
        f.write("This is my first line of code")
        f.write("\nThis is my second line of code with {} the first item in my list".format(item))
        f.write("\nAnnd this is my last line of code")