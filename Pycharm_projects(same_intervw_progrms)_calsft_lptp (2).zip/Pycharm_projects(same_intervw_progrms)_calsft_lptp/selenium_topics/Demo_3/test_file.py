# fh = open(r"C:\Users\srihari.pampana\PycharmProjects\selenium_topics\Demo_3\abc.txt","r")
# data = fh.writelines(["sdfjl sdjldjkf sjhhkx \n","fsdkkeq adhskhckj asdkjkc \n","sdkkjk ffkjsfdkf sdks \n", "sad \n","dsfsk \n"])
# data = fh.readlines()
# print(data)


# l1 = [2,3,4]
# l2 = [5,7,8]
# l3 = {i:j for i in l1 for j in l2}
# l3 = {i:j for (i,j) in (l1)}
# print(l3)

import os
# list_all = os.walk()
for (root,dirs,files) in os.walk("C:\\Users\\srihari.pampana\\Desktop\\Python_program",topdown=True):
    print(root)
    print(dirs)
    print(files)
    print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")