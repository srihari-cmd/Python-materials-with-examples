# Python3 code to demonstrate working of
# Find dictionary matching value in list
# Using loop

# Initialize list
test_list = [{'gfg' : 2, 'is' : 4, 'best' : 6},
			{'it' : 5, 'is' : 7, 'best' : 8},
			{'CS' : 10}]

# Printing original list
print("The original list is : " + str(test_list))
print("the index based list:",test_list[0])
print("the index based list:",test_list[1])
print("the index based list:",test_list[2])
# print("the index based list:",type(test_list[0]))


# Using loop
# Find dictionary matching value in list
res = None
for sub in test_list:
	if sub['is'] == 7:
		res = sub


# printing result
print("The filtered dictionary value is : " + str(res))



l1 = [{"A":1,"B":3},{"C":2,"D":4},{"A":1,"E":5}]
res = None
for sub in l1:
    if sub["A"]==1:
        res = sub
        break
print(res)



# Python3 code to demonstrate working of
# Get values of particular key in list of dictionaries
# Using list comprehension

# initializing list
# test_list = [{"A":1,"B":3},{"C":2,"D":4},{"A":1,"E":5}]

test_list = [{'gfg' : 1, 'is' : 2, 'good' : 3},
			{'gfg' : 2}, {'best' : 3, 'gfg' : 4}]



