
# hh = {"a": {"b": {"c": "qwe", "d": "rty"}, "x": {"y": "asd", "z": "cvb"}}}
#
#
# # {"b": {"c": "qwe", "d": "rty"}, "x": {"y": "asd", "z": "cvb"}}
#
# gh = hh["a"]["x"]["y"]
# print(gh)
# gh1 = hh.get("a")["b"]["d"]
# print(gh1)

l1 = [4,2,5,7,8]
l2 = [3,4,5,6]
x = [2,6]
l3 = set(l1)

l4 = l3.intersection(l2)
l5 = list(l4)
l6 = [x[i] * l5[i] for i in range(len(x))]
print(l6)
# print(list(l4))



l1 = [4,2,5,7,8]
l2 = [3,4,5,6]
x = [2,6]
l3 = [i for i in l1 if i in l2]
l4 = [x[i] * l3[i] for i in range(len(x))]
print(l4)


foo=[1,2,3,4]
bar=[1,2,5,55]
l=list(map(lambda x,y:x*y,foo,bar))
print(l)