from selenium import webdriver
import time
url = "https://opensource-demo.orangehrmlive.com/"
username = "Admin"
password = "admin123"

usr_id= "txtUsername"
psswd_name = "txtPassword"
submt_id = "btnLogin"



driver = webdriver.Chrome()
driver.get(url)
driver.maximize_window()
driver.find_element_by_id(usr_id).send_keys(username)
driver.find_element_by_name(psswd_name).send_keys(password)
driver.find_element_by_id(submt_id).click()
time.sleep(4)
driver.back()
time.sleep(2)
driver.forward()



