from selenium import webdriver
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.python.org/")
time.sleep(4)
# driver.execute_script("window.scrollTo(800,900)")

''' Scroll to the page end '''
driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

time.sleep(10)

''' Scroll to the page top '''
driver.execute_script("window.scroll(0, 0);")


