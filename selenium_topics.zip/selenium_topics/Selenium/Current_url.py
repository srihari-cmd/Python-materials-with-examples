from selenium import webdriver
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.python.org/")
time.sleep(4)

get_currnt_url = driver.current_url

print("the current url is ",get_currnt_url)
assert get_currnt_url == "https://www.python.org/","the url is mismatched"



