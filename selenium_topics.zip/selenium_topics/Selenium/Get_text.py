from selenium import webdriver
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.python.org/")
time.sleep(4)

get_text = driver.find_element_by_id("downloads").text
print("the text for the element is ",get_text)

assert get_text =="Downloads" ,"doesnt match"


