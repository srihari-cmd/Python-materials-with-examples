# from selenium import webdriver
# from selenium.webdriver.support.ui import Select
# import time
# url = "https://www.facebook.com/"
# # username = "Admin"
# # password = "admin123"
#
# # usr_id= "txtUsername"
# # psswd_name = "txtPassword"
# # submt_id = "btnLogin"
#
# driver = webdriver.Chrome()
# driver.get(url)
# driver.maximize_window()
# driver.find_element_by_id("u_0_2").click()
# day_value = Select(driver.find_element_by_name("birthday_day")).select_by_index("13")




# Select(driver.find_element_by_id("select#numReturnSelect")).select_by_value(15000).click()

# driver.find_element_by_id(usr_id).send_keys(username)
# driver.find_element_by_name(psswd_name).send_keys(password)
# driver.find_element_by_id(submt_id).click()
# time.sleep(4)
# driver.back()
# time.sleep(2)
# driver.forward()

from selenium import webdriver
import time
from selenium.webdriver.support.ui import Select
d=webdriver.Chrome()
d.get("http://www.facebook.com/")
d.maximize_window()
time.sleep(3)
#so=Select(d.find_element_by_id('month'))

so=Select(d.find_element_by_id('month'))
#so.select_by_visible_text('Feb')
#so.select_by_index(4)
so.select_by_value('4')
s1=Select(d.find_element_by_id('day'))
s1.select_by_index(14)
s2=Select(d.find_element_by_id('year'))
s2.select_by_index(21)

