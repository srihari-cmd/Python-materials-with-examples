from selenium import webdriver
import time

# with maximize window and without maximize window method checking the size
#
# driver = webdriver.Chrome()
# driver.get("https://www.python.org/")
# time.sleep(4)
# print("the current window size is ",driver.get_window_size())


driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.python.org/")
time.sleep(4)
print("the current window size is ",driver.get_window_size())

time.sleep(3)

print("the current window size is ",driver.set_window_size(1000,702))


