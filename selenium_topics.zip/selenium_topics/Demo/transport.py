class Vihecle1:
    def __init__(self,name,color,wheels,seats):
        self.name = name
        self.color = color
        self.wheels = wheels
        self.seats = seats
    def Bus(self):
        print("the bus name is:",self.name)
        print("the bus color is:",self.color)
        print("the bus wheels is:",self.wheels)
        print("the bus seats is:",self.seats)

class Vihecle2(Vihecle1):
    def Car(self):
        print("the car name is:", self.name)
        print("the car color is:", self.color)
        print("the car wheels is:", self.wheels)
        print("the car seats is:", self.seats)

obj = Vihecle2("Volvo","white",4,25)
obj.Bus()
