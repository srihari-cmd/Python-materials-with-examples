#
# # 1. Run all the files and test methods which is starts with test_ or ends with  _test.use below command to run all the test methods and files.
#
# py.test
#
# # 2. run all the files and test methods using -v means verbose(it is nothing but it shows passed or failed)
#
# py.test -v
#
# # 3. run test methods which is having print function in method.that will display in to the console using -s method .to run the below command .
#
# py.test - v - s
#
# # 4. its the same as -s option,which outputs the print statement on the console.
#
# pytest - -capture = no
#
# # 5.To run the pytest files which is not contains with test in starting.that files we have to run explicitly.
#
# pytest < filename > -v
#
# # or using python below cmd to run .
#
# python
# pytest < filename > -v
#
# # 6. To run test method which contains substring .use -k we can run the test methods.
#
# py.test - v - k < substring >
#
# # or
#
# pytest –v  –k < “substring or sub
# function” >
#
# # or we can use with out -k to run the test methods contain substring
#
# pytest < filename >:: < particular
# test_function > -v
#
# # 7. the -q option will not verbose the failed and passed test cases ,instead its results in dot(.) for the success and (F) for the failed test case
#
# pytest - v - q
#
# # 8. Based on  maxfail it will move forward the test cases. Its reults the failed test cases uptil the depth of the maxfail.If suppose <number> is 2 its results the 2 failed test cases.
#
# pytest - v - -maxfail = < number >
#
# # 9.if we contain first failure occurs in test case it will terminated or exit automatically.it will not continue on next test case. -x is used to terminated whearter it contain test method failed.
#
# pytest < filename > -v - x
#
# # 10. Once the error will occur .It does not display the assertion error message in cmd line.  use below cmd to execute the test cases.
#
# pytest - v - -tb = no
#
#
# # 11.using this cmd we can skip the particular test case or function. use decorotor (@)  we can define the skip function.
#
# @pytest.mark.skip(reason="do not run the particular test case means we can use it")
#
#
# py.test
# Test_file.py - k < mark
# name > -v
#
#
# # 12 we can use skipif to make condition in perticular thing. we can defined skipif in below.
#
# @pytest.mark.skipif(
#
# < here
# we
# can
# make
# condition >)
#
# py.test
# Test_file.py - k < mark
# name > -v
#
#
# # 13.using this cmd we can skip the particular test case or function. use decorotor (@)  we can define the skip function.
#
# @pytest.mark.parametrize()
# # 14 using this cmd we can run the test cases which is contain mark.we can defined mark in below.
#
# @pytest.mark.
#
# < mark
# name >
#
# py.test
# Test_file.py -k
# set1 - v
#
#
# # 15 Fixtures are used when we want to run some code before every test method. So instead of repeating the same code in every test we define fixtures. Usually, fixtures are used to initialize database connections, pass the base , etc.
# # To keep  setup and teardown function in fixtures.using scope for both .
# # * setup will execute before all the test methods only one time.
# # * teardown will execute after all the test methods only one time.
#
# @pytest.fixture
# # 16 . There will be some situations where we don't want to execute a test, or a test case is not relevant for a particular time. In those situations, we have the option to xfail the test or skip the tests.
# # The xfailed test will be executed, but it will not be counted as part failed or passed tests. There will be no traceback displayed if that test fails. We can xfail tests using
#
# @pytest.mark.xfail

#
#

