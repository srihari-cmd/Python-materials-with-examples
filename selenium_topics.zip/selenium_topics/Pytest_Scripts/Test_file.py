
import pytest


def test_add():
    x = 10
    y = 21
    assert x+11==y,"test failed"


def test_sub():
    x = 10
    y = 12
    assert x+1==y,"test failed"


def test_mul():
    x = 10
    y = 20
    assert x*2==y,"test failed"


def test_sub1():
    x = 10
    y = 12
    assert x+1==y,"test failed"
