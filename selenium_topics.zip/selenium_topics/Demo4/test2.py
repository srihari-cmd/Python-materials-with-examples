l1 = [1,2,3,2,5,3]
# l2 = [4,5,6]
l3 = {i:i**2 for i in l1}
print(l3)

x = "abcd"
d1 = {}
for i in x:
    d1[i] = "char"
print(d1)

d2 = {}
d2["a"] = 20
print(d2)