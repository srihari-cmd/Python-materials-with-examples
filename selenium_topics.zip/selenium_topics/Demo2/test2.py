'''

# dict1 = {"A":"23","45":20,"10":20}
# print(dict1.get("45"))
#
#
# # dict1 = {“Hello”:”5”,“45”:20, 10:20}
# dict1 = {"Hello":"5","45":20, 10:20}
# print(dict1.get("45"))
# print(dict1["45"])


#
# tup = (1,2,[1,2,3],5,6)
# print(tup[2].append(10))
# tup[2].append(20)
# print(tup)
# print(tup.append(30))
#
# def print_name(prefix):
#     print("Searching prefix: {}".format(prefix))
#     While True:
#          name = (yield)
#          If prefix in name:
#              print(name)
# corou =  print_name("Dear")
# corou.__next__()
# corou.send("Atul")
# corou.send("Dear Atul")
#
# def hello_decorator(func):
#     def inner1(*args, **kwargs):
#         print("before Execution")
#         returned_value = func(*args, **kwargs)
#         print("after Execution")
#         return returned_value
#
#     return inner1
#
#
# @hello_decorator
# def sum_two_numbers(a, b):
#     print("Inside the function")
#     return a + b
#
# a, b = 1, 2
#
# print("Sum =", sum_two_numbers(a, b))
#
'''


# data types    done
# funtions   done
# file handling    done
# regular expression
# oops
# decorator      done
# iterator  done
# generator    done
# constructor   done
# lambda,map,reduce,filter
#


class A:
    def add(self):
        print("A add is:")

    def add(self,a):
        print("A add is:",a)

    def add(self,a,b):
        print("A add is:",a+b)


obj = A()
obj.add(20,30)


# from shutil import copyfile
# copyfile(r"C:\Users\srihari.pampana\Desktop\xyz3.txt",r"C:\Users\srihari.pampana\Desktop\xyz4.txt")

import string, os
if not os.path.exists("letters"):
   os.makedirs("letters")
for letter in string.ascii_uppercase:
   with open("C:\\Users\\srihari.pampana\\Desktop\\" +letter +".txt", "w") as f:
       f.writelines(letter)



