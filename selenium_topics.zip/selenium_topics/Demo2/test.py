l1 = [1,2,1,1,3,4,3,5,6,7,7]
l2 = [9,2,4,6,9,7,6]
l1.extend(l2)
print(l1)

from collections import Counter

a = dict(Counter(l1))
print(a)



