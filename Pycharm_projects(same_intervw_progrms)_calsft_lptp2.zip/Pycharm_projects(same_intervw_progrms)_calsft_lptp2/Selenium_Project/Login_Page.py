from selenium import webdriver
import time
user = "rebalsrihari143@gmail.com"
pwd = "8977483646"
fb = "https://www.facebook.com/"
class Login():
    def credentilas(self,fb,user,pwd):
       # d = webdriver.Chrome("C:\chromedriver_win32")
        d = webdriver.Chrome(executable_path=r"C:\chromedriver_win32\chromedriver.exe")
        d.get(fb)
        d.maximize_window()
        d.find_element_by_id("email").clear()
        time.sleep(2)
        d.find_element_by_id("email").send_keys(user)
        time.sleep(4)
        d.find_element_by_name("pass").clear()
        time.sleep(2)
        d.find_element_by_name("pass").send_keys(pwd)
        time.sleep(3)
        d.find_element_by_id("loginbutton").click()
        time.sleep(4)

inst = Login()
inst.credentilas(fb,user,pwd)




